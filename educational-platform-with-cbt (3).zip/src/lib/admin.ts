export function isAdmin(req: Request) {
  const code = req.headers.get("x-admin-code") ?? "";
  return code.length > 0 && code === (process.env.ADMIN_CODE || "prince-admin");
}
