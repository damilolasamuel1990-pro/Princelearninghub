import type { Chapter } from "./pdf-handout";

export const maths: Chapter = {
  id: "maths",
  title: "Mathematics and Statistics for Computing",
  tagline: "The quantitative tools that support computing: algebra, calculus, logic, statistics and operations research.",
  units: [
    {
      title: "Sets, Relations, Functions and Logic",
      objectives: [
        "perform operations on sets and use Venn diagrams",
        "explain relations and functions with examples",
        "apply the laws of logic and quantifiers",
        "use modular arithmetic in computing applications",
      ],
      paragraphs: [
        "A set is a well defined collection of objects, written in braces, for example A = {1, 2, 3}. The operations of sets are union (A U B), intersection (A n B), difference (A - B) and complement (A'). Venn diagrams are used to visualise these operations and to solve counting problems. The formula n(A U B) = n(A) + n(B) - n(A n B) is used frequently in examinations.",
        "A relation R from set A to set B is a set of ordered pairs. Relations may be reflexive, symmetric, transitive or antisymmetric. A relation that is reflexive, symmetric and transitive is an equivalence relation and divides a set into classes. A function f: A -> B assigns to each element of A exactly one element of B. Functions may be one-to-one (injective), onto (surjective) or both (bijective).",
        "Logic deals with statements that are either true or false. The connectives are negation (not), conjunction (and), disjunction (or), implication (if ... then) and biconditional (if and only if). Truth tables are used to determine the truth value of compound statements. Quantifiers extend logic to many cases: the universal quantifier (for all) and the existential quantifier (there exists).",
        "Modular arithmetic works with remainders and is the basis of hash functions, check digits and cryptography. We write a mod n for the remainder when a is divided by n. For example, 17 mod 5 = 2, and because clocks repeat every 12 or 24 hours, they are a familiar example of modular arithmetic.",
      ],
      keyPoints: [
        "n(A U B) = n(A) + n(B) - n(A n B).",
        "A function maps each input to exactly one output.",
        "Implication p -> q is false only when p is true and q is false.",
        "Modular arithmetic returns the remainder of a division.",
      ],
      example: {
        heading: "Worked example — sets and counting",
        lines: [
          "In a class of 40 students, 22 offer CSC, 18 offer MTH and 8 offer both. How many offer neither?",
          "n(C U M) = 22 + 18 - 8 = 32.",
          "Students offering neither = 40 - 32 = 8 students.",
          "This method is used in course registration reports and timetable planning.",
        ],
      },
      summary:
        "Sets, relations, functions and logic form the language of computing. Modular arithmetic is widely used in hashing, checksums and encryption.",
      questions: [
        "If A = {2, 4, 6, 8} and B = {4, 8, 12}, find A U B and A n B.",
        "Define a one-to-one function and give an example.",
        "Construct the truth table for (p and q) or (not p).",
        "Evaluate 25 mod 7 and explain where mod is used in computing.",
      ],
    },
    {
      title: "Basic Calculus and Linear Algebra",
      objectives: [
        "differentiate and integrate simple functions",
        "apply derivatives to rates of change and optimisation",
        "perform operations on matrices",
        "solve systems of equations using matrices",
      ],
      paragraphs: [
        "Calculus is the mathematics of change. Differentiation gives the rate at which a quantity changes. The basic rule is that if y = x raised to the power n, then dy/dx = n x raised to the power (n - 1). Derivatives are used in computing to measure growth rates, to optimise algorithms and in the training of machine learning models through gradient methods.",
        "Integration is the reverse of differentiation and is used to find areas, volumes and totals. The integral of x raised to the power n is x raised to the power (n + 1) divided by (n + 1), plus a constant. Definite integrals are evaluated between two limits and are used in probability to find areas under curves.",
        "A matrix is a rectangular arrangement of numbers in rows and columns. Matrices are added by adding corresponding elements and multiplied by combining rows with columns. The determinant of a square matrix is used to find whether the matrix has an inverse, and the inverse is used to solve systems of simultaneous equations.",
        "Linear algebra is applied widely in computing: transformations in computer graphics use matrices, data sets in machine learning are represented as matrices, and networks are described by adjacency matrices. Students should be comfortable with matrix addition, multiplication and determinants up to 3 by 3 matrices.",
      ],
      keyPoints: [
        "d/dx (x^n) = n x^(n-1); the integral of x^n is x^(n+1)/(n+1) + C.",
        "Matrices add element by element; multiplication combines rows and columns.",
        "A determinant of zero means the matrix has no inverse.",
        "Matrices are used in graphics, machine learning and network analysis.",
      ],
      example: {
        heading: "Worked example — matrix multiplication",
        lines: [
          "Let A = [[1, 2], [3, 4]] and B = [[5, 6], [7, 8]].",
          "A x B = [[1x5 + 2x7, 1x6 + 2x8], [3x5 + 4x7, 3x6 + 4x8]]",
          "= [[19, 22], [43, 50]].",
          "Notice that matrix multiplication is not commutative: B x A gives a different result.",
        ],
      },
      summary:
        "Calculus measures change and optimisation, while linear algebra provides the structures used to represent data and transformations in computing.",
      questions: [
        "Differentiate y = 3x^3 - 2x + 7.",
        "Evaluate the definite integral of 2x from 0 to 3.",
        "Find the determinant of the matrix [[2, 3], [1, 4]].",
        "State two applications of matrices in computing.",
      ],
    },
    {
      title: "Statistics and Data Analysis",
      objectives: [
        "calculate measures of location and dispersion",
        "construct frequency tables and charts",
        "explain probability and its basic rules",
        "interpret statistical results in a computing context",
      ],
      paragraphs: [
        "Statistics is the science of collecting, organising, analysing and interpreting data. Data may be primary (collected first hand) or secondary (obtained from existing sources). Measures of location describe the centre of the data: the mean (sum divided by the number of items), the median (middle value) and the mode (most frequent value). Measures of dispersion describe the spread: the range, the variance and the standard deviation.",
        "Grouped data is presented in a frequency table with class intervals, class marks and frequencies. Charts are used to present results: bar charts compare categories, pie charts show proportions, histograms show the distribution of grouped data and ogives show cumulative frequency. Choosing the right chart makes results easy to understand.",
        "Probability measures the likelihood of an event and is a value between 0 and 1. The probability of an event is the number of favourable outcomes divided by the total number of equally likely outcomes. For two independent events, the probability that both occur is the product of their probabilities. Permutations count arrangements while combinations count selections.",
        "Statistical analysis is used in computing to benchmark systems, to analyse network traffic, to study user behaviour and to train machine learning models. A student who can summarise data, draw the right chart and interpret the result has a skill that is valuable in every field.",
      ],
      keyPoints: [
        "Mean = sum of values divided by the number of values.",
        "Range = highest value minus lowest value.",
        "Probability is between 0 and 1; P(A) = favourable outcomes / total outcomes.",
        "Permutations count arrangements; combinations count selections.",
      ],
      table: {
        caption: "Table 5.1 — Measures of location and dispersion",
        headers: ["Measure", "Type", "Formula", "Use"],
        rows: [
          ["Mean", "Location", "sum of x divided by n", "Average score"],
          ["Median", "Location", "Middle value", "Robust to outliers"],
          ["Mode", "Location", "Most frequent value", "Most common result"],
          ["Range", "Dispersion", "Maximum minus minimum", "Simple spread"],
          ["Standard deviation", "Dispersion", "Square root of variance", "Typical deviation"],
        ],
      },
      example: {
        heading: "Worked example — mean and standard deviation",
        lines: [
          "Scores: 5, 7, 8, 10. Mean = (5 + 7 + 8 + 10) / 4 = 7.5.",
          "Deviations: -2.5, -0.5, 0.5, 2.5. Squared deviations: 6.25, 0.25, 0.25, 6.25.",
          "Variance = (6.25 + 0.25 + 0.25 + 6.25) / 4 = 3.25. Standard deviation = sqrt(3.25) = 1.80.",
          "Interpretation: the scores typically deviate from the mean by about 1.8 marks.",
        ],
      },
      image: "course-mth.jpg",
      imageCaption: "Figure 5.3 — Mathematical models support computing",
      summary:
        "Statistics turns raw data into useful conclusions. The ability to summarise, present and interpret data is essential for research, benchmarking and data driven decision making.",
      questions: [
        "Calculate the mean, median and mode of 3, 7, 7, 9, 12.",
        "Explain the difference between primary and secondary data.",
        "A die is thrown once. Find the probability of obtaining a number greater than 4.",
        "When would you use a histogram rather than a bar chart?",
      ],
    },
    {
      title: "Operations Research and Mathematical Modelling",
      objectives: [
        "explain the meaning and steps of operations research",
        "formulate simple linear programming problems",
        "apply the graphical method to two variable problems",
        "explain queueing and inventory models in simple terms",
      ],
      paragraphs: [
        "Operations research applies scientific and mathematical methods to decision making. Its steps are: defining the problem, building a mathematical model, solving the model, testing the solution and implementing it. The technique became prominent during the Second World War and is now used in transport, manufacturing, telecommunications and healthcare.",
        "Linear programming is the most widely used method. It consists of decision variables, an objective function (to be maximised or minimised) and constraints. The graphical method draws the constraints to produce a feasible region and evaluates the objective function at each corner point; the optimal solution is found at one of these corners. The simplex method is used when there are more than two variables.",
        "Queueing theory studies waiting lines and is used to design service systems such as bank counters, network routers and print servers. The main measures are the arrival rate, the service rate, the average length of the queue and the average waiting time. Well designed systems balance service quality against cost.",
        "Inventory models such as the Economic Order Quantity determine how much to order and when, so as to minimise the combined cost of ordering and holding stock. These models are used in supply chain management and are good examples of how mathematics saves money in practice.",
      ],
      keyPoints: [
        "Operations research: define, model, solve, test, implement.",
        "Linear programming finds the best outcome under constraints.",
        "Queueing theory designs service systems such as routers and bank counters.",
        "The Economic Order Quantity balances ordering and holding costs.",
      ],
      example: {
        heading: "Worked example — linear programming",
        lines: [
          "Maximise Z = 3x + 2y subject to x <= 4, y <= 3, x >= 0, y >= 0.",
          "The feasible region is a rectangle with corners (0,0), (4,0), (4,3) and (0,3).",
          "Z at the corners: 0, 12, 18 and 6 respectively.",
          "Therefore the maximum value is Z = 18 at x = 4 and y = 3.",
        ],
      },
      summary:
        "Operations research uses mathematical models to support decisions. Linear programming, queueing and inventory models are the techniques most often used in computing and business.",
      questions: [
        "List the steps of the operations research process.",
        "A student must produce at least 120 units. Formulate a simple linear programming problem for this situation.",
        "Explain the terms arrival rate and service rate in queueing theory.",
        "What is the purpose of the Economic Order Quantity model?",
      ],
    },
  ],
  assignments: [
    {
      title: "Mathematics and Statistics",
      questions: [
        "In a group of 60 students, 35 study programming, 28 study mathematics and 12 study both. How many study neither? Draw a Venn diagram to illustrate your answer.",
        "Differentiate y = 4x^3 - 3x^2 + 2x - 5 and evaluate the derivative when x = 2.",
        "The following are the marks of ten students: 45, 67, 55, 78, 90, 62, 48, 71, 84, 59. Calculate the mean, median, range and standard deviation, and present the data in a frequency table.",
        "Explain how queueing theory can be used to design the queue at a bank or a network server.",
      ],
    },
  ],
  glossary: [
    { term: "Calculus", definition: "The mathematics of change, including differentiation and integration." },
    { term: "Combination", definition: "A selection of items where order does not matter." },
    { term: "Determinant", definition: "A value computed from a square matrix that shows whether it has an inverse." },
    { term: "Frequency", definition: "The number of times a value occurs in a data set." },
    { term: "Function", definition: "A mapping that assigns each input exactly one output." },
    { term: "Linear programming", definition: "A method of optimising a linear objective under constraints." },
    { term: "Matrix", definition: "A rectangular arrangement of numbers in rows and columns." },
    { term: "Mean", definition: "The average value of a data set." },
    { term: "Median", definition: "The middle value of an ordered data set." },
    { term: "Permutation", definition: "An arrangement of items where order matters." },
    { term: "Probability", definition: "The likelihood of an event, between 0 and 1." },
    { term: "Queueing theory", definition: "The study of waiting lines and service systems." },
    { term: "Relation", definition: "A set of ordered pairs linking elements of two sets." },
    { term: "Set", definition: "A well defined collection of distinct objects." },
    { term: "Variance", definition: "The average of squared deviations from the mean." },
  ],
  references: [
    "Kreyszig, E. (2011). Advanced Engineering Mathematics. 10th ed. Wiley.",
    "Taha, H. A. (2016). Operations Research: An Introduction. 10th ed. Pearson.",
    "Bluman, A. G. (2017). Elementary Statistics: A Step by Step Approach. McGraw-Hill.",
    "Prince Learning Hub (2026). Mathematical Methods: Worked Examples. Lagos.",
  ],
};

export const programming: Chapter = {
  id: "programming",
  title: "Programming Fundamentals and Problem Solving",
  tagline: "From algorithm to working program: paradigms, control structures, arrays and files.",
  units: [
    {
      title: "Programming Concepts, Paradigms and Algorithms",
      objectives: [
        "explain the meaning of programming and program development",
        "compare the major programming paradigms",
        "write algorithms in pseudocode",
        "draw flowcharts for simple problems",
      ],
      paragraphs: [
        "Programming is the process of designing, writing, testing and maintaining programs. A program is a set of instructions that a computer follows to solve a problem. Before writing code, the programmer must understand the problem, plan the solution and then express the solution in a form that can be translated by the computer. Planning reduces errors and saves time later.",
        "Programming paradigms describe different styles of writing programs. In imperative (procedural) programming the programmer gives a sequence of commands that change the state of memory. In declarative programming the programmer describes what result is required; logic programming (Prolog) and query languages (SQL) are examples. Functional programming builds programs from pure functions, and object oriented programming models a system as interacting objects.",
        "An algorithm is a finite, ordered set of well defined steps for solving a problem. It must have clear input and output, be definite (unambiguous), finite (it must end) and effective (each step must be executable). Pseudocode expresses an algorithm in plain language that resembles programming statements but does not belong to any language.",
        "A flowchart is a pictorial representation of an algorithm. The oval represents start or stop, the parallelogram represents input or output, the rectangle represents a process, the diamond represents a decision and the arrow shows the flow of control. Flowcharts are especially useful for planning programs with branches and loops.",
      ],
      keyPoints: [
        "Plan before coding: understand the problem, design the solution, then write the program.",
        "Paradigms: procedural, declarative, functional and object oriented.",
        "An algorithm must be finite, definite and effective.",
        "Flowchart symbols: oval, parallelogram, rectangle, diamond, arrow.",
      ],
      diagram: "flowchart",
      example: {
        heading: "Worked example — pseudocode for the larger of two numbers",
        lines: [
          "START",
          "  READ A, B",
          "  IF A > B THEN",
          "     PRINT A",
          "  ELSE",
          "     PRINT B",
          "  END IF",
          "STOP",
        ],
      },
      image: "course-csc.jpg",
      imageCaption: "Figure 6.1 — Source code in a development environment",
      summary:
        "Good programs begin with a clear algorithm. Pseudocode and flowcharts allow the programmer to test the logic before writing code in any particular language.",
      questions: [
        "Define an algorithm and list four characteristics of a good algorithm.",
        "Compare procedural and object oriented programming.",
        "Write pseudocode to calculate the average of three numbers.",
        "Draw a flowchart that reads ten numbers and prints the largest.",
      ],
    },
    {
      title: "Data Types, Variables, Expressions and Operators",
      objectives: [
        "declare variables and constants with the correct data type",
        "use arithmetic, relational and logical operators",
        "explain type conversion and precedence of operators",
        "write correct assignment and input statements",
      ],
      paragraphs: [
        "A variable is a named memory location whose value can change during execution; a constant holds a value that does not change. Every variable has a data type that determines the kind of value it can hold and the amount of memory it requires. The common types are integer (whole numbers), floating point (numbers with decimals), character (single symbols), string (sequences of characters) and boolean (true or false).",
        "Operators act on values. Arithmetic operators perform addition, subtraction, multiplication, division and modulus (remainder). Relational operators compare values and give a boolean result: equal to, not equal to, greater than, less than and so on. Logical operators (and, or, not) combine conditions. Assignment operators store a value in a variable, and the increment and decrement operators add or subtract one.",
        "When expressions mix operators, the order of operations matters: parentheses first, then multiplication and division, then addition and subtraction. Type conversion (casting) is needed when different types are combined; in some languages this is done automatically (implicit conversion) while in others the programmer must request it (explicit conversion).",
        "Input and output statements allow the program to communicate with the user. Reading data from the keyboard, processing it and displaying the result is the pattern of almost every beginner program. Care should be taken with formatting output so that it is clear and professional.",
      ],
      keyPoints: [
        "A variable is named memory; a constant never changes.",
        "Types: integer, float, char, string, boolean.",
        "Modulus (%) returns the remainder of a division.",
        "Parentheses control the order of evaluation in an expression.",
      ],
      example: {
        heading: "Worked example — expression evaluation",
        lines: [
          "Evaluate: 2 + 3 * 4 - 6 / 2.",
          "Multiplication and division first: 3 * 4 = 12 and 6 / 2 = 3.",
          "Then addition and subtraction: 2 + 12 - 3 = 11.",
          "Adding parentheses changes the meaning: (2 + 3) * 4 - 6 / 2 = 5 * 4 - 3 = 17.",
        ],
      },
      summary:
        "Variables, types and operators are the building blocks of every program. Understanding precedence and type conversion prevents the most common beginner errors.",
      questions: [
        "Differentiate between a variable and a constant.",
        "What is the output of 17 % 5 and 17 / 5 in integer arithmetic?",
        "Explain implicit and explicit type conversion with examples.",
        "Evaluate 5 + 2 * 3 - 4 / 2.",
      ],
    },
    {
      title: "Control Structures: Selection and Iteration",
      objectives: [
        "use if, if-else and switch statements",
        "write programs using for, while and do-while loops",
        "trace loops and predict their output",
        "avoid the common errors that cause infinite loops",
      ],
      paragraphs: [
        "Control structures change the normal flow of a program. Selection statements choose between alternatives: the simple if statement executes a block only when a condition is true, the if-else statement provides two alternatives, the nested if handles several conditions, and the switch statement chooses one of many cases. Conditions must be written carefully; a common error is using '=' (assignment) where '==' (comparison) is required.",
        "Iteration repeats a block of statements. The for loop is used when the number of repetitions is known, the while loop repeats while a condition remains true and is checked before each iteration, and the do-while loop checks the condition after the body has run at least once. Loops must contain code that moves the condition towards its end, such as incrementing a counter.",
        "Tracing a loop means writing down the values of the variables at each iteration. This is a valuable habit that catches errors before running the program. Students should trace loops with at least three iterations on paper in every exercise.",
        "Infinite loops occur when the loop condition never becomes false. Typical causes include forgetting to update the loop variable, testing the wrong condition or updating it in the wrong direction. Debugging techniques, such as printing intermediate values, help to locate such errors quickly.",
      ],
      keyPoints: [
        "Use '==' for comparison and '=' for assignment.",
        "for loops suit a known number of repetitions; while loops test before each run.",
        "do-while executes the body at least once.",
        "Always update the loop variable to avoid infinite loops.",
      ],
      example: {
        heading: "Worked example — sum of numbers 1 to 10",
        lines: [
          "Set total to 0 and counter to 1.",
          "While counter is less than or equal to 10: add counter to total, then increase counter by 1.",
          "After ten iterations total is 55 and counter is 11, so the loop stops.",
          "The same result is given by the formula n(n + 1)/2 = 10 x 11 / 2 = 55.",
        ],
      },
      summary:
        "Selection and iteration give programs their power. Careful construction and tracing of loops prevents errors and produces reliable code.",
      questions: [
        "Compare the while loop and the do-while loop.",
        "Write a program that prints all even numbers between 1 and 50.",
        "What causes an infinite loop? Give two examples.",
        "Rewrite a nested if statement as a switch statement.",
      ],
    },
    {
      title: "Arrays, Strings, Files and Functions",
      objectives: [
        "declare and use one dimensional arrays",
        "process strings as sequences of characters",
        "read from and write to text files",
        "define functions and pass parameters",
      ],
      paragraphs: [
        "An array is a collection of elements of the same type stored in consecutive memory locations under one name. Each element is identified by an index; in C, C++, Java and Python the first index is 0. Arrays are used to store lists of marks, names or measurements, and they are processed with loops. A two dimensional array represents a table of rows and columns.",
        "A string is a sequence of characters. Programming languages provide functions to find the length of a string, copy one string to another, join strings together, compare them and search for a character or a substring. In some languages strings are immutable, which means that a new string is created whenever a change is made.",
        "Files allow data to be kept after a program finishes. The steps in file processing are opening the file, reading or writing records, and closing the file. Text files can be read line by line and are widely used for configuration and data exchange, while binary files store data in the same form as it is held in memory.",
        "Functions (also called procedures or methods) break a large program into smaller, understandable parts. Each function performs one task, receives input through parameters and returns a result. Good design gives functions clear names, a single responsibility and documented behaviour; this makes programs easier to test and reuse.",
      ],
      keyPoints: [
        "Arrays store many values of the same type; the first index is 0 in C, Java and Python.",
        "Strings can be measured, copied, joined, compared and searched.",
        "File processing: open, read/write, close.",
        "Functions make programs modular, testable and reusable.",
      ],
      example: {
        heading: "Worked example — finding the highest mark",
        lines: [
          "Store the marks in an array called marks[ ] and set highest to the first element.",
          "For each element in the array, if the element is greater than highest, update highest.",
          "After the loop, highest holds the largest value.",
          "For marks 55, 72, 68, 90, 44 the result is 90.",
        ],
      },
      summary:
        "Arrays, strings, files and functions are the practical tools used in every serious program. Mastering them allows the student to write complete, useful applications.",
      questions: [
        "What is an array? Why must all elements have the same type?",
        "Write a function that takes two numbers and returns the larger.",
        "Explain the three steps of file processing.",
        "Write a program that reads 20 scores and prints the highest and the lowest.",
      ],
    },
  ],
  assignments: [
    {
      title: "Programming Fundamentals",
      questions: [
        "Write an algorithm in pseudocode and draw a flowchart for a program that computes the grade of a student from a score between 0 and 100.",
        "Explain the four programming paradigms and give one language associated with each.",
        "Write a program that declares an array of 30 integers and prints the number of negative values in it.",
        "Discuss three common programming errors and explain how each can be avoided.",
      ],
    },
  ],
  glossary: [
    { term: "Algorithm", definition: "A finite, ordered set of steps for solving a problem." },
    { term: "Array", definition: "A collection of same type elements stored under one name." },
    { term: "Bug", definition: "An error in a program that causes it to behave incorrectly." },
    { term: "Constant", definition: "A named value that does not change during execution." },
    { term: "Control structure", definition: "A statement that changes the order in which statements execute." },
    { term: "Debugging", definition: "The process of finding and correcting errors in a program." },
    { term: "Flowchart", definition: "A pictorial representation of an algorithm." },
    { term: "Function", definition: "A named block of code that performs a specific task." },
    { term: "Iteration", definition: "Repeating a block of statements using a loop." },
    { term: "Pseudocode", definition: "Informal, language independent description of an algorithm." },
    { term: "Selection", definition: "Choosing between alternatives using conditions." },
    { term: "String", definition: "A sequence of characters." },
    { term: "Syntax error", definition: "An error caused by breaking the grammar rules of a language." },
    { term: "Variable", definition: "A named memory location whose value can change." },
    { term: "Array index", definition: "The position of an element within an array, starting from 0." },
  ],
  references: [
    "Deitel, P. and Deitel, H. (2020). Java: How to Program. 11th ed. Pearson.",
    "Kernighan, B. W. and Ritchie, D. M. (1988). The C Programming Language. 2nd ed. Prentice Hall.",
    "Sommerville, I. (2015). Software Engineering. 10th ed. Pearson.",
    "Prince Learning Hub (2026). Programming Laboratory Manual. Lagos.",
  ],
};

export const oop: Chapter = {
  id: "oop",
  title: "Object-Oriented Programming and Java",
  tagline: "Modelling the world as objects: classes, encapsulation, inheritance, polymorphism and exceptions.",
  units: [
    {
      title: "Classes, Objects and Encapsulation",
      objectives: [
        "explain the basic concepts of object oriented programming",
        "define classes and create objects",
        "use constructors, methods and access modifiers",
        "apply encapsulation with getters and setters",
      ],
      paragraphs: [
        "Object oriented programming (OOP) models a system as a collection of objects that interact with one another. An object combines state (data) and behaviour (methods). The main ideas are abstraction, encapsulation, inheritance and polymorphism. These ideas help programmers to build systems that are easier to understand, extend and maintain.",
        "A class is a blueprint from which objects are created. It declares attributes (fields) and methods. A constructor is a special method that runs when an object is created and initialises its attributes. In Java, a class is written with the class keyword, and objects are created with the new operator. For example, a Student class may have name, registration number and level, and methods such as registerCourse().",
        "Encapsulation hides the internal details of an object and exposes only what is necessary. This is achieved by declaring attributes as private and providing public getter and setter methods. Encapsulation protects data from accidental change and allows the internal representation to be improved without breaking the code that uses the class.",
        "Access modifiers control visibility. Public members are accessible from anywhere, protected members from the same package and subclasses, private members only within the class, and members with no modifier only within the package. Choosing the correct modifier is part of good design.",
      ],
      keyPoints: [
        "OOP models systems as interacting objects.",
        "A class is a blueprint; an object is an instance of a class.",
        "Constructors initialise objects when they are created.",
        "Encapsulation: private fields with public accessors.",
      ],
      example: {
        heading: "Worked example — a simple class",
        lines: [
          "class Student {",
          "  private String name;",
          "  private int level;",
          "  Student(String name, int level) { this.name = name; this.level = level; }",
          "  String getName() { return name; }",
          "  void setLevel(int level) { this.level = level; }",
          "}",
          "Student s = new Student(\"Amaka\", 200);   // object created and initialised",
        ],
      },
      image: "online-class.jpg",
      imageCaption: "Figure 7.1 — Practical programming and online learning",
      summary:
        "Objects combine data and behaviour, and classes describe them. Encapsulation protects data and keeps code maintainable.",
      questions: [
        "Define a class and an object with examples.",
        "What is a constructor and when is it executed?",
        "Explain how encapsulation improves program maintenance.",
        "Write a class called Book with two attributes and one method.",
      ],
    },
    {
      title: "Inheritance, Polymorphism and Abstraction",
      objectives: [
        "use inheritance to reuse and extend classes",
        "explain method overloading and overriding",
        "apply polymorphism in program design",
        "use abstract classes and interfaces",
      ],
      paragraphs: [
        "Inheritance allows a class (subclass) to acquire the attributes and methods of another class (superclass). It promotes code reuse and models the 'is a' relationship: a Car is a Vehicle. In Java, inheritance is declared with the extends keyword. The super keyword refers to the superclass and is used to call its constructor or methods.",
        "Polymorphism means 'many forms'. Compile time polymorphism (overloading) occurs when several methods in the same class share a name but differ in their parameters. Run time polymorphism (overriding) occurs when a subclass provides its own version of a method that is already defined in the superclass; the correct version is chosen when the program runs.",
        "Abstraction means showing only the essential features while hiding the details. An abstract class may contain abstract methods that have no body and must be completed by subclasses. An interface is a contract that lists methods a class must implement; a class may implement several interfaces even though it can extend only one class.",
        "These ideas are used in large systems to keep code organised. For example, a drawing program may define a Shape interface implemented by Circle, Rectangle and Triangle, so that the drawing code treats all shapes in the same way without knowing their details.",
      ],
      keyPoints: [
        "Inheritance models 'is a' relationships and reuses code.",
        "Overloading is compile time; overriding is run time polymorphism.",
        "An abstract class cannot be instantiated; its subclasses complete its methods.",
        "A class can implement several interfaces but extend only one class.",
      ],
      diagram: "tree",
      example: {
        heading: "Worked example — overriding",
        lines: [
          "class Animal { void speak() { System.out.println(\"The animal makes a sound\"); } }",
          "class Dog extends Animal { void speak() { System.out.println(\"The dog barks\"); } }",
          "Animal a = new Dog(); a.speak();",
          "Output: The dog barks. The version that runs is chosen at run time from the actual object.",
        ],
      },
      summary:
        "Inheritance, polymorphism and abstraction give object oriented programs their flexibility. Together they allow code to be reused and extended with minimal change to existing code.",
      questions: [
        "Differentiate between overloading and overriding.",
        "What is an interface and how does it differ from an abstract class?",
        "Explain how polymorphism is achieved at run time.",
        "Write a class hierarchy for Shape, Circle and Rectangle.",
      ],
    },
    {
      title: "Strings, Arrays, Collections and Generics",
      objectives: [
        "process strings using standard methods",
        "use arrays and multi dimensional arrays",
        "apply the collections framework",
        "explain the benefit of generics",
      ],
      paragraphs: [
        "Strings are objects in Java and are immutable. The String class provides methods such as length(), charAt(), substring(), toUpperCase(), equals() and indexOf(). Because strings cannot be changed, repeated modification is done with the StringBuilder class, which allows efficient building of text.",
        "Arrays store fixed numbers of elements of the same type. An array is created with the new operator and its size is fixed after creation. When the size must change, a collection such as ArrayList is used. A two dimensional array represents a table and is accessed with two indices.",
        "The collections framework provides ready made data structures: ArrayList for a resizable list, LinkedList for frequent insertion and deletion, HashSet for unique elements and HashMap for key value pairs. Each provides methods to add, remove, search and iterate over elements, saving the programmer from writing these structures from scratch.",
        "Generics allow classes and methods to work with any type while keeping compile time safety. A declaration such as List<String> tells the compiler that the list holds strings, so a wrong type cannot be added accidentally and no casting is needed when retrieving elements.",
      ],
      keyPoints: [
        "String objects are immutable; StringBuilder is used for frequent changes.",
        "ArrayList resizes automatically; arrays have a fixed size.",
        "HashSet keeps only unique elements; HashMap stores key value pairs.",
        "Generics provide type safety without casting.",
      ],
      example: {
        heading: "Worked example — using an ArrayList",
        lines: [
          "List<String> names = new ArrayList<>();",
          "names.add(\"Amaka\"); names.add(\"Tunde\"); names.add(\"Amaka\");",
          "System.out.println(names.size());        // prints 3 (list allows duplicates)",
          "System.out.println(names.contains(\"Tunde\")); // prints true",
        ],
      },
      summary:
        "Strings, arrays and collections handle the data of an application. Generics make this data handling safe and easy to read.",
      questions: [
        "Why are String objects described as immutable?",
        "Compare an array with an ArrayList.",
        "Which collection would you use to store student registration numbers without duplicates? Justify your answer.",
        "Explain the benefit of generics with an example.",
      ],
    },
    {
      title: "Exception Handling, Input/Output and GUI Basics",
      objectives: [
        "explain the meaning of exceptions",
        "use try, catch, finally and throw",
        "read from and write to text files",
        "describe the structure of a simple GUI application",
      ],
      paragraphs: [
        "An exception is an unexpected event that interrupts the normal flow of a program, such as division by zero, invalid input or a missing file. Java handles exceptions with try, catch and finally blocks: the code that may cause an error is placed in the try block, the handling code in the catch block, and clean up code in the finally block, which runs whether or not an exception occurred.",
        "Exceptions are of two kinds. Checked exceptions (such as IOException) must be handled or declared, while unchecked exceptions (such as NullPointerException) occur during execution and usually indicate programming errors. The throw statement raises an exception and the throws clause declares that a method may raise one.",
        "Input and output allow programs to work with data outside memory. Classes such as Scanner read from the keyboard or a text file, while PrintWriter and FileWriter write text to files. Files should always be closed after use, and the try with resources statement closes them automatically.",
        "Graphical user interfaces present programs with windows, buttons, text fields and labels. In Java, Swing provides components such as JFrame, JPanel, JButton, JTextField and JLabel. Event handling follows a simple pattern: implement a listener interface, register it on a component, and write the code that responds when the user acts. Event driven programming is the basis of most modern applications.",
      ],
      keyPoints: [
        "try contains risky code, catch handles the error, finally always runs.",
        "Checked exceptions must be handled or declared.",
        "Files are opened, read or written, and closed.",
        "GUI components respond to user actions through event listeners.",
      ],
      example: {
        heading: "Worked example — handling invalid input",
        lines: [
          "try {",
          "  int age = Integer.parseInt(scanner.nextLine());",
          "} catch (NumberFormatException e) {",
          "  System.out.println(\"Please enter a valid number for age.\");",
          "} finally {",
          "  scanner.close();",
          "}",
        ],
      },
      summary:
        "Exception handling keeps programs from crashing, file handling keeps data beyond the life of a program, and GUI programming makes programs pleasant to use.",
      questions: [
        "Differentiate between checked and unchecked exceptions.",
        "What is the purpose of the finally block?",
        "Write code that reads a text file line by line and counts the lines.",
        "Name four Swing components and state their uses.",
      ],
    },
  ],
  assignments: [
    {
      title: "Object Oriented Programming",
      questions: [
        "Design a class Account with attributes for account number and balance, including methods to deposit and withdraw money. Explain how encapsulation is applied.",
        "Explain the four pillars of object oriented programming with a diagram and examples.",
        "Write a Java program that reads five numbers into an ArrayList and prints them in reverse order.",
        "Discuss the benefits of exception handling and demonstrate with code that reads a number and handles invalid input.",
      ],
    },
  ],
  glossary: [
    { term: "Abstract class", definition: "A class that cannot be instantiated and may contain abstract methods." },
    { term: "Attribute", definition: "A variable that holds the state of an object." },
    { term: "Class", definition: "A blueprint for creating objects." },
    { term: "Collection", definition: "A ready made data structure for holding groups of objects." },
    { term: "Constructor", definition: "A special method that initialises a new object." },
    { term: "Encapsulation", definition: "Hiding internal details and exposing controlled access." },
    { term: "Exception", definition: "An event that disrupts the normal flow of a program." },
    { term: "Generic", definition: "A type parameterised class or method that works with any type safely." },
    { term: "Inheritance", definition: "Acquiring the properties of an existing class." },
    { term: "Interface", definition: "A contract listing methods that a class must implement." },
    { term: "Method", definition: "A function defined inside a class." },
    { term: "Object", definition: "An instance of a class with state and behaviour." },
    { term: "Overloading", definition: "Several methods with the same name but different parameters." },
    { term: "Overriding", definition: "Redefining an inherited method in a subclass." },
    { term: "Polymorphism", definition: "One interface taking many forms." },
  ],
  references: [
    "Horstmann, C. S. (2022). Core Java. 12th ed. Prentice Hall.",
    "Barnes, D. and Kolling, M. (2020). Objects First with Java. 6th ed. Pearson.",
    "Oracle (2024). The Java Tutorials: Trail on Object-Oriented Programming.",
    "Prince Learning Hub (2026). OOP in Java: Lecture Slides and Exercises. Lagos.",
  ],
};

export const algo: Chapter = {
  id: "algo",
  title: "Data Structures, Algorithms and Complexity",
  tagline: "Organising data and solving problems efficiently: lists, stacks, queues, trees, graphs and sorting.",
  units: [
    {
      title: "Introduction to Data Structures",
      objectives: [
        "explain what a data structure is and why it is needed",
        "compare linear and non linear data structures",
        "describe arrays and linked lists",
        "choose the right structure for a given problem",
      ],
      paragraphs: [
        "A data structure is a way of organising and storing data so that it can be used efficiently. The choice of structure affects the speed of a program and the amount of memory it uses. Data structures are divided into linear structures, in which elements are arranged in a sequence (arrays, stacks, queues, linked lists), and non linear structures, in which elements are arranged hierarchically or in networks (trees, graphs, heaps).",
        "An array stores elements in consecutive memory locations and provides fast access by index, but inserting or deleting an element requires moving other elements. A linked list stores elements in nodes, each holding data and a reference to the next node. Insertions and deletions are fast once the position is known, but access to the kth element requires following the chain from the beginning.",
        "A stack is a list in which elements are added and removed at one end (the top), following the Last In, First Out rule. Operations are push (add), pop (remove), peek (view the top) and isEmpty. Stacks are used for undo operations, checking balanced brackets and for function calls.",
        "A queue is a list in which elements are added at the rear and removed from the front, following the First In, First Out rule. Operations are enqueue and dequeue. Queues are used for job scheduling, printer spooling and breadth first search. A circular queue and a priority queue are common variations.",
      ],
      keyPoints: [
        "Data structures may be linear or non linear.",
        "Arrays give fast indexed access; linked lists give fast insertion and deletion.",
        "Stack: LIFO with push and pop; Queue: FIFO with enqueue and dequeue.",
        "Choose a structure to suit the operations your program performs most often.",
      ],
      table: {
        caption: "Table 6.1 — Comparison of basic structures",
        headers: ["Structure", "Access", "Insertion", "Deletion", "Typical use"],
        rows: [
          ["Array", "O(1) by index", "O(n)", "O(n)", "Fixed lists, tables"],
          ["Linked list", "O(n)", "O(1) at head", "O(1) at head", "Dynamic lists"],
          ["Stack", "O(1) at top", "O(1)", "O(1)", "Undo, function calls"],
          ["Queue", "O(1) at front", "O(1)", "O(1)", "Scheduling, printing"],
        ],
      },
      summary:
        "Data structures organise data for efficient use. Arrays, linked lists, stacks and queues each suit particular operations, and selecting the right one is a key design decision.",
      questions: [
        "Differentiate between linear and non linear data structures.",
        "Compare an array and a linked list.",
        "Explain the operations of a stack and give two applications.",
        "Which data structure is best for a printer queue? Justify your answer.",
      ],
    },
    {
      title: "Trees, Graphs and Searching",
      objectives: [
        "describe trees and their terminology",
        "explain binary search trees and their traversals",
        "describe graphs and their representations",
        "apply linear search and binary search",
      ],
      paragraphs: [
        "A tree is a hierarchical structure made of nodes connected by edges. The top node is the root, nodes with no children are leaves, and the depth of a node is the number of edges from the root. A binary tree has at most two children per node. A binary search tree keeps smaller values in the left subtree and larger values in the right, which makes searching efficient.",
        "Trees are traversed in three standard ways. In-order traversal visits the left subtree, the root and then the right subtree, and for a binary search tree it produces values in ascending order. Pre-order visits root, left, right; post-order visits left, right, root. Binary heaps, expression trees and organisational charts are common examples of trees.",
        "A graph is a set of vertices connected by edges and is used to model networks such as roads, computer networks and social relationships. Graphs may be directed or undirected, weighted or unweighted. They are stored using an adjacency matrix or an adjacency list. Breadth first search explores level by level using a queue, while depth first search goes as deep as possible using a stack or recursion.",
        "Searching is the process of finding a target in a data structure. Linear search checks each element in turn and works on any list, taking up to n comparisons. Binary search works only on sorted lists and repeatedly halves the search area, taking about log2(n) comparisons. For one million items, binary search needs at most twenty comparisons while linear search may need one million.",
      ],
      keyPoints: [
        "A binary search tree keeps smaller values left and larger values right.",
        "In-order traversal of a BST gives sorted values.",
        "BFS uses a queue; DFS uses a stack or recursion.",
        "Binary search needs a sorted list and runs in O(log n).",
      ],
      diagram: "tree",
      example: {
        heading: "Worked example — binary search",
        lines: [
          "Sorted list: 2, 5, 8, 12, 16, 23, 38, 56. Find 23.",
          "Step 1: middle is 12. 23 is greater, so search the right half.",
          "Step 2: middle of 16, 23, 38, 56 is 38. 23 is smaller, so search the left part.",
          "Step 3: middle of 16, 23 is 16. 23 is greater; the next value is 23. Found after 4 steps.",
        ],
      },
      image: "computers-library.jpg",
      imageCaption: "Figure 8.2 — Organising data for efficient access",
      summary:
        "Trees and graphs model hierarchical and networked data, while searching algorithms retrieve information quickly. Binary search is only possible when the data is sorted.",
      questions: [
        "Define a binary search tree and state its key property.",
        "List the three tree traversals and give the result of each on a small tree.",
        "Differentiate between breadth first and depth first search.",
        "How many comparisons does binary search need at most for a list of 1,024 items?",
      ],
    },
    {
      title: "Sorting and Algorithm Efficiency",
      objectives: [
        "explain the operation of common sorting algorithms",
        "compare sorting algorithms by time complexity",
        "explain big-O notation",
        "analyse the efficiency of a simple algorithm",
      ],
      paragraphs: [
        "Sorting arranges data in order and is one of the most studied problems in computing. Bubble sort repeatedly compares and swaps adjacent elements; it is simple but slow for large data. Selection sort repeatedly selects the smallest element and places it at the front. Insertion sort builds a sorted list one element at a time and is fast for nearly sorted data. Merge sort divides the list in halves and merges them, and quick sort partitions the list around a pivot.",
        "The efficiency of an algorithm is measured by the number of operations it performs as the input grows. Big-O notation describes the upper bound of this growth. O(1) is constant time, O(log n) is logarithmic, O(n) is linear, O(n log n) is linearithmic and O(n squared) is quadratic. An algorithm with O(n squared) becomes impractical for large inputs.",
        "Bubble sort and selection sort have O(n squared) time complexity in the worst case, while merge sort and heap sort run in O(n log n). No comparison based sort can be faster than O(n log n) in the worst case. Counting sort and radix sort are faster for particular kinds of data because they do not compare elements.",
        "Space complexity is also important. Merge sort requires extra memory for merging, while heap sort sorts in place. The programmer must balance speed, memory use and simplicity when choosing an algorithm.",
      ],
      keyPoints: [
        "Bubble and selection sort: O(n^2); merge and heap sort: O(n log n).",
        "Big-O describes how running time grows with input size.",
        "Comparison based sorting cannot beat O(n log n).",
        "Consider both time and space complexity.",
      ],
      table: {
        caption: "Table 6.2 — Sorting algorithms compared",
        headers: ["Algorithm", "Best case", "Worst case", "Space", "Stable"],
        rows: [
          ["Bubble sort", "O(n)", "O(n^2)", "O(1)", "Yes"],
          ["Selection sort", "O(n^2)", "O(n^2)", "O(1)", "No"],
          ["Insertion sort", "O(n)", "O(n^2)", "O(1)", "Yes"],
          ["Merge sort", "O(n log n)", "O(n log n)", "O(n)", "Yes"],
          ["Quick sort", "O(n log n)", "O(n^2)", "O(log n)", "No"],
        ],
      },
      example: {
        heading: "Worked example — bubble sort trace",
        lines: [
          "Sort 5, 3, 8, 1 in ascending order.",
          "Pass 1: compare (5,3) swap → 3,5,8,1; (5,8) no swap; (8,1) swap → 3,5,1,8.",
          "Pass 2: (3,5) no swap; (5,1) swap → 3,1,5,8; end of pass 2.",
          "Pass 3: (3,1) swap → 1,3,5,8. The list is now sorted after three passes.",
        ],
      },
      summary:
        "Sorting and complexity analysis are central to algorithm design. Choosing an efficient algorithm can make the difference between a program that responds in seconds and one that never finishes.",
      questions: [
        "Trace bubble sort on the list 4, 2, 7, 1.",
        "Explain big-O notation and give an example of each of O(1), O(n) and O(n^2).",
        "Compare merge sort and quick sort.",
        "Why is binary search faster than linear search?",
      ],
    },
    {
      title: "Recursion, Hashing and Graph Algorithms",
      objectives: [
        "explain recursion and write recursive algorithms",
        "describe hash tables and collision handling",
        "explain spanning trees and shortest path problems",
        "apply divide and conquer strategies",
      ],
      paragraphs: [
        "Recursion is a technique in which a function calls itself to solve smaller versions of the same problem. Every recursive function must have a base case that stops the recursion and a recursive case that reduces the problem. Examples include factorial, Fibonacci numbers, binary search and tree traversals. Recursion often produces elegant code, though it uses more memory because each call occupies space on the call stack.",
        "A hash table stores data as key value pairs and finds an item by computing its position with a hash function. Access takes constant time on average. When two keys hash to the same location, a collision occurs; it is resolved by chaining (storing a list at that location) or by open addressing (probing for the next free slot). Hash tables are used for symbol tables, dictionaries and caches.",
        "A spanning tree of a graph connects all vertices with the minimum number of edges and no cycles. A minimum spanning tree has the smallest total edge weight and is found using Kruskal's or Prim's algorithm. The shortest path problem finds the cheapest route between two vertices; Dijkstra's algorithm solves it for graphs with non negative weights.",
        "Divide and conquer is a strategy that breaks a problem into smaller subproblems, solves each one and combines the results. Merge sort and quick sort are classic examples. Understanding these patterns allows the programmer to design efficient solutions rather than relying on brute force.",
      ],
      keyPoints: [
        "Recursion needs a base case and a reducing recursive case.",
        "Hash tables give average O(1) access and resolve collisions by chaining or probing.",
        "A minimum spanning tree connects all vertices at minimum cost.",
        "Dijkstra's algorithm finds shortest paths with non negative weights.",
      ],
      example: {
        heading: "Worked example — recursive factorial",
        lines: [
          "factorial(n) = 1 if n <= 1, otherwise n x factorial(n - 1).",
          "factorial(5) = 5 x factorial(4) = 5 x 4 x factorial(3) = 5 x 4 x 3 x 2 x 1 = 120.",
          "Each call waits for the next to return, so five stack frames are used.",
          "The base case (n <= 1) stops the recursion; without it the program would run out of memory.",
        ],
      },
      summary:
        "Recursion, hashing and graph algorithms extend the programmer's toolkit. They are the basis of many practical systems, from compilers to route planning.",
      questions: [
        "What is the base case in a recursive function?",
        "Explain how a hash table resolves collisions.",
        "Compare Kruskal's and Prim's algorithms.",
        "Write a recursive function to compute the nth Fibonacci number.",
      ],
    },
  ],
  assignments: [
    {
      title: "Data Structures and Algorithms",
      questions: [
        "Compare arrays, linked lists, stacks and queues in a table, stating the operations supported and one application of each.",
        "Trace binary search on the sorted list 2, 4, 7, 11, 15, 19, 24, 28 to find 11, and state the number of comparisons made.",
        "Explain big-O notation and analyse the time complexity of an algorithm with a loop inside a loop.",
        "Implement bubble sort and merge sort for a list of ten numbers and compare the number of comparisons each makes.",
      ],
    },
  ],
  glossary: [
    { term: "Adjacency list", definition: "A compact representation of a graph as lists of neighbours." },
    { term: "Algorithm analysis", definition: "The study of the time and space an algorithm needs." },
    { term: "Base case", definition: "The condition that stops a recursive function." },
    { term: "Big-O", definition: "Notation describing the upper bound of an algorithm's growth." },
    { term: "Binary search", definition: "Search on sorted data by repeatedly halving the range." },
    { term: "Binary tree", definition: "A tree in which each node has at most two children." },
    { term: "Collision", definition: "Two keys hashing to the same location in a hash table." },
    { term: "Graph", definition: "Vertices connected by edges, used to model networks." },
    { term: "Hash function", definition: "A function that maps a key to a location in a hash table." },
    { term: "Linked list", definition: "A chain of nodes, each pointing to the next." },
    { term: "Queue", definition: "A FIFO structure with enqueue and dequeue." },
    { term: "Recursion", definition: "A function that calls itself to solve smaller problems." },
    { term: "Root", definition: "The top node of a tree." },
    { term: "Stack", definition: "A LIFO structure with push and pop." },
    { term: "Traversal", definition: "Visiting every node of a tree or graph in a defined order." },
  ],
  references: [
    "Cormen, T. H., Leiserson, C. E., Rivest, R. L. and Stein, C. (2022). Introduction to Algorithms. 4th ed. MIT Press.",
    "Goodrich, M. T., Tamassia, R. and Goldwasser, M. H. (2014). Data Structures and Algorithms in Java. Wiley.",
    "Knuth, D. E. (1997). The Art of Computer Programming, Volume 3: Sorting and Searching. Addison-Wesley.",
    "Prince Learning Hub (2026). Algorithms: Tracing Workbook. Lagos.",
  ],
};
