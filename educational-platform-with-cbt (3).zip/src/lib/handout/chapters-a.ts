import type { Chapter } from "./pdf-handout";

export const computing: Chapter = {
  id: "computing",
  title: "Fundamentals of Computing and Information Processing",
  tagline: "How computing devices work, where they came from, and what they do in society today.",
  units: [
    {
      title: "Meaning, History and Generations of Computers",
      objectives: [
        "define a computer and explain the data processing cycle",
        "trace the development of computing devices from the abacus to modern machines",
        "describe the five generations of computers and the technology behind each",
        "explain the stored program concept and why it matters",
      ],
      paragraphs: [
        "A computer is an electronic device that accepts data (input), processes it under the control of a set of stored instructions called a program, stores the result, and produces information (output). Data consists of raw facts such as numbers, names and dates. Information is data that has been processed into a form that is useful for making decisions. The ability to convert data into information quickly and accurately is what makes a computer valuable in every field of human endeavour.",
        "Computing did not begin with electronic machines. The abacus, used thousands of years ago, helped traders perform arithmetic. Blaise Pascal built the Pascaline in 1642 for addition and subtraction, and Gottfried Leibniz extended it to multiplication and division. In the nineteenth century, Charles Babbage designed the Difference Engine and the Analytical Engine, and Ada Lovelace wrote instructions for the Analytical Engine, which is why she is remembered as the first computer programmer. Herman Hollerith later used punched cards to process the 1890 United States census.",
        "Electronic computers are grouped into five generations. First generation machines (1940s) used vacuum tubes and were large, hot and unreliable; ENIAC and UNIVAC belong to this group. Second generation machines used transistors and became smaller and cheaper. Third generation machines used integrated circuits. Fourth generation machines are built around the microprocessor, which placed a complete processor on a single chip and produced the personal computer. Fifth generation machines are characterised by artificial intelligence, parallel processing and natural interaction with users.",
        "The stored program concept, attributed to John von Neumann, means that both the instructions of a program and the data it uses are kept in the same memory. Before this idea, computers had to be rewired physically for every new task. Because a program can be loaded from storage and changed without altering the hardware, the modern computer is a general purpose machine that can be used for accounting, design, communication, medicine, entertainment and education.",
      ],
      keyPoints: [
        "Data is raw facts; information is processed data.",
        "The processing cycle is input → processing → output, with storage at every stage.",
        "Charles Babbage is called the father of the computer; Ada Lovelace was the first programmer.",
        "Vacuum tubes → transistors → integrated circuits → microprocessors → artificial intelligence.",
        "The stored program concept allows software to be changed without changing hardware.",
      ],
      table: {
        caption: "Table 1.1 — The five generations of computers",
        headers: ["Generation", "Period", "Technology", "Example"],
        rows: [
          ["First", "1940–1956", "Vacuum tubes", "ENIAC, UNIVAC"],
          ["Second", "1956–1963", "Transistors", "IBM 1401"],
          ["Third", "1964–1971", "Integrated circuits", "IBM System/360"],
          ["Fourth", "1971–present", "Microprocessors", "Personal computers"],
          ["Fifth", "Present", "Artificial intelligence", "Robots, expert systems"],
        ],
      },
      example: {
        heading: "Worked example — the data processing cycle",
        lines: [
          "A bank records the money you deposit (input). The system adds it to your account balance and calculates the new balance (processing).",
          "It prints a receipt (output) and stores the transaction in the bank's database (storage).",
          "Notice that the receipt (output) becomes data for your personal records, which shows that output can be reused as input.",
        ],
      },
      summary:
        "A computer converts data into information using the processing cycle. Its development from mechanical calculators to intelligent machines prepared the way for the general purpose, stored program devices we use today.",
      questions: [
        "Differentiate between data and information with two examples of each.",
        "List the five generations of computers and the technology that defines each.",
        "What is the stored program concept and who proposed it?",
        "Explain why Ada Lovelace is regarded as the first computer programmer.",
      ],
    },
    {
      title: "Computer Components, Hardware, Software and Humanware",
      objectives: [
        "identify the four major components of a computer system",
        "classify input, output, processing and storage devices",
        "distinguish between system software and application software",
        "explain the role of humanware (liveware) in a computer system",
      ],
      paragraphs: [
        "A complete computer system is made up of hardware, software, data, procedures and people. Hardware refers to the physical parts that can be touched, such as the monitor, keyboard, system unit and printer. Software is the set of programs and instructions that tells the hardware what to do. Humanware (also called liveware) describes the people who operate, program and maintain the system; without trained users, the best hardware and software are of little value.",
        "Hardware is grouped by function. Input devices (keyboard, mouse, scanner, microphone, barcode reader) accept data from the user. The processing unit, the Central Processing Unit, contains the Arithmetic Logic Unit which performs calculations and comparisons, the Control Unit which directs the operation of the system, and small high speed memories called registers. Storage is classified into primary storage (RAM and ROM, inside the system unit) and secondary storage (hard disks, flash drives, optical discs). Output devices (monitor, printer, projector, speakers) present results to the user.",
        "Software is divided into system software and application software. System software includes the operating system, device drivers and utility programs that control the computer and provide services to other programs. Application software performs the tasks the user cares about: word processing, spreadsheets, presentations, database management, graphics and communication. A third category, firmware, is software permanently stored in hardware, such as the BIOS program that starts the computer when it is switched on.",
        "A peripheral is any device connected to the computer but not part of its core processing unit. When buying or building a computer, the user must consider compatibility between components, the purpose of the machine, and the cost. A machine used for graphic design, for example, needs more memory and a stronger graphics processor than one used mainly for typing.",
      ],
      keyPoints: [
        "Computer system = hardware + software + data + procedures + people.",
        "The CPU has two main parts: the ALU and the Control Unit.",
        "RAM is volatile working memory; ROM is non-volatile and holds start-up instructions.",
        "System software controls the machine; application software solves user problems.",
        "Peripherals are input, output or storage devices attached to the computer.",
      ],
      image: "computers-library.jpg",
      imageCaption: "Figure 1.1 — Students working on networked computers in a university library",
      example: {
        heading: "Worked example — identifying components",
        lines: [
          "Question: Classify the following as input, output or storage: printer, scanner, hard disk, monitor, flash drive, microphone.",
          "Answer: Input = scanner, microphone. Output = printer, monitor. Storage = hard disk, flash drive.",
          "Reasoning: ask what the device does in the processing cycle — it accepts data (input), presents results (output) or keeps data for later use (storage).",
        ],
      },
      summary:
        "A computer system is the combination of hardware, software and the people who use them. Understanding the function of each component is the first step towards using a computer effectively.",
      questions: [
        "Define hardware and software, giving two examples of each.",
        "Name the two main components of the CPU and state one function of each.",
        "Differentiate between primary and secondary storage.",
        "Explain the term humanware and state why it is important.",
      ],
    },
    {
      title: "Types of Computers and Their Applications",
      objectives: [
        "classify computers by size, purpose and method of processing",
        "compare microcomputers, minicomputers, mainframes and supercomputers",
        "give examples of embedded and special purpose computers",
        "identify the diverse applications of computers in society",
      ],
      paragraphs: [
        "Computers may be classified in several ways. By the type of data they handle, they are analog (processing continuous quantities such as temperature), digital (processing discrete numbers and characters) or hybrid (combining both). By size and processing power, they are microcomputers, minicomputers, mainframes and supercomputers. By purpose, they are general purpose machines that can run many kinds of programs, or special purpose machines built for a single task.",
        "Microcomputers are small, inexpensive machines designed for individual use; desktop computers, laptops, tablets and smartphones fall into this group. Minicomputers are mid range machines used by medium sized organisations. Mainframes are large, powerful computers that support hundreds of users at the same time and handle very large volumes of transactions, such as those processed by banks and government agencies. Supercomputers are the fastest machines available and are used for weather forecasting, scientific simulation, nuclear research and space exploration.",
        "An embedded computer is a processor built into another device to control it. Examples include the computer inside a microwave oven, a washing machine, a car engine control unit, an ATM and a traffic light. The user rarely sees such computers, yet they perform many of the tasks that make modern life convenient and safe.",
        "The applications of computers are endless. In education they support online learning, research and computer based tests. In medicine they store patient records and control diagnostic equipment. In banking they process transactions and provide electronic payment. In agriculture, science, entertainment, communication and government, computers save time, reduce errors and increase productivity. Understanding these applications helps the student to see computing as a discipline with many career paths, including programming, networking, hardware engineering, database administration and information systems analysis.",
      ],
      keyPoints: [
        "Analog processes continuous data; digital processes discrete data; hybrid combines both.",
        "Supercomputers are the most powerful; microcomputers are the most common.",
        "Embedded computers control everyday devices such as cars and traffic lights.",
        "Computers are applied in education, medicine, banking, agriculture, science and government.",
      ],
      table: {
        caption: "Table 1.2 — Comparison of computers by size",
        headers: ["Type", "Users served", "Typical use", "Example"],
        rows: [
          ["Supercomputer", "Many (very fast)", "Weather, research", "Frontier, Fugaku"],
          ["Mainframe", "Hundreds", "Bank transactions", "IBM zSeries"],
          ["Minicomputer", "Tens", "Departmental work", "PDP-8"],
          ["Microcomputer", "One or a few", "Personal work", "Desktop, laptop, tablet"],
          ["Embedded", "Device control", "Cars, ATMs, ovens", "Microcontrollers"],
        ],
      },
      summary:
        "Computers range from tiny embedded controllers to powerful supercomputers, and they are used in nearly every area of human activity. The classification of a computer depends on its size, purpose and the type of data it processes.",
      questions: [
        "Differentiate between analog, digital and hybrid computers.",
        "Compare a mainframe and a microcomputer in terms of size, cost and users served.",
        "What is an embedded computer? Give three examples.",
        "State four applications of computers in the Nigerian economy.",
      ],
    },
    {
      title: "Information Processing, the Internet and Computing Careers",
      objectives: [
        "explain the role of information processing in society",
        "describe the Internet, its services and its impact",
        "identify the areas of the computing discipline",
        "outline the job specialisations available to computing professionals",
      ],
      paragraphs: [
        "Information processing is the collection, organisation, storage and distribution of data to support decision making. Organisations that process information well respond faster to customers, reduce waste and plan more accurately. The speed and reliability of modern information processing have changed how governments deliver services, how businesses reach customers and how schools teach students. With this power comes responsibility: information must be accurate, protected and used ethically.",
        "The Internet is a worldwide network of computers that communicate using a common set of rules called TCP/IP. It offers services such as electronic mail, the World Wide Web, file transfer, online banking, e-commerce, e-learning, video conferencing and social networking. Its impact is enormous: information that once took days to find is now available in seconds, and people can work, trade and study across borders. The negative effects include cybercrime, fraud, privacy loss, distraction and the spread of false information.",
        "The computing discipline is broad. Computer science focuses on theory, algorithms and programming. Computer engineering combines electrical engineering with computing to design hardware. Software engineering applies engineering principles to build reliable software. Information systems concentrates on using technology to support organisations, while information technology focuses on installing and managing systems. Cybersecurity, data science, artificial intelligence and network engineering are growing specialisations within these areas.",
        "Computing professionals work as programmers, systems analysts, database administrators, network engineers, web developers, hardware technicians, security analysts, project managers and researchers. A good professional keeps learning, because the technology changes quickly. Practical skills, sound theory, communication ability and ethical conduct together build a successful career in computing.",
      ],
      keyPoints: [
        "Information processing supports planning, control and decision making.",
        "The Internet connects the world using TCP/IP and provides web, email and e-commerce.",
        "Computing areas include computer science, computer engineering, software engineering and information systems.",
        "Careers include programming, networking, databases, security and systems analysis.",
      ],
      example: {
        heading: "Example — information processing in a hospital",
        lines: [
          "Input: patient name, symptoms and test results entered by the nurse.",
          "Processing: the system matches symptoms against records and calculates charges.",
          "Output: prescription and bill printed for the patient.",
          "Storage: the record is saved for future visits and for hospital management reports.",
        ],
      },
      summary:
        "Computing has become essential to modern society. Understanding information processing, the Internet and the branches of the discipline helps the student to choose a career path and to use technology responsibly.",
      questions: [
        "What is information processing? State three benefits to an organisation.",
        "List five services provided by the Internet.",
        "Give two positive and two negative effects of the Internet on society.",
        "Describe three career areas open to a graduate of computing.",
      ],
    },
  ],
  assignments: [
    {
      title: "Fundamentals of Computing",
      questions: [
        "With the aid of a diagram, describe the data processing cycle and give a practical example from a bank or a school.",
        "Compare the five generations of computers in a table, stating the technology, size, cost and one machine from each generation.",
        "Write short notes on: (a) embedded computer (b) firmware (c) humanware (d) peripheral.",
        "Discuss five ways the Internet has changed education in Nigeria, and mention two problems it has introduced.",
      ],
    },
  ],
  glossary: [
    { term: "Abacus", definition: "A manual counting device made of beads on rods, used for arithmetic." },
    { term: "ALU", definition: "The Arithmetic Logic Unit of the CPU that performs calculations and comparisons." },
    { term: "Application software", definition: "Programs that help users perform specific tasks such as typing or accounting." },
    { term: "Computer", definition: "An electronic device that accepts, processes, stores data and produces information." },
    { term: "Data", definition: "Raw facts and figures that have not yet been processed." },
    { term: "Embedded computer", definition: "A processor built into a device to control its functions." },
    { term: "Firmware", definition: "Software permanently stored in hardware, such as the BIOS." },
    { term: "Hardware", definition: "The physical, touchable parts of a computer system." },
    { term: "Humanware", definition: "The people who operate, program and maintain computer systems." },
    { term: "Information", definition: "Data that has been processed into a meaningful and useful form." },
    { term: "Internet", definition: "A global network of networks that communicate using TCP/IP." },
    { term: "Mainframe", definition: "A large computer that supports hundreds of simultaneous users." },
    { term: "Peripheral", definition: "An input, output or storage device attached to a computer." },
    { term: "Software", definition: "Programs and instructions that tell hardware what to do." },
    { term: "Stored program concept", definition: "The idea that instructions and data are held in the same memory." },
    { term: "Supercomputer", definition: "The fastest and most powerful class of computer." },
  ],
  references: [
    "Stallings, W. (2021). Computer Organization and Architecture. 11th ed. Pearson.",
    "Sinclair, I. (2018). Computers: A Very Short Introduction. Oxford University Press.",
    "National Universities Commission (2024). Benchmark Minimum Academic Standards for Computing Programmes.",
    "Prince Learning Hub (2026). CSC 101 Video Lecture Series. Lagos.",
  ],
};

export const datarep: Chapter = {
  id: "datarep",
  title: "Data Representation and Number Systems",
  tagline: "How numbers, text, images and sound are stored and manipulated inside the computer.",
  units: [
    {
      title: "Number Systems and Conversions",
      objectives: [
        "describe the binary, octal, decimal and hexadecimal number systems",
        "convert between base 10 and other bases",
        "perform arithmetic in binary",
        "explain why computers use the binary system",
      ],
      paragraphs: [
        "A number system is a method of representing quantities using a set of digits and a base (radix). The decimal system uses ten digits (0–9) and has base 10. The binary system uses two digits (0 and 1) and has base 2; it is used by computers because the two digits can be represented easily by the two states of an electronic switch, on and off. The octal system (base 8) and the hexadecimal system (base 16) are used as shorthand for binary because they are more compact.",
        "To convert a decimal number to binary, divide repeatedly by 2 and read the remainders from bottom to top. To convert from binary to decimal, multiply each digit by the power of 2 indicated by its position and add the results. Octal numbers are converted by grouping binary digits in threes, while hexadecimal numbers are converted by grouping binary digits in fours. The hexadecimal digits are 0 to 9 and A to F, where A = 10, B = 11 up to F = 15.",
        "Binary arithmetic follows four simple rules for addition: 0 + 0 = 0, 0 + 1 = 1, 1 + 0 = 1 and 1 + 1 = 10 (which is 0 with a carry of 1). Subtraction uses the borrow method in the same way as decimal subtraction. Understanding these operations is important because all arithmetic performed by the computer, including addition of large numbers and calculations in spreadsheets, is carried out in binary by the processor.",
        "Students should practise conversions until they are automatic. Speed and accuracy with number systems are examined in nearly every first year computing course, and the same skills are used later when working with memory addresses, network addresses and colour codes in web design.",
      ],
      keyPoints: [
        "Binary (base 2) is used because electronic switches have two states.",
        "Octal groups binary digits in threes; hexadecimal groups them in fours.",
        "Hexadecimal digits are 0–9 and A–F (A = 10 … F = 15).",
        "1 KB = 1,024 bytes; 1 MB = 1,024 KB; 1 GB = 1,024 MB.",
      ],
      example: {
        heading: "Worked example — decimal 45 to binary and hexadecimal",
        lines: [
          "Divide by 2 repeatedly: 45 ÷ 2 = 22 r1; 22 ÷ 2 = 11 r0; 11 ÷ 2 = 5 r1; 5 ÷ 2 = 2 r1; 2 ÷ 2 = 1 r0; 1 ÷ 2 = 0 r1.",
          "Reading the remainders upwards gives 45 (decimal) = 101101 (binary).",
          "Group the binary digits in fours from the right: 0010 1101 = 2 and D, so 45 (decimal) = 2D (hexadecimal).",
          "Check: 2 × 16 + 13 = 45. The answer is correct.",
        ],
      },
      summary:
        "Number systems are the language in which data is represented inside the computer. Conversion between decimal, binary, octal and hexadecimal is a basic skill for every computing student.",
      questions: [
        "Convert 156 (decimal) to binary and to hexadecimal.",
        "Convert 1101101 (binary) to decimal.",
        "Explain why the binary system is used in computers.",
        "Perform the binary addition 1011 + 1101.",
      ],
    },
    {
      title: "Representation of Text, Numbers and Characters",
      objectives: [
        "explain how characters are encoded using ASCII and Unicode",
        "describe fixed point and floating point number representation",
        "distinguish between integers and real numbers in computing",
        "explain the meaning of precision and rounding errors",
      ],
      paragraphs: [
        "Computers store characters using codes that assign a number to each symbol. The American Standard Code for Information Interchange (ASCII) uses 7 bits and can represent 128 characters, including uppercase and lowercase letters, digits and punctuation. Extended ASCII uses 8 bits and can represent 256 characters. Unicode uses 16 bits or more and can represent characters from almost every writing system in the world, which makes it suitable for multilingual software.",
        "Whole numbers (integers) are stored in binary form, usually in one or more bytes. Negative numbers may be represented using sign and magnitude, one's complement or two's complement. In two's complement, the most significant bit indicates the sign and the value is obtained by inverting the bits of the positive number and adding one. Real numbers with fractional parts are stored in floating point form, which is similar to scientific notation and consists of a mantissa and an exponent.",
        "Because the space available for storing a number is limited, rounding errors can occur when very large or very precise values are used. This is why a calculator may show 0.3333333 for one third, and why software used for engineering and finance must handle precision carefully. The number of bits used to store a value determines its precision and the range of values it can hold.",
        "Computers also represent sound and images digitally. Sound is captured by sampling the sound wave thousands of times per second and storing the amplitude of each sample. Images are stored as a grid of picture elements (pixels), each described by numbers giving its colour and brightness. Text, numbers, sound and images are therefore all reduced to binary digits inside the computer.",
      ],
      keyPoints: [
        "ASCII uses 7 bits (128 characters); Unicode supports most world languages.",
        "Integers are stored in binary; negative integers use two's complement.",
        "Floating point numbers use a mantissa and an exponent.",
        "Sound is sampled; images are stored as pixels; both become binary.",
      ],
      table: {
        caption: "Table 2.1 — Common character codes",
        headers: ["Code", "Bits", "Capacity", "Use"],
        rows: [
          ["ASCII", "7", "128 characters", "Basic English text"],
          ["Extended ASCII", "8", "256 characters", "European languages"],
          ["Unicode", "16+", "Over 140,000 characters", "Multilingual software"],
          ["BCD", "4 per digit", "10 digits", "Calculators, finance"],
        ],
      },
      example: {
        heading: "Worked example — representing the letter 'A'",
        lines: [
          "In ASCII, the capital letter A has the code 65 (decimal).",
          "Converting 65 to binary: 64 + 1 = 1000001.",
          "Stored in 8 bits the code is 01000001.",
          "A lowercase 'a' has the code 97 (01100001), which shows that upper and lower case are stored as different codes.",
        ],
      },
      summary:
        "All data inside a computer is stored as binary digits. Character codes, integer formats and floating point representation allow text and numbers to be processed accurately, while sound and images are converted to numbers before storage.",
      questions: [
        "State two differences between ASCII and Unicode.",
        "Convert 75 to an 8 bit binary number.",
        "What is two's complement and why is it used?",
        "Explain how a photograph is stored in a computer.",
      ],
    },
    {
      title: "Logic Gates and Boolean Algebra",
      objectives: [
        "state the basic logic gates and their truth tables",
        "apply the laws of Boolean algebra",
        "combine gates to build simple logic circuits",
        "explain how logic gates relate to binary arithmetic",
      ],
      paragraphs: [
        "Digital computers process binary data using electronic circuits called logic gates. The three basic gates are AND, OR and NOT. An AND gate produces 1 only when all its inputs are 1. An OR gate produces 1 when at least one input is 1. A NOT gate (inverter) produces the opposite of its input. The combination of these basic gates gives the compound gates NAND, NOR, XOR and XNOR, which are used to build the arithmetic circuits inside the processor.",
        "Boolean algebra, developed by George Boole, provides the rules for working with binary variables. The main laws include the identity law (A + 0 = A, A · 1 = A), the commutative law, the associative law, the distributive law and De Morgan's theorems, which state that the complement of a product equals the sum of the complements and vice versa. These laws allow a circuit to be simplified, reducing the number of gates required and lowering the cost and power consumption of the hardware.",
        "A truth table lists every possible combination of inputs and the resulting output. It is the standard way of describing the behaviour of a gate or a circuit and is used both in examinations and in practical design work. Students should be able to build truth tables for circuits of two or three inputs without difficulty.",
        "Logic gates are combined to form half adders and full adders, which perform binary addition, and to form flip-flops, which store a single bit of memory. In this way, simple gates form the building blocks of the entire processor and memory system.",
      ],
      keyPoints: [
        "AND gives 1 when all inputs are 1; OR gives 1 when any input is 1; NOT inverts the input.",
        "NAND and NOR are universal gates.",
        "De Morgan: (A · B)' = A' + B' and (A + B)' = A' · B'.",
        "Half adders and full adders perform binary addition inside the processor.",
      ],
      table: {
        caption: "Table 2.2 — Truth table of the basic gates",
        headers: ["A", "B", "AND", "OR", "XOR"],
        rows: [
          ["0", "0", "0", "0", "0"],
          ["0", "1", "0", "1", "1"],
          ["1", "0", "0", "1", "1"],
          ["1", "1", "1", "1", "0"],
        ],
      },
      example: {
        heading: "Worked example — simplifying a logic expression",
        lines: [
          "Simplify: F = A · B + A · B'.",
          "Factor out A: F = A · (B + B').",
          "Since B + B' = 1, we get F = A · 1 = A.",
          "The circuit therefore needs only a wire from A, saving two AND gates and an OR gate.",
        ],
      },
      summary:
        "Logic gates are the physical implementation of Boolean algebra. Mastering truth tables and the laws of Boolean algebra is essential for understanding how the processor carries out arithmetic and logical operations.",
      questions: [
        "Draw the symbol and truth table of the NOR gate.",
        "Simplify the expression A + A · B.",
        "State De Morgan's two theorems.",
        "Explain why NAND is called a universal gate.",
      ],
    },
    {
      title: "Storage of Multimedia and Data Compression",
      objectives: [
        "explain how sound and video are represented digitally",
        "describe the principles of data compression",
        "distinguish between lossy and lossless compression",
        "estimate the storage requirement of a digital image or sound file",
      ],
      paragraphs: [
        "Digital sound is produced by sampling an analog sound wave at regular intervals. The quality of the recording depends on the sampling rate (samples per second) and the sample resolution (bits per sample). A standard audio CD uses 44,100 samples per second with 16 bits for each of two channels. Digital video is a rapid sequence of images together with sound, and it produces very large files unless compression is applied.",
        "Data compression reduces the size of data so that it occupies less storage space and takes less time to transmit. Lossless compression removes redundancy without losing any information; it is used for text, programs and spreadsheets where accuracy is essential. Lossy compression permanently removes information that is less noticeable to human senses; it is used for photographs, music and video where a small loss of quality is acceptable in exchange for much smaller files.",
        "The size of an uncompressed image can be calculated by multiplying the number of pixels by the number of bits used for each pixel. For example, a 1,024 by 768 image with 24 bits per pixel requires 1,024 × 768 × 24 bits, which is about 2.25 megabytes. Compressing the same image with the JPEG method may reduce it to a few hundred kilobytes.",
        "Common file formats reflect these methods: TXT and BMP store uncompressed data, ZIP and PNG use lossless compression, while JPEG, MP3 and MP4 use lossy compression. Choosing the right format is part of good file management and is especially important when preparing material for the web or for mobile devices.",
      ],
      keyPoints: [
        "Sound is sampled; quality depends on sampling rate and resolution.",
        "Lossless compression keeps every bit; lossy compression discards some detail.",
        "Image size = width × height × bits per pixel.",
        "JPEG, MP3 and MP4 are lossy; ZIP and PNG are lossless.",
      ],
      example: {
        heading: "Worked example — calculating image size",
        lines: [
          "An image is 800 pixels wide and 600 pixels high with 24 bits per pixel.",
          "Total bits = 800 × 600 × 24 = 11,520,000 bits.",
          "Convert to bytes: 11,520,000 ÷ 8 = 1,440,000 bytes ≈ 1.37 MB.",
          "If the image is saved in JPEG format at a compression ratio of 10:1, it will occupy about 0.14 MB.",
        ],
      },
      image: "notebook.jpg",
      imageCaption: "Figure 2.3 — Documents, data and note-taking in study",
      summary:
        "Multimedia data is represented by sampling and pixel grids, and compression makes it practical to store and transmit. Understanding the trade-off between file size and quality is essential for every computing student.",
      questions: [
        "Differentiate between lossy and lossless compression.",
        "Calculate the size in bytes of a 640 × 480 image at 16 bits per pixel.",
        "What factors determine the quality of a digital sound recording?",
        "Give two file formats that use lossless compression.",
      ],
    },
  ],
  assignments: [
    {
      title: "Data Representation",
      questions: [
        "Convert the following to binary and hexadecimal: (a) 215 (b) 3,004 (c) 0.75.",
        "Explain how text, sound and images are represented in a computer system, with examples of file formats.",
        "Build the truth table for the expression F = (A + B) · C and draw the corresponding circuit.",
        "A colour image is 1,280 × 720 pixels at 32 bits per pixel. Calculate its size in megabytes and estimate its size after JPEG compression at 12:1.",
      ],
    },
  ],
  glossary: [
    { term: "ASCII", definition: "A 7 bit code that represents 128 characters of English text." },
    { term: "Binary", definition: "A number system with base 2 using only the digits 0 and 1." },
    { term: "Bit", definition: "A binary digit, the smallest unit of data, valued 0 or 1." },
    { term: "Boolean algebra", definition: "The algebra of binary variables and logic operations." },
    { term: "Byte", definition: "A group of eight bits." },
    { term: "Compression", definition: "Reducing the size of data by removing redundancy." },
    { term: "Floating point", definition: "A method of storing real numbers using a mantissa and an exponent." },
    { term: "Hexadecimal", definition: "A number system with base 16 using digits 0–9 and A–F." },
    { term: "Logic gate", definition: "An electronic circuit that performs a basic logical operation." },
    { term: "Lossless", definition: "Compression that can recover the original data exactly." },
    { term: "Lossy", definition: "Compression that permanently discards some data to gain size." },
    { term: "Pixel", definition: "The smallest element of a digital image." },
    { term: "Resolution", definition: "The number of pixels or samples used to represent data." },
    { term: "Sampling", definition: "Measuring a sound wave at regular intervals to convert it to numbers." },
    { term: "Unicode", definition: "A character code that supports most of the world's writing systems." },
  ],
  references: [
    "Stallings, W. (2021). Computer Organization and Architecture. Pearson.",
    "Mano, M. M. and Ciletti, M. (2017). Digital Design. 6th ed. Pearson.",
    "IEEE (2020). IEEE Standard for Floating-Point Arithmetic (754-2019).",
    "Prince Learning Hub (2026). Number Systems: Practice Workbook. Lagos.",
  ],
};

export const hardware: Chapter = {
  id: "hardware",
  title: "Computer Hardware, Maintenance and Troubleshooting",
  tagline: "The physical machine: processors, memory, storage, ports, upgrades and keeping it working.",
  units: [
    {
      title: "System Unit, Motherboard and the Processor",
      objectives: [
        "identify the parts of the system unit and their functions",
        "explain the features of the motherboard and its associated components",
        "describe the structure and operation of the CPU",
        "state the meaning of clock speed, word length and bus width",
      ],
      paragraphs: [
        "The system unit is the main box of a desktop computer and it houses the motherboard, the processor, memory modules, the power supply and storage drives. The motherboard (system board) is the main circuit board that connects all the components together through a set of electrical paths called buses. It carries the processor socket, memory slots, expansion slots, the chipset and the connectors for storage and peripherals.",
        "The processor (CPU) executes the instructions of a program. It contains the control unit, the arithmetic logic unit, registers and a small fast memory called cache. Its speed is measured in gigahertz, and its performance depends on several factors: clock speed, word length (the number of bits processed at once), the number of cores, the size of the cache and the width of the bus. Modern processors have two or more cores, allowing them to work on several tasks at the same time.",
        "The Little Man Computer is a simple model used to teach how a processor works. It imagines a small post office with one hundred mailboxes (memory locations), a calculator (accumulator), a program counter and an instruction register. Instructions such as 901 (input), 902 (output), 1xx (load), 2xx (store), 3xx (add), 5xx (subtract) and 000 (halt) show how the fetch–decode–execute cycle works. Students who understand this model find real processor architecture much easier to follow.",
        "Buses connect the components. The data bus carries data, the address bus carries the location where data is to be found, and the control bus carries timing and command signals. A wider bus moves more data at once, which is why a 64 bit system is faster than a 32 bit system with the same clock speed.",
      ],
      keyPoints: [
        "The motherboard connects all components through buses.",
        "CPU performance depends on clock speed, word length, cores, cache and bus width.",
        "The Little Man Computer explains the fetch–decode–execute cycle.",
        "Data bus carries data; address bus carries locations; control bus carries signals.",
      ],
      diagram: "blocks",
      example: {
        heading: "Worked example — Little Man Computer",
        lines: [
          "Program: 901 (input first number), 310 (add contents of mailbox 10), 902 (output), 000 (halt).",
          "If the user inputs 5 and mailbox 10 holds 7, the calculator receives 5, then adds 7 to give 12, which is printed.",
          "This shows the fetch–decode–execute cycle: fetch 901, decode as input, execute by reading 5 into the calculator.",
        ],
      },
      summary:
        "The system unit contains the motherboard, processor, memory and storage. The processor follows the fetch–decode–execute cycle, and its performance depends on clock speed, word length, cache and bus width.",
      questions: [
        "Name six components found inside the system unit.",
        "What is the function of the motherboard?",
        "Using the Little Man Computer, explain the fetch–decode–execute cycle.",
        "State four factors that determine the speed of a processor.",
      ],
    },
    {
      title: "Memory and Storage Devices",
      objectives: [
        "distinguish between primary and secondary memory",
        "explain the difference between RAM and ROM",
        "compare magnetic, optical and solid state storage",
        "select suitable storage for given situations",
      ],
      paragraphs: [
        "Memory is where data and instructions are held while the computer is working. Primary memory is directly accessible by the processor and includes RAM (random access memory) and ROM (read only memory). RAM is volatile, meaning its contents are lost when the power is switched off; it holds the operating system, running programs and open documents. ROM is non-volatile and keeps its contents without power; it holds the start-up instructions (BIOS/UEFI) needed when the computer is switched on.",
        "Secondary (auxiliary) storage keeps data permanently. Magnetic storage includes hard disk drives, which are inexpensive and hold large amounts of data, and magnetic tape, used for backups. Optical storage includes CD, DVD and Blu-ray discs, read by a laser. Solid state drives use flash memory chips with no moving parts, so they are faster, quieter and more reliable than hard disks, although they cost more per gigabyte.",
        "Memory is arranged in a hierarchy: registers inside the processor are the fastest and smallest, followed by cache, then main memory (RAM), and finally secondary storage, which is the slowest and largest. The operating system moves data between these levels so that the processor usually finds what it needs in the fastest memory.",
        "When choosing storage, consider capacity, speed, portability, durability and cost. A student who works on several machines may prefer a flash drive or cloud storage, while an organisation that keeps millions of records will need hard disk arrays with backup facilities.",
      ],
      keyPoints: [
        "RAM is volatile working memory; ROM is non-volatile and holds the BIOS.",
        "Memory hierarchy: registers → cache → RAM → secondary storage.",
        "SSDs are faster and more durable than hard disks but cost more per GB.",
        "Storage choice depends on capacity, speed, portability, durability and cost.",
      ],
      table: {
        caption: "Table 3.1 — Comparison of storage media",
        headers: ["Medium", "Volatility", "Relative speed", "Typical use"],
        rows: [
          ["RAM", "Volatile", "Very fast", "Running programs"],
          ["ROM", "Non-volatile", "Fast", "Start-up instructions"],
          ["SSD", "Non-volatile", "Fast", "Operating system, applications"],
          ["Hard disk", "Non-volatile", "Medium", "Mass storage"],
          ["Optical disc", "Non-volatile", "Slow", "Distribution, backup"],
          ["Magnetic tape", "Non-volatile", "Very slow", "Archive backup"],
        ],
      },
      summary:
        "Memory and storage are organised in a hierarchy that balances speed and cost. Understanding the characteristics of each medium allows the user to choose the right device for each task.",
      questions: [
        "Differentiate between RAM and ROM.",
        "What is the memory hierarchy? List it from fastest to slowest.",
        "Give two advantages of a solid state drive over a hard disk drive.",
        "Which storage medium would you recommend for archiving student records? Justify your answer.",
      ],
    },
    {
      title: "Ports, Connectors and Peripheral Devices",
      objectives: [
        "identify common ports and connectors on the system unit",
        "explain the function of USB, HDMI, Ethernet and other interfaces",
        "describe the main types of printers and their uses",
        "state the precautions to take when installing equipment",
      ],
      paragraphs: [
        "Ports are the sockets on the computer where peripherals are connected. USB (Universal Serial Bus) is the most common interface and comes in several versions; USB-C is reversible and can carry data, video and power. HDMI carries digital video and sound to monitors and projectors. The Ethernet port (RJ-45) connects the computer to a wired network, while the older VGA and DVI ports carry video to monitors. Audio jacks connect microphones and speakers.",
        "Peripheral devices include printers (inkjet, laser and dot matrix), scanners, projectors, webcams, keyboards and mice. Inkjet printers are inexpensive and produce good colour output; laser printers are faster and cheaper per page for large volumes; dot matrix printers are impact printers used where carbon copies are required. Scanners convert paper documents into digital form, and optical character recognition software converts scanned images into editable text.",
        "When installing any equipment, the machine should be switched off and unplugged, the correct cable should be used, and the device driver should be installed so that the operating system can communicate with the hardware. Anti-static precautions protect sensitive components from static electricity, which can damage chips without being seen.",
        "Good cabling practice improves safety and reliability. Cables should not be bent sharply or placed where people can trip over them, and ventilation openings must not be blocked. Dust should be removed regularly with compressed air, and liquids should never be placed near the computer.",
      ],
      keyPoints: [
        "USB-C carries data, video and power through a reversible connector.",
        "HDMI carries digital video and audio; RJ-45 connects Ethernet networks.",
        "Laser printers are best for high volume; inkjet printers for colour at low cost.",
        "Install hardware with the power off and use anti-static precautions.",
      ],
      table: {
        caption: "Table 3.2 — Common ports and their uses",
        headers: ["Port", "Carries", "Typical device"],
        rows: [
          ["USB / USB-C", "Data, sometimes power and video", "Flash drive, keyboard, phone"],
          ["HDMI", "Digital video and audio", "Monitor, projector"],
          ["RJ-45", "Network data", "Ethernet cable"],
          ["VGA / DVI", "Analog / digital video", "Monitor"],
          ["3.5 mm jack", "Audio", "Speakers, microphone"],
        ],
      },
      image: "engineering.jpg",
      imageCaption: "Figure 3.3 — Working safely on computer hardware",
      summary:
        "Ports and connectors link the computer to the outside world. Knowing which interface to use, and installing equipment correctly, prevents damage and keeps the system working reliably.",
      questions: [
        "List five ports found on a typical desktop computer and one device for each.",
        "Compare inkjet and laser printers.",
        "What precautions should be taken when installing a new peripheral?",
        "Explain the purpose of a device driver.",
      ],
    },
    {
      title: "PC Assembly, Upgrading, Maintenance and Troubleshooting",
      objectives: [
        "describe the steps involved in assembling a simple PC",
        "explain when and how to upgrade memory, storage and the operating system",
        "apply preventive maintenance practices",
        "apply a systematic troubleshooting procedure to common faults",
      ],
      paragraphs: [
        "Assembling a PC involves preparing the case and power supply, mounting the processor and cooler on the motherboard, installing the memory modules, fixing the motherboard into the case, connecting the power and data cables, installing the storage drives and expansion cards, and finally connecting the monitor, keyboard and mouse. The BIOS is then configured and the operating system installed. Throughout the process, the technician must earth himself with an anti-static strap and handle components by their edges.",
        "Upgrading is the process of improving the machine by adding or replacing components. The most common upgrades are adding more RAM, replacing a hard disk with a solid state drive and upgrading the operating system. Before any upgrade, compatibility must be checked (memory type and speed, available slots and power supply capacity), and all important data must be backed up.",
        "Maintenance is of two kinds. Preventive maintenance keeps the system in good condition before faults occur: cleaning dust from vents and fans, keeping the system cool and dry, using surge protectors and uninterruptible power supplies, updating software and running antivirus scans. Corrective maintenance is carried out after a fault appears, such as replacing a failed power supply or removing malware.",
        "Troubleshooting follows a systematic sequence: identify the problem, form a theory of the probable cause, test the theory, plan and implement the solution, verify that the whole system works properly, and document what was done. Common problems include no power, no display, overheating, slow performance, missing drivers, disk errors and printer jams. A patient, methodical approach saves time and prevents new problems.",
      ],
      keyPoints: [
        "Assemble with the power off and use an anti-static strap.",
        "Check compatibility and back up data before any upgrade.",
        "Preventive maintenance avoids faults; corrective maintenance repairs them.",
        "Troubleshoot systematically and document the outcome.",
      ],
      example: {
        heading: "Worked example — troubleshooting a computer with no display",
        lines: [
          "Step 1: Observe. The fans are spinning, but the monitor shows 'no signal'.",
          "Step 2: Theory. The monitor cable may be loose or the memory module may not be seated correctly.",
          "Step 3: Test. Reseat the video cable and then one memory module at a time.",
          "Step 4: Implement. A loose memory module is found and re-seated.",
          "Step 5: Verify and document. The system now boots; the fault is recorded in the maintenance log.",
        ],
      },
      summary:
        "Hardware work requires care, planning and a systematic approach. Assembly, upgrading, preventive maintenance and troubleshooting are essential practical skills for every computing professional.",
      questions: [
        "List the correct order of steps when assembling a desktop computer.",
        "State three precautions to observe when handling computer components.",
        "Differentiate between preventive and corrective maintenance.",
        "Outline the six steps of systematic troubleshooting.",
      ],
    },
  ],
  assignments: [
    {
      title: "Hardware",
      questions: [
        "Draw and label the system unit, showing the motherboard, processor, memory, power supply and drives.",
        "A student's computer restarts randomly and the case feels hot. Diagnose the fault systematically and recommend three preventive measures.",
        "Compare RAM, ROM, SSD, hard disk and optical disc in terms of volatility, speed, capacity and cost.",
        "Prepare a step by step guide for upgrading a computer from 4 GB to 8 GB of memory, including the precautions to observe.",
      ],
    },
  ],
  glossary: [
    { term: "Bus", definition: "An electrical path that carries data, addresses and signals between components." },
    { term: "Cache", definition: "Small, very fast memory inside or near the processor." },
    { term: "Clock speed", definition: "The rate at which a processor executes instructions, measured in GHz." },
    { term: "Device driver", definition: "Software that allows the operating system to control a hardware device." },
    { term: "ESD", definition: "Electrostatic discharge; static electricity that can damage components." },
    { term: "Firmware", definition: "Software stored permanently in hardware, such as the BIOS." },
    { term: "Motherboard", definition: "The main circuit board that connects all computer components." },
    { term: "Peripheral", definition: "A device connected to the computer, such as a printer or scanner." },
    { term: "POST", definition: "Power-On Self-Test, the check performed by the BIOS at start-up." },
    { term: "RAM", definition: "Volatile memory that holds programs and data currently in use." },
    { term: "ROM", definition: "Non-volatile memory that holds permanent instructions." },
    { term: "SSD", definition: "Solid state drive; storage using flash memory without moving parts." },
    { term: "Troubleshooting", definition: "A systematic process of finding and repairing faults." },
    { term: "Upgrade", definition: "Improving a computer by adding or replacing components." },
    { term: "Word length", definition: "The number of bits a processor handles in one operation." },
  ],
  references: [
    "Patterson, D. A. and Hennessy, J. L. (2020). Computer Organization and Design. Morgan Kaufmann.",
    "CompTIA (2023). A+ Certification: Core Hardware Objectives.",
    "White, R. (2019). How Computers Work. 10th ed. Que Publishing.",
    "Prince Learning Hub (2026). Practical Hardware Workshop Notes. Lagos.",
  ],
};

export const software: Chapter = {
  id: "software",
  title: "Software, Operating Systems and Application Packages",
  tagline: "The programs that make hardware useful, from the operating system to office applications.",
  units: [
    {
      title: "System Software and Operating Systems",
      objectives: [
        "classify system software and application software",
        "explain the functions of an operating system",
        "compare command line and graphical user interfaces",
        "describe the types of operating systems and their uses",
      ],
      paragraphs: [
        "Software is the set of programs that directs the operation of the computer. System software includes the operating system, device drivers, translators and utility programs; it manages the hardware and provides a platform for application software. Application software performs the tasks that users want to accomplish, such as typing letters, preparing budgets, designing graphics and communicating over the Internet.",
        "The operating system performs several essential functions. It manages the processor by scheduling jobs, manages memory by allocating space to programs, manages files and folders on storage, controls input and output devices through drivers, provides a user interface, enforces security through user accounts and passwords, and detects and reports errors. Common operating systems include Windows, macOS, Linux and Android.",
        "The user interface is the means by which the user communicates with the computer. A command line interface requires typed commands and is efficient for trained users and system administrators. A graphical user interface (GUI) uses windows, icons, menus and a pointer, making it easy for beginners. Touch and voice interfaces are now common on mobile devices.",
        "Operating systems may also be classified by how they handle users and jobs. A single user operating system serves one person at a time, a multi-user system serves many users simultaneously, a multitasking system runs several programs at once, a real time system responds within strict time limits, and a distributed system manages resources on several machines as if they were one.",
      ],
      keyPoints: [
        "System software manages hardware; application software solves user problems.",
        "The operating system manages processor, memory, files, devices, security and errors.",
        "GUI is easy for beginners; command line is fast for experts.",
        "Types: single user, multi-user, multitasking, real time and distributed.",
      ],
      table: {
        caption: "Table 4.1 — System software and application software",
        headers: ["Category", "Examples", "Function"],
        rows: [
          ["Operating system", "Windows, Linux, Android", "Controls hardware and programs"],
          ["Device driver", "Printer driver, graphics driver", "Controls a specific device"],
          ["Utility", "Antivirus, disk defragmenter", "Maintains and protects the system"],
          ["Translator", "Compiler, interpreter", "Converts source code to machine code"],
          ["Application", "Word processor, spreadsheet", "Performs user tasks"],
        ],
      },
      image: "course-gst.jpg",
      imageCaption: "Figure 4.1 — Planning and office application work",
      summary:
        "Software is divided into system software and application software. The operating system is the most important system program because it manages every hardware resource and provides the environment in which applications run.",
      questions: [
        "List five functions of an operating system.",
        "Differentiate between system software and application software.",
        "Compare command line and graphical user interfaces.",
        "What is a real time operating system? Give one example of its use.",
      ],
    },
    {
      title: "File Management and Organisation",
      objectives: [
        "explain the concepts of files, folders and directories",
        "describe file naming rules and file types",
        "use common file management operations",
        "apply good practices for organising and protecting files",
      ],
      paragraphs: [
        "A file is a named collection of related data stored on a storage device. Files are classified by their content and by their extension: text files (.txt), documents (.docx), spreadsheets (.xlsx), images (.jpg, .png), audio (.mp3), video (.mp4) and programs (.exe). The file extension tells the operating system which program should open the file.",
        "Files are organised in folders (directories), which may contain sub-folders in a hierarchical structure. Good organisation saves time: students should create a folder for each course, use clear names and dates for files, and delete or archive files that are no longer needed. File management operations include creating, renaming, copying, moving, deleting, searching and compressing files.",
        "File names must follow the rules of the operating system. In Windows, certain characters cannot be used in names, names are not case sensitive, and long names may be shortened when transferred to older systems. A good file name is short but descriptive, for example MTH101_Notes_Week3.docx rather than New Document (2).docx.",
        "Files must also be protected. This is achieved by using passwords and user accounts, keeping regular backup copies on a separate device or in the cloud, using antivirus software, and encrypting sensitive information. A file that is deleted from the hard disk may still be recoverable until the space is overwritten, so storage devices containing confidential data must be properly cleared before disposal.",
      ],
      keyPoints: [
        "A file is named data; the extension shows the file type.",
        "Folders organise files hierarchically.",
        "Use clear, descriptive file names and a consistent structure.",
        "Protect files with passwords, backups, antivirus and encryption.",
      ],
      example: {
        heading: "Worked example — organising student files",
        lines: [
          "Create a folder called 'ND2 Second Semester'.",
          "Inside it create sub-folders: COM221, COM222, COM223, COM224, COM225 and COM226.",
          "Save notes as COM221_Week1_Notes.docx and assignments as COM221_Assignment1.docx.",
          "At the end of each week, copy the whole folder to a flash drive or cloud storage as a backup.",
        ],
      },
      summary:
        "File management is a daily activity. Naming files properly, organising them in folders and protecting them with backups prevents loss of work and saves time when it is needed.",
      questions: [
        "What is a file? Give three examples with their extensions.",
        "Explain why folders are used to organise files.",
        "State four rules for good file naming.",
        "Describe three ways of protecting files from loss or unauthorised access.",
      ],
    },
    {
      title: "Word Processing, Spreadsheets and Presentations",
      objectives: [
        "use word processing features to produce formatted documents",
        "use spreadsheet formulas and functions for calculations",
        "create and deliver effective presentations",
        "choose the right application for a given task",
      ],
      paragraphs: [
        "A word processor is used to create, edit and format text documents. Basic features include typing and editing, character and paragraph formatting, spell checking, tables, headers and footers, page layout, mail merge and printing. Common packages include Microsoft Word, LibreOffice Writer and Google Docs. The standard shortcuts Ctrl+S to save, Ctrl+C to copy, Ctrl+V to paste, Ctrl+Z to undo and Ctrl+P to print should become second nature.",
        "A spreadsheet organises data in rows and columns. Each cell has an address such as B3, and each cell can contain a value, a label or a formula. Formulas begin with the equals sign and use operators such as +, -, * and /. Built in functions include SUM, AVERAGE, MIN, MAX, COUNT and IF. Spreadsheets are used for budgets, results computation, invoices, timetables and data analysis, and charts are used to present the results visually.",
        "Presentation software such as Microsoft PowerPoint is used to create slides for lectures and seminars. A good presentation uses a clear structure, readable fonts, a limited number of colours, short bullet points instead of paragraphs, and images or charts to support the message. Speaker notes help the presenter while the audience sees only the slides.",
        "Database packages such as Microsoft Access store related data in tables and allow the user to search, sort and report on the data. Choosing the right tool matters: a letter is best written in a word processor, a payroll in a spreadsheet, a talk in presentation software and a list of students in a database.",
      ],
      keyPoints: [
        "Formulas in spreadsheets begin with '=' and may use functions such as SUM and IF.",
        "Cell address = column letter + row number, e.g. B3.",
        "Effective slides use short points, readable fonts and supporting visuals.",
        "Choose the right tool: word processor, spreadsheet, presentation or database.",
      ],
      example: {
        heading: "Worked example — spreadsheet formula",
        lines: [
          "Cells A2:A6 hold the scores 70, 65, 80, 55 and 90.",
          "Total: =SUM(A2:A6) returns 360.",
          "Average: =AVERAGE(A2:A6) returns 72.",
          "Pass/Fail in cell B2: =IF(A2>=50,\"Pass\",\"Fail\") returns \"Pass\" for a score of 70.",
        ],
      },
      summary:
        "Application packages make computers useful to ordinary users. Proficiency in word processing, spreadsheets, presentations and databases is expected of every graduate and is examined in most computing programmes.",
      questions: [
        "List five features of a word processor.",
        "Write a spreadsheet formula that returns 'Credit' if a score is 60 or above and 'Fail' otherwise.",
        "State four guidelines for preparing a good presentation.",
        "When would you use a database rather than a spreadsheet?",
      ],
    },
    {
      title: "Utility Programs, Devices and Productivity Tools",
      objectives: [
        "explain the role of utility programs",
        "describe how antivirus, backup and compression tools work",
        "use productivity tools for collaboration",
        "evaluate software for a given task",
      ],
      paragraphs: [
        "Utility programs perform maintenance and support tasks. Antivirus software scans files for malicious code and removes or quarantines threats. Backup utilities make copies of data so that it can be restored after loss. Compression utilities such as WinZip reduce file size for storage and transmission. Disk management utilities format, partition and defragment drives, while diagnostic utilities check hardware and report errors.",
        "Cloud productivity tools allow several people to work on the same document at the same time. Google Workspace and Microsoft 365 provide word processing, spreadsheets, presentations, email and storage through a web browser. Advantages include access from any device, automatic saving and easy sharing; the disadvantages include dependence on an Internet connection and concerns about data privacy.",
        "When evaluating software, consider its purpose, ease of use, reliability, cost, compatibility with existing systems, support and security. Free and open source software such as LibreOffice and Linux can reduce costs, while commercial packages may offer better support and integration. Students should understand software licences and respect intellectual property rights.",
        "Automation tools, including macros and scripting, can save time on repetitive tasks. A macro in a spreadsheet, for example, can format a monthly report at the click of a button. Learning to automate routine work is a valuable skill in any organisation.",
      ],
      keyPoints: [
        "Utilities include antivirus, backup, compression, disk and diagnostic tools.",
        "Cloud tools support collaboration but depend on connectivity.",
        "Evaluate software by purpose, usability, cost, compatibility and security.",
        "Macros and scripts automate repetitive work.",
      ],
      summary:
        "Utility programs keep the system healthy, and modern productivity tools support collaboration across distance. Selecting and using the right software is a practical skill that every student must develop.",
      questions: [
        "Name four utility programs and state one function of each.",
        "Give two advantages and two disadvantages of cloud productivity tools.",
        "What factors should be considered when selecting software for an organisation?",
        "Explain how a macro can improve productivity.",
      ],
    },
  ],
  assignments: [
    {
      title: "Software and Application Packages",
      questions: [
        "Explain the functions of an operating system and state four types of operating systems with examples.",
        "Using a spreadsheet package, prepare a result sheet for five students offering four courses, showing the total, average and grade for each student. Attach a printout.",
        "Design a set of ten slides for a five minute talk on 'Safe Use of the Internet', observing the guidelines for good presentations.",
        "Discuss the benefits and challenges of using cloud productivity tools in a Nigerian institution.",
      ],
    },
  ],
  glossary: [
    { term: "Application software", definition: "Programs that help users perform specific tasks." },
    { term: "Backup", definition: "A copy of data kept for restoration after loss." },
    { term: "Cell", definition: "The intersection of a row and column in a spreadsheet." },
    { term: "CLI", definition: "Command line interface; typed commands used to control a system." },
    { term: "Database", definition: "An organised collection of related data." },
    { term: "Device driver", definition: "Software that lets the operating system control a device." },
    { term: "File", definition: "A named collection of related data stored on a device." },
    { term: "Formula", definition: "A calculation entered in a spreadsheet cell, beginning with '='." },
    { term: "GUI", definition: "Graphical user interface using windows, icons, menus and pointer." },
    { term: "Macro", definition: "A recorded sequence of commands that can be replayed." },
    { term: "Multitasking", definition: "Running several programs at the same time." },
    { term: "Operating system", definition: "Software that manages hardware and provides services to programs." },
    { term: "Utility", definition: "A program that maintains, repairs or protects the computer." },
    { term: "Virus", definition: "A malicious program that attaches itself to other files." },
    { term: "Word processor", definition: "Software used to create and format text documents." },
  ],
  references: [
    "Silberschatz, A., Galvin, P. B. and Gagne, G. (2021). Operating System Concepts. 10th ed. Wiley.",
    "Parsons, J. and Oja, D. (2020). New Perspectives on Computer Concepts. Cengage.",
    "Microsoft (2024). Office Application Support Documentation.",
    "Prince Learning Hub (2026). Computer Application Packages Practical Manual. Lagos.",
  ],
};
