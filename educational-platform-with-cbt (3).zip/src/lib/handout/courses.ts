import { computing, datarep, hardware, software } from "./chapters-a";
import { maths, programming, oop, algo } from "./chapters-b";
import { data, network, se, security, research } from "./chapters-c";
import type { Chapter, HandoutInput, Practice } from "./pdf-handout";
import { ALL_TESTS } from "@/lib/tests";

export const CHAPTERS: Record<string, Chapter> = {
  computing,
  datarep,
  hardware,
  software,
  maths,
  programming,
  oop,
  algo,
  data,
  network,
  se,
  security,
  research,
};

/** Chapter selection by course code. Anything not listed falls back to the title keywords. */
export const CHAPTER_MAP: Record<string, string[]> = {
  "COS 101": ["computing", "datarep", "software", "research"],
  "WUI-LBS 001": ["research", "computing", "security", "software"],
  "WUI-LIB 001": ["research", "computing", "security", "software"],
  "WUI-CSC 101": ["computing", "hardware", "software", "network"],
  "WUI-CSC 103": ["network", "hardware", "computing", "security"],
  "WUI-CSC 104": ["software", "computing", "data", "research"],
  "COS 201": ["programming", "oop", "algo", "research"],
  "WUI-SEN 263": ["programming", "oop", "algo", "research"],
  "CSC 203": ["algo", "datarep", "programming", "research"],
  "SEN 201": ["se", "programming", "research", "security"],
  "WUI-CSC 201": ["hardware", "computing", "network", "software"],
  "COS 202": ["oop", "programming", "algo", "se"],
  "IFT 212": ["hardware", "datarep", "algo", "computing"],
  "INS 204": ["se", "data", "research", "programming"],
  "CSC 301": ["oop", "programming", "algo", "se"],
  "CSC 303": ["se", "data", "research", "programming"],
  "CSC 305": ["algo", "programming", "datarep", "research"],
  "CSC 307": ["data", "datarep", "network", "se"],
  "CSC 309": ["hardware", "datarep", "algo", "computing"],
  "MAT 303": ["maths", "datarep", "algo", "research"],
  "CSC 401": ["network", "security", "data", "computing"],
  "CSC 403": ["programming", "computing", "oop", "algo"],
  "CSC 405": ["se", "programming", "research", "security"],
  "CSC 407": ["algo", "maths", "programming", "computing"],
  "CSC 409": ["se", "computing", "research", "software"],
  "CSC 419": ["data", "se", "computing", "research"],
  "CSC 427": ["computing", "network", "security", "algo"],
  "SEN 301": ["oop", "se", "programming", "data"],
  "SEN 303": ["se", "programming", "algo", "research"],
  "SEN 305": ["network", "programming", "software", "se"],
  "SEN 309": ["programming", "oop", "algo", "computing"],
  "SEN 311": ["se", "research", "security", "computing"],
  "SEN 312": ["maths", "hardware", "algo", "research"],
  "CSC 304": ["oop", "programming", "software", "se"],
  "CSC 330": ["programming", "algo", "computing", "datarep"],
  "CSC 312": ["maths", "data", "research", "computing"],
  "STA 322": ["maths", "algo", "data", "research"],
  "SEN 401": ["se", "programming", "security", "research"],
  "SEN 403": ["se", "research", "data", "computing"],
  "SEN 405": ["research", "maths", "se", "security"],
  "SEN 407": ["security", "se", "research", "computing"],
  "SEN 409": ["security", "network", "programming", "se"],
  "SEN 411": ["algo", "computing", "programming", "data"],
  "SEN 413": ["programming", "oop", "network", "se"],
  "SEN 415": ["hardware", "programming", "computing", "network"],
  "SEN 417": ["data", "algo", "se", "network"],
  "COM 111": ["computing", "datarep", "software", "research"],
  "COM 113": ["programming", "oop", "algo", "research"],
  "COM 114": ["maths", "computing", "datarep", "research"],
  "COM 115": ["software", "computing", "data", "research"],
  "COM 121": ["programming", "oop", "algo", "datarep"],
  "COM 122": ["network", "computing", "security", "research"],
  "COM 123": ["oop", "programming", "algo", "software"],
  "COM 124": ["algo", "programming", "data", "research"],
  "COM 125": ["se", "data", "research", "programming"],
  "COM 126": ["hardware", "computing", "network", "security"],
  "COM 211": ["oop", "programming", "algo", "se"],
  "COM 212": ["hardware", "programming", "algo", "computing"],
  "COM 214": ["hardware", "network", "security", "computing"],
  "COM 215": ["software", "data", "computing", "research"],
  "COM 221": ["network", "hardware", "computing", "security"],
  "COM 222": ["security", "research", "se", "computing"],
  "COM 223": ["hardware", "computing", "network", "security"],
  "COM 224": ["data", "se", "computing", "research"],
  "COM 225": ["network", "programming", "software", "security"],
  "COM 226": ["data", "computing", "algo", "software"],
  "SWD311": ["network", "programming", "software", "security"],
  "SWD321": ["programming", "oop", "network", "software"],
  "NCC311": ["network", "hardware", "computing", "security"],
  "NCC321": ["network", "security", "data", "computing"],
  "CYB311": ["security", "network", "computing", "research"],
  "CYB321": ["security", "network", "data", "research"],
  "AIT311": ["computing", "algo", "programming", "research"],
  "AIT321": ["maths", "algo", "programming", "data"],
  "GST101": ["research", "computing", "security", "software"],
  "MTH101": ["maths", "datarep", "research", "computing"],
  "CPE101": ["hardware", "computing", "datarep", "software"],
  "CPE201": ["hardware", "datarep", "programming", "computing"],
  "CPE301": ["hardware", "programming", "computing", "network"],
  "CPE401": ["network", "hardware", "computing", "security"],
  "CPE501": ["hardware", "programming", "network", "se"],
};

function chaptersFromTitle(title: string): string[] {
  const t = title.toLowerCase();
  if (/entrepreneur/.test(t)) return ["se", "research", "security", "computing"];
  if (/research method/.test(t)) return ["research", "maths", "se", "data"];
  if (/library|study skill/.test(t)) return ["research", "computing", "security", "software"];
  if (/compiler/.test(t)) return ["programming", "algo", "computing", "datarep"];
  if (/algorithm|data structure/.test(t)) return ["algo", "programming", "datarep", "research"];
  if (/database|data management|file organisa/.test(t)) return ["data", "algo", "se", "research"];
  if (/network|internet|web|iot|cloud|net-centric/.test(t)) return ["network", "computing", "security", "se"];
  if (/security|cyber|ethic/.test(t)) return ["security", "network", "computing", "research"];
  if (/hardware|architecture|troubleshoot|maintenance|embedded/.test(t)) return ["hardware", "computing", "programming", "network"];
  if (/mobile|android|ios/.test(t)) return ["programming", "oop", "network", "se"];
  if (/artificial|expert|machine learning/.test(t)) return ["algo", "computing", "programming", "data"];
  if (/human computer|interface|usability/.test(t)) return ["se", "computing", "research", "software"];
  if (/management information|\bmis\b/.test(t)) return ["data", "se", "computing", "research"];
  if (/performance/.test(t)) return ["maths", "hardware", "algo", "research"];
  if (/statistic|mathemat|operations research|discrete/.test(t)) return ["maths", "datarep", "algo", "research"];
  if (/software engineering|software config|project management|quality|testing/.test(t)) return ["se", "programming", "research", "security"];
  if (/object oriented|object-oriented/.test(t)) return ["oop", "programming", "algo", "se"];
  if (/programming|c\+\+|java|c#|\br\b/.test(t)) return ["programming", "oop", "algo", "se"];
  if (/application package|office/.test(t)) return ["software", "computing", "data", "research"];
  return ["computing", "software", "research", "se"];
}

const CATEGORY_LABEL: Record<string, string> = {
  university: "University",
  polytechnic: "Polytechnic",
};

export function handoutForTest(t: {
  code: string;
  title: string;
  category: string;
  department: string;
  level: string;
  semester: string;
  description: string;
  questions: Practice[];
}): HandoutInput | null {
  const ids = CHAPTER_MAP[t.code] ?? chaptersFromTitle(t.title);
  const chapters = ids.map((id) => CHAPTERS[id]).filter(Boolean);
  if (chapters.length < 3) return null;
  // every handout carries five chapters so that it reads as a complete study text
  const extras = ["computing", "research", "se", "software", "datarep", "hardware", "programming", "security"];
  for (const id of extras) {
    if (chapters.length >= 5) break;
    const ch = CHAPTERS[id];
    if (ch && !chapters.includes(ch)) chapters.push(ch);
  }
  const outcomes = [
    `explain the fundamental concepts and principles of ${t.title.toLowerCase()}`,
    ...chapters.map((c) => c.units[0].objectives[0]),
    "apply the techniques studied to solve practical problems",
    "use appropriate tools and terminology confidently",
    "evaluate current practice and communicate ideas clearly",
  ].slice(0, 10);
  return {
    courseCode: t.code,
    title: t.title,
    department: t.department,
    level: t.level,
    semester: t.semester,
    categoryLabel: CATEGORY_LABEL[t.category] ?? t.category,
    description: t.description,
    outcomes,
    chapters,
    practice: t.questions,
  };
}

/** Every university and polytechnic course that should have a downloadable handout. */
export function buildHandouts(): HandoutInput[] {
  return ALL_TESTS.filter((t) => t.category === "university" || t.category === "polytechnic")
    .map((t) =>
      handoutForTest({
        code: t.code,
        title: t.title,
        category: t.category,
        department: t.department,
        level: t.level,
        semester: t.semester ?? "",
        description: t.description,
        questions: (t.questions ?? []).map(([question, options, answerIndex, explanation]) => ({
          question,
          options,
          answerIndex,
          explanation,
        })),
      }),
    )
    .filter((x): x is HandoutInput => x !== null);
}
