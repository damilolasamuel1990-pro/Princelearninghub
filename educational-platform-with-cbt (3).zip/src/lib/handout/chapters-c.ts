import type { Chapter } from "./pdf-handout";

export const data: Chapter = {
  id: "data",
  title: "Database Systems and Information Management",
  tagline: "Designing and using databases: the relational model, SQL, normalisation, transactions and information systems.",
  units: [
    {
      title: "Database Concepts and the Relational Model",
      objectives: [
        "explain the difference between data, files and databases",
        "describe the database management system and its functions",
        "explain the relational model and its terminology",
        "identify keys and integrity rules",
      ],
      paragraphs: [
        "A database is an organised collection of related data that can be shared by many users. Before databases, organisations kept separate files for each department, which caused duplication, inconsistency and difficulty in sharing information. A database management system (DBMS) is software that creates, stores, retrieves and controls access to the database. Examples include MySQL, Oracle, Microsoft Access and PostgreSQL.",
        "The relational model, proposed by E. F. Codd, represents data as tables called relations. A table consists of rows (tuples) and columns (attributes). Each row describes one entity, such as one student, and each column describes one property, such as registration number. The intersection of a row and column is a field. The number of columns is the degree and the number of rows is the cardinality.",
        "Keys are important for identifying records. A candidate key is any attribute or set of attributes that uniquely identifies each row. The primary key is the candidate key chosen for the table. A foreign key is an attribute in one table that refers to the primary key of another table and creates a relationship between them.",
        "Integrity rules keep data correct. Entity integrity requires that no primary key value is null. Referential integrity requires that every foreign key value either matches an existing primary key or is null. Following these rules prevents errors such as orders belonging to customers who do not exist.",
      ],
      keyPoints: [
        "A DBMS creates, stores, retrieves and protects data.",
        "Relations are tables: rows are tuples, columns are attributes.",
        "The primary key uniquely identifies a row; a foreign key links tables.",
        "Entity integrity: no null primary keys. Referential integrity: valid foreign keys.",
      ],
      example: {
        heading: "Worked example — a simple student table",
        lines: [
          "STUDENT (RegNo, Name, Level, Department)",
          "Row: PLH/2026/014, Amaka Johnson, 200, Computer Science.",
          "RegNo is the primary key because no two students share it.",
          "A related RESULT table uses RegNo as a foreign key to link each result to a student.",
        ],
      },
      image: "notebook.jpg",
      imageCaption: "Figure 9.1 — Structured records and data organisation",
      summary:
        "Databases remove the problems of file based systems. The relational model represents data as tables linked by keys and protected by integrity rules.",
      questions: [
        "State four problems of file based data processing.",
        "Define the terms relation, tuple and attribute.",
        "Differentiate between a primary key and a foreign key.",
        "Explain entity integrity and referential integrity.",
      ],
    },
    {
      title: "Structured Query Language (SQL)",
      objectives: [
        "write SQL statements to create and modify tables",
        "retrieve data using SELECT with conditions",
        "sort, group and aggregate data",
        "join tables to combine related information",
      ],
      paragraphs: [
        "SQL is the standard language for working with relational databases. It has three parts: data definition language (CREATE, ALTER, DROP) which defines structures, data manipulation language (SELECT, INSERT, UPDATE, DELETE) which works with data, and data control language (GRANT, REVOKE) which controls access.",
        "The SELECT statement retrieves data. It uses FROM to name the tables, WHERE to filter rows, ORDER BY to sort results, GROUP BY to collect rows with the same value and HAVING to filter groups. Aggregate functions include COUNT, SUM, AVG, MIN and MAX. Distinct values are obtained with the DISTINCT keyword.",
        "Joins combine data from two or more tables. An inner join returns only matching rows, a left outer join returns all rows from the left table and matching rows from the right, and a full outer join returns all rows from both. Most queries in real systems use joins, so understanding them is essential.",
        "SQL is a declarative language: the user states what result is required and the database works out how to obtain it. Good queries are readable, use clear table aliases and avoid selecting unnecessary columns, especially in large databases.",
      ],
      keyPoints: [
        "DDL defines structures; DML works with data; DCL controls access.",
        "SELECT ... FROM ... WHERE ... ORDER BY is the standard query pattern.",
        "GROUP BY collects rows; HAVING filters the groups.",
        "Inner joins return matching rows; outer joins keep unmatched rows too.",
      ],
      example: {
        heading: "Worked example — SQL query with a join",
        lines: [
          "SELECT s.Name, r.CourseCode, r.Score",
          "FROM Student s",
          "INNER JOIN Result r ON s.RegNo = r.RegNo",
          "WHERE r.Score >= 50",
          "ORDER BY r.Score DESC;",
          "This returns the names of students who passed, with their courses and scores, from the highest to the lowest.",
        ],
      },
      summary:
        "SQL allows the user to define, manipulate and control database data. Skill in SELECT, joins and aggregation is central to working with any relational database.",
      questions: [
        "Write SQL to create a table called Course with columns Code, Title and Units.",
        "Write a query that lists all students in the 300 level in alphabetical order.",
        "Explain the difference between WHERE and HAVING.",
        "What is a join? Differentiate between inner and left outer joins.",
      ],
    },
    {
      title: "Normalisation and Database Design",
      objectives: [
        "explain data redundancy and the anomalies it causes",
        "apply the first three normal forms",
        "design an entity relationship diagram",
        "convert an ER diagram into tables",
      ],
      paragraphs: [
        "Normalisation is the process of organising tables to reduce duplication and prevent insertion, update and deletion anomalies. First normal form (1NF) removes repeating groups so that every field holds a single value. Second normal form (2NF) removes partial dependencies on part of a composite key. Third normal form (3NF) removes transitive dependencies, where a non key attribute depends on another non key attribute.",
        "Design begins with an entity relationship (ER) model. Entities are the things of interest (Student, Course), attributes describe them (Name, Level), and relationships link them (a student registers for a course). Cardinality shows whether a relationship is one to one, one to many or many to many. In an ER diagram, entities are drawn as rectangles, attributes as ovals and relationships as diamonds.",
        "A many to many relationship is implemented with a linking table containing the primary keys of both entities as foreign keys. For example, the relationship between Student and Course is implemented by a Registration table containing RegNo and CourseCode.",
        "Good database design makes applications easier to build and maintain. It also improves performance, because well normalised tables can be joined quickly, while badly designed tables require repeated updates and produce inconsistent reports.",
      ],
      keyPoints: [
        "1NF removes repeating groups; 2NF removes partial dependencies; 3NF removes transitive dependencies.",
        "ER diagrams show entities, attributes and relationships.",
        "Many to many relationships need a linking table.",
        "Normalisation reduces duplication and anomalies.",
      ],
      example: {
        heading: "Worked example — normalisation",
        lines: [
          "Unnormalised: Student(RegNo, Name, Course1, Course2).",
          "1NF: Student(RegNo, Name, Course) — one course per row.",
          "2NF: remove partial dependency: Student(RegNo, Name) and Registration(RegNo, Course).",
          "3NF: remove transitive dependency: add Course table Course(Course, Title) and keep CourseCode in Registration.",
        ],
      },
      summary:
        "Normalisation and ER modelling produce clean, reliable database designs. These skills are used by database administrators and developers in every organisation.",
      questions: [
        "Define normalisation and state its purpose.",
        "Convert a table with repeating groups to the first normal form.",
        "Draw an ER diagram for a library system with books, members and loans.",
        "Why is a many to many relationship implemented with a linking table?",
      ],
    },
    {
      title: "Transactions, Concurrency and Information Systems",
      objectives: [
        "explain the ACID properties of transactions",
        "describe concurrency control and its problems",
        "explain backup and recovery",
        "describe the role of information systems in organisations",
      ],
      paragraphs: [
        "A transaction is a logical unit of work that must be completed entirely or not at all. For example, transferring money between two accounts involves debiting one and crediting the other; both actions must succeed or both must be undone. Transactions have four properties: atomicity (all or nothing), consistency (the database stays valid), isolation (transactions do not interfere) and durability (committed changes survive failures).",
        "Concurrency problems occur when many users work at the same time. A lost update happens when two users modify the same record and one change overwrites the other. A dirty read occurs when a transaction reads data that has not been committed. These problems are controlled with locking, timestamps and isolation levels, and in modern systems with multi version concurrency control.",
        "Recovery is the ability to restore the database after a failure. Write ahead logging records every change before it is made, and checkpoints reduce the time needed to recover. Regular backups to separate media, together with tested restoration procedures, are essential for any organisation.",
        "Information systems use technology to support an organisation's activities. Transaction processing systems record daily operations, management information systems produce regular reports, decision support systems help with semi structured decisions, and executive support systems serve senior management. Understanding these systems helps the computing professional to apply technology where it delivers real value.",
      ],
      keyPoints: [
        "ACID: atomicity, consistency, isolation, durability.",
        "Concurrency control prevents lost updates and dirty reads.",
        "Write ahead logging and checkpoints support recovery.",
        "TPS, MIS, DSS and ESS serve different levels of an organisation.",
      ],
      table: {
        caption: "Table 7.1 — Information systems by management level",
        headers: ["System", "Level", "Typical output"],
        rows: [
          ["TPS", "Operational", "Daily transaction records"],
          ["MIS", "Middle management", "Scheduled reports"],
          ["DSS", "Tactical", "Models and what-if analysis"],
          ["ESS", "Senior management", "Dashboards and trends"],
        ],
      },
      summary:
        "Transactions keep database work reliable, and information systems turn data into decisions for every level of an organisation.",
      questions: [
        "Explain the ACID properties with an example of a transaction.",
        "What is a dirty read and how is it prevented?",
        "Why are regular backups important?",
        "Compare TPS and DSS.",
      ],
    },
  ],
  assignments: [
    {
      title: "Database Systems",
      questions: [
        "Design a database for a student registration system: give the tables, keys and relationships, and draw the ER diagram.",
        "Write SQL statements to create the tables you designed and insert three rows of test data.",
        "Normalise the following to the third normal form, explaining each step: Result(RegNo, Name, Level, Course1, Score1, Course2, Score2).",
        "Explain the ACID properties and describe how a bank transfer demonstrates each one.",
      ],
    },
  ],
  glossary: [
    { term: "ACID", definition: "Atomicity, consistency, isolation and durability of transactions." },
    { term: "Attribute", definition: "A column of a relation." },
    { term: "Cardinality", definition: "The number of rows in a relation." },
    { term: "DBMS", definition: "Software that manages a database." },
    { term: "Entity", definition: "An object of interest represented by a table." },
    { term: "Foreign key", definition: "An attribute that references a primary key in another table." },
    { term: "Join", definition: "Combining rows from two or more tables using a related column." },
    { term: "Normalisation", definition: "Organising tables to reduce redundancy and anomalies." },
    { term: "Primary key", definition: "The attribute that uniquely identifies each row." },
    { term: "Query", definition: "A request for data from a database." },
    { term: "Relation", definition: "A table in the relational model." },
    { term: "Redundancy", definition: "Storing the same data more than once." },
    { term: "SQL", definition: "Structured Query Language for relational databases." },
    { term: "Transaction", definition: "A logical unit of work performed as a whole." },
    { term: "View", definition: "A virtual table defined by a query." },
  ],
  references: [
    "Elmasri, R. and Navathe, S. B. (2015). Fundamentals of Database Systems. 7th ed. Pearson.",
    "Date, C. J. (2019). An Introduction to Database Systems. 8th ed. Pearson.",
    "Oracle (2024). MySQL Reference Manual.",
    "Prince Learning Hub (2026). SQL Practice Workbook. Lagos.",
  ],
};

export const network: Chapter = {
  id: "network",
  title: "Computer Networks, the Internet and the Internet of Things",
  tagline: "Connecting computers and devices: topologies, protocols, addressing, the web and smart devices.",
  units: [
    {
      title: "Network Concepts, Topologies and Devices",
      objectives: [
        "define a computer network and state its benefits",
        "classify networks by size and coverage",
        "describe the common network topologies",
        "explain the functions of network devices",
      ],
      paragraphs: [
        "A computer network is two or more computers connected to share resources such as files, printers and Internet connections. Networks make communication faster, allow information to be shared and reduce cost by using common resources. Networks are classified by coverage: a personal area network (PAN) connects personal devices, a local area network (LAN) covers a building or campus, a metropolitan area network (MAN) covers a city, and a wide area network (MAN) spans countries and continents; the Internet is the largest WAN.",
        "Topology describes how devices are arranged. In a star topology every device connects to a central switch; it is easy to manage and troubleshoot but depends on the central device. In a bus topology all devices share one backbone cable. In a ring topology each device connects to two neighbours. In a mesh topology every device connects to every other, giving the highest reliability at the highest cost.",
        "Network devices perform specific roles. The hub sends data to all ports, the switch forwards data only to the intended port using MAC addresses, the router connects different networks and directs packets using IP addresses, the repeater strengthens a signal, and the access point allows wireless devices to join the network. A firewall filters traffic to protect the network.",
        "Transmission media may be guided (copper cables such as twisted pair and coaxial, and fibre optic) or unguided (radio waves, microwaves and satellite). Fibre optic cable carries data as light and is immune to electrical interference, making it the preferred choice for backbone links.",
      ],
      keyPoints: [
        "LAN covers a building; WAN covers countries; the Internet is the largest WAN.",
        "Star is easy to manage; mesh is most reliable and most expensive.",
        "Switches use MAC addresses; routers use IP addresses.",
        "Fibre optic is fast and immune to electromagnetic interference.",
      ],
      summary:
        "Networks connect computers to share resources. The choice of topology, devices and media determines the cost, speed and reliability of the network.",
      questions: [
        "Define a computer network and give three benefits.",
        "Compare the star and bus topologies.",
        "State the difference between a switch and a router.",
        "Give two advantages of fibre optic cable over copper cable.",
      ],
    },
    {
      title: "Network Models, Protocols and Addressing",
      objectives: [
        "describe the OSI reference model",
        "explain the TCP/IP model and its protocols",
        "describe IP addressing and subnetting basics",
        "explain the client server and peer to peer models",
      ],
      paragraphs: [
        "The Open Systems Interconnection (OSI) model divides network communication into seven layers: physical, data link, network, transport, session, presentation and application. Each layer has a specific job and communicates with the layers above and below it. The model is used for teaching, designing and troubleshooting networks.",
        "The TCP/IP model has four layers: network access, internet, transport and application. The Internet Protocol (IP) handles addressing and routing at the internet layer, while the Transmission Control Protocol (TCP) provides reliable delivery at the transport layer and the User Datagram Protocol (UDP) provides faster, connectionless delivery. Application protocols include HTTP for web pages, SMTP for sending mail, POP3 and IMAP for receiving mail, FTP for file transfer and DNS for name resolution.",
        "An IPv4 address is 32 bits written as four numbers separated by dots, for example 192.168.1.10. Addresses are grouped into classes A to E, and private address ranges are used inside organisations. The subnet mask shows which part of the address identifies the network and which identifies the host. IPv6 uses 128 bit addresses to provide a much larger address space.",
        "In the client server model, clients request services from a central server, which provides security and central management. In the peer to peer model, each computer can act as both client and server. Organisations use the client server model for reliability, while peer to peer networks are simple and inexpensive for small groups.",
      ],
      keyPoints: [
        "OSI has seven layers; TCP/IP has four layers.",
        "TCP is reliable and connection oriented; UDP is fast and connectionless.",
        "DNS converts domain names to IP addresses; DHCP assigns addresses automatically.",
        "Private IPv4 ranges: 10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16.",
      ],
      diagram: "osi",
      table: {
        caption: "Table 8.1 — Common protocols and their default ports",
        headers: ["Protocol", "Purpose", "Port"],
        rows: [
          ["HTTP", "Web pages", "80"],
          ["HTTPS", "Secure web pages", "443"],
          ["FTP", "File transfer", "21"],
          ["SMTP", "Sending email", "25"],
          ["SSH", "Secure remote login", "22"],
        ],
      },
      image: "networking.jpg",
      imageCaption: "Figure 10.2 — Network cabling in a data room",
      summary:
        "Network models organise the complex task of communication into layers. Protocols define the rules, and IP addresses identify devices on the network.",
      questions: [
        "List the seven layers of the OSI model.",
        "Differentiate between TCP and UDP.",
        "What is the function of DNS?",
        "Explain the difference between a private and a public IP address.",
      ],
    },
    {
      title: "The Internet, Web Technologies and Cybersecurity Basics",
      objectives: [
        "explain how the Internet works",
        "describe the services provided by the Internet",
        "explain web browsers, search engines and email",
        "apply safe practices while using the Internet",
      ],
      paragraphs: [
        "The Internet is a worldwide network of networks that communicate using TCP/IP. It grew out of the ARPANET project and is now used by billions of people. Its services include the World Wide Web, electronic mail, file transfer, instant messaging, video conferencing, e-commerce, e-learning and social networking.",
        "The World Wide Web is a collection of web pages linked by hyperlinks and accessed with a browser. Web pages are written in HTML, styled with CSS and made interactive with JavaScript. A web address (URL) shows the protocol, domain name and page. Search engines index the web so that users can find information using keywords, and Boolean operators such as AND, OR and NOT make searches more precise.",
        "Electronic mail is exchanged using protocols: SMTP sends messages and POP3 or IMAP retrieves them. An email address has a user name and a domain name separated by the at sign. Attachments allow files to be sent with messages, and modern systems filter spam and scan attachments for viruses.",
        "Using the Internet safely requires care. Users should use strong passwords, keep software updated, avoid suspicious links and attachments, verify the identity of websites before entering personal information and respect the privacy of others. Phishing, identity theft and cyberbullying are real threats, and reporting them promptly limits the damage.",
      ],
      keyPoints: [
        "The Internet uses TCP/IP and offers web, email, file transfer and e-commerce.",
        "HTML structures pages, CSS styles them and JavaScript makes them interactive.",
        "SMTP sends email; POP3 and IMAP retrieve it.",
        "Stay safe: strong passwords, updates, and caution with links and attachments.",
      ],
      example: {
        heading: "Worked example — reading a URL",
        lines: [
          "https://www.princelearninghub.com/materials/csc101.pdf",
          "https is the protocol (secure web transfer), www.princelearninghub.com is the domain name,",
          "/materials/csc101.pdf is the path to the file on the server.",
          "A padlock symbol in the browser shows that the connection is encrypted.",
        ],
      },
      summary:
        "The Internet and the web are essential tools for learning and business. Knowing how they work and how to use them safely is part of digital literacy.",
      questions: [
        "Describe three services provided by the Internet.",
        "Explain the roles of HTML, CSS and JavaScript in a web page.",
        "What is phishing and how can it be avoided?",
        "Describe how an email travels from the sender to the receiver.",
      ],
    },
    {
      title: "Internet of Things and Emerging Networks",
      objectives: [
        "explain the concept of the Internet of Things",
        "identify sensors, actuators and microcontrollers used in IoT",
        "describe IoT communication protocols",
        "explain IoT applications and security challenges",
      ],
      paragraphs: [
        "The Internet of Things (IoT) refers to everyday physical devices that are embedded with sensors, software and network connectivity so that they can collect and exchange data. Examples include smart thermostats, wearable health monitors, soil moisture sensors and connected vehicles. IoT extends the Internet beyond computers and phones into the physical world.",
        "An IoT system has three main parts. Sensors detect changes in the environment (temperature, light, motion, moisture), actuators carry out actions (opening a valve, switching on a motor), and a microcontroller or single board computer processes the data. Popular platforms include Arduino, which is programmed in C or C++, and Raspberry Pi, which runs Linux and is programmed in Python. The data is often sent to a cloud platform for storage and analysis.",
        "IoT devices communicate using protocols suited to their needs. Wi-Fi provides high data rates over short distances, Bluetooth Low Energy suits wearables, Zigbee supports low power mesh networks and LoRaWAN provides long range communication with very low power. MQTT is a lightweight messaging protocol widely used to carry sensor data to the cloud.",
        "IoT brings benefits in smart homes, healthcare, agriculture and manufacturing, but it also raises security and privacy concerns. Devices with default passwords have been used in large scale attacks, so IoT security must include strong authentication, encrypted communication and regular firmware updates. Designers must also consider data privacy and the amount of power consumed by battery powered devices.",
      ],
      keyPoints: [
        "IoT connects everyday devices to the Internet to collect and share data.",
        "Sensors detect, actuators act, microcontrollers process.",
        "Protocols: Wi-Fi, BLE, Zigbee, LoRaWAN; MQTT for messaging.",
        "IoT security: strong passwords, encryption and firmware updates.",
      ],
      example: {
        heading: "Worked example — smart irrigation",
        lines: [
          "A soil moisture sensor measures the water content of the soil.",
          "The microcontroller compares the reading with a set threshold.",
          "If the soil is dry, the actuator (a water valve) is opened for a fixed time.",
          "The readings are sent to a cloud dashboard so that the farmer can monitor the field from a phone.",
        ],
      },
      summary:
        "The Internet of Things connects the physical world to digital services. It offers great benefits in many industries but must be designed with security and privacy in mind.",
      questions: [
        "Define the Internet of Things and give three examples.",
        "Differentiate between a sensor and an actuator.",
        "Compare Wi-Fi, Zigbee and LoRaWAN for IoT applications.",
        "State three security concerns in IoT and how each can be addressed.",
      ],
    },
  ],
  assignments: [
    {
      title: "Networks and the Internet",
      questions: [
        "Design a network for a three storey academic building, stating the topology, devices and cable types you would use and giving reasons.",
        "Explain the seven layers of the OSI model with one function and one example for each layer.",
        "Describe how you would set up a small IoT project to monitor temperature in a server room, listing the components and protocols involved.",
        "Discuss five ways students can stay safe while using the Internet.",
      ],
    },
  ],
  glossary: [
    { term: "Bandwidth", definition: "The maximum data rate of a communication link." },
    { term: "Client", definition: "A computer that requests services from a server." },
    { term: "DNS", definition: "The system that converts domain names into IP addresses." },
    { term: "Firewall", definition: "A device or program that filters network traffic." },
    { term: "Gateway", definition: "A device that connects two different networks." },
    { term: "IoT", definition: "The Internet of Things; everyday devices connected to the Internet." },
    { term: "IP address", definition: "The numeric address that identifies a device on a network." },
    { term: "LAN", definition: "A local area network covering a building or campus." },
    { term: "Protocol", definition: "A set of rules governing communication between devices." },
    { term: "Router", definition: "A device that forwards packets between networks." },
    { term: "Sensor", definition: "A device that detects a physical change." },
    { term: "Server", definition: "A computer that provides services to clients." },
    { term: "Switch", definition: "A device that forwards frames using MAC addresses." },
    { term: "Topology", definition: "The arrangement of devices in a network." },
    { term: "URL", definition: "The address of a resource on the web." },
  ],
  references: [
    "Tanenbaum, A. S. and Wetherall, D. J. (2021). Computer Networks. 6th ed. Pearson.",
    "Forouzan, B. A. (2021). Data Communications and Networking. 6th ed. McGraw-Hill.",
    "Hakim, A. and Bhatt, A. (2022). Practical Internet of Things. Apress.",
    "Prince Learning Hub (2026). Networking and IoT Practical Notes. Lagos.",
  ],
};

export const se: Chapter = {
  id: "se",
  title: "Software Engineering and Project Management",
  tagline: "Building reliable software on time and within budget: processes, requirements, design, testing and management.",
  units: [
    {
      title: "Software Engineering and the Software Life Cycle",
      objectives: [
        "explain the meaning and goals of software engineering",
        "describe the phases of the software life cycle",
        "compare software process models",
        "explain process assessment and metrics",
      ],
      paragraphs: [
        "Software engineering is the application of a systematic, disciplined and quantifiable approach to the development, operation and maintenance of software. It emerged as a discipline in the 1960s when large projects were late, over budget and unreliable, a situation known as the software crisis. The goals are to produce software that is correct, reliable, efficient, maintainable and delivered on time.",
        "The software life cycle has several phases: requirements analysis (what the system must do), design (how it will be built), implementation (coding), testing (checking that it works), deployment (release) and maintenance (changes and repairs after release). Each phase produces documentation that guides the next, and reviews are held to catch errors early, when they are cheapest to fix.",
        "Process models describe how these phases are organised. The waterfall model completes each phase before starting the next and suits projects with stable requirements. The incremental model delivers the system in usable pieces. The spiral model is risk driven and suits large, risky projects. Agile methods such as Scrum and Extreme Programming deliver working software in short iterations with close customer involvement.",
        "Process quality is assessed using models such as the Capability Maturity Model Integration (CMMI), which rates organisations from initial (level 1) to optimising (level 5). Metrics such as defects per thousand lines of code, function points and cycle time help managers to measure progress and improve the process.",
      ],
      keyPoints: [
        "Software engineering applies systematic methods to build reliable software.",
        "Life cycle: requirements, design, implementation, testing, deployment, maintenance.",
        "Waterfall suits stable requirements; agile suits changing requirements.",
        "CMMI measures process maturity from level 1 to level 5.",
      ],
      diagram: "sdlc",
      summary:
        "Software engineering brings discipline to software development. Following a defined process and measuring quality produces systems that are reliable and maintainable.",
      questions: [
        "Define software engineering and state three of its goals.",
        "List the phases of the software life cycle in order.",
        "Compare the waterfall and spiral models.",
        "What is CMMI and how does it help an organisation?",
      ],
    },
    {
      title: "Requirements, Design and Modelling with UML",
      objectives: [
        "elicit and specify software requirements",
        "distinguish functional from non functional requirements",
        "apply UML diagrams for analysis and design",
        "explain architectural styles and design principles",
      ],
      paragraphs: [
        "Requirements engineering establishes what the system must do. Requirements are gathered through interviews, questionnaires, observation, document analysis and workshops. They are classified as functional requirements (the functions the system performs) and non functional requirements (qualities such as performance, security and usability). Requirements must be complete, consistent, unambiguous and verifiable.",
        "Design turns requirements into a blueprint for construction. Good design has high cohesion (each module does one thing well) and low coupling (modules are independent). Architectural styles include layered architecture, client server, pipe and filter and microservices. Design patterns such as the observer, factory and singleton provide proven solutions to recurring problems.",
        "The Unified Modeling Language (UML) provides standard diagrams for modelling. Use case diagrams show actors and system functions. Class diagrams show classes, attributes and relationships. Sequence diagrams show how objects interact over time. Activity diagrams show workflows, and state diagrams show how an object changes state. UML keeps the development team and the customer working from a shared understanding.",
        "Modelling also supports communication with stakeholders who are not technical. A well drawn use case diagram, for example, allows a bank manager to confirm that every business operation is covered before coding begins, which is far cheaper than discovering the omission after release.",
      ],
      keyPoints: [
        "Functional requirements describe what; non functional describe how well.",
        "Good design: high cohesion and low coupling.",
        "UML: use case, class, sequence, activity and state diagrams.",
        "Early reviews of models are cheaper than late code fixes.",
      ],
      example: {
        heading: "Worked example — requirements specification",
        lines: [
          "Functional requirement: 'The system shall allow a student to register for a course if prerequisites are met.'",
          "Non functional requirement: 'The registration page shall load within 2 seconds for 500 concurrent users.'",
          "Both are testable: the first with a test case, the second with a load test.",
          "Requirements that cannot be tested should be rewritten before design begins.",
        ],
      },
      summary:
        "Clear requirements and good design are the foundation of successful software. UML provides the vocabulary for modelling systems before they are built.",
      questions: [
        "Differentiate between functional and non functional requirements with examples.",
        "Explain cohesion and coupling in software design.",
        "Draw a use case diagram for a library system.",
        "Why is UML useful in software development?",
      ],
    },
    {
      title: "Software Testing, Quality and Maintenance",
      objectives: [
        "explain the principles and levels of testing",
        "apply black box and white box techniques",
        "describe software quality assurance",
        "explain the types of software maintenance",
      ],
      paragraphs: [
        "Testing checks that the software meets its requirements and is free from serious defects. The main levels are unit testing (individual modules), integration testing (modules working together), system testing (the complete system) and acceptance testing (confirming that the system meets the user's needs). Testing can show the presence of defects but cannot prove their absence.",
        "Black box testing examines the software from the outside using techniques such as equivalence partitioning and boundary value analysis. White box testing examines the code and aims for coverage of statements, branches and paths. Reviews and inspections are static techniques that examine documents and code without running them, and they find many defects early.",
        "Quality assurance is the set of activities that ensure the development process produces quality software. It includes standards, reviews, testing plans, configuration management and measurement. Quality control is the product focused activity of finding defects. Both are needed, and standards such as ISO 9001 and ISO/IEC 25010 describe quality systems and product quality characteristics.",
        "Maintenance is often the most expensive phase of the life cycle. Corrective maintenance fixes defects, adaptive maintenance adapts the system to new environments, perfective maintenance adds improvements requested by users, and preventive maintenance improves the structure to avoid future problems. Systems that are not maintained gradually decay and become difficult to change.",
      ],
      keyPoints: [
        "Levels: unit, integration, system and acceptance testing.",
        "Black box uses specifications; white box uses code structure.",
        "QA is process focused; QC is product focused.",
        "Maintenance: corrective, adaptive, perfective and preventive.",
      ],
      table: {
        caption: "Table 9.1 — Types of testing",
        headers: ["Type", "Focus", "Performed by"],
        rows: [
          ["Unit testing", "Individual modules", "Developers"],
          ["Integration testing", "Interfaces between modules", "Developers / testers"],
          ["System testing", "Whole system", "Test team"],
          ["Acceptance testing", "Business requirements", "End users"],
          ["Regression testing", "Impact of changes", "Test team"],
        ],
      },
      image: "group-study.jpg",
      imageCaption: "Figure 11.3 — Team work and review in software projects",
      summary:
        "Testing and quality assurance protect the user from defects, and maintenance keeps the software useful throughout its life. Both are core responsibilities of the software engineer.",
      questions: [
        "List the four levels of testing and who performs each.",
        "Differentiate between black box and white box testing.",
        "What is the difference between quality assurance and quality control?",
        "Describe the four types of software maintenance.",
      ],
    },
    {
      title: "Project Management, Configuration Management and Professional Practice",
      objectives: [
        "explain the responsibilities of a project manager",
        "plan and schedule a software project",
        "describe software configuration management",
        "explain the legal and ethical issues in software engineering",
      ],
      paragraphs: [
        "Software projects fail for many reasons: unclear requirements, poor estimation, weak management and changing scope. Project management applies planning, organising, staffing, directing and controlling to deliver the project on time, within budget and to the required quality. The project manager draws up a plan, estimates effort using techniques such as function points and COCOMO, allocates resources and monitors progress against milestones.",
        "Scheduling tools include the work breakdown structure, Gantt charts and network analysis with the critical path method. Risk management identifies what could go wrong and plans responses. Earned value management compares the work planned with the work done and the money spent to show whether a project is on track.",
        "Software configuration management keeps track of every version of every artefact. It includes configuration identification, change control through a change control board, status accounting and auditing. Version control systems such as Git and Subversion allow teams to work together without overwriting each other's work.",
        "Professional practice includes contracts, licensing, intellectual property and ethics. Software is protected by copyright, patents and trade secrets, and it is licensed rather than sold. Engineers must respect confidentiality, be honest in their estimates, avoid plagiarism and keep their skills current through continuing professional development.",
      ],
      keyPoints: [
        "Project management delivers scope, time, cost and quality.",
        "The critical path is the longest path through the project network.",
        "SCM: identification, change control, status accounting and auditing.",
        "Software is protected by copyright, patents and trade secrets.",
      ],
      example: {
        heading: "Worked example — simple project scheduling",
        lines: [
          "Activities: Analysis (10 days), Design (15 days), Coding (30 days), Testing (20 days).",
          "If they run one after the other, the project takes 10 + 15 + 30 + 20 = 75 days.",
          "If testing can start 10 days before coding ends, the project takes 65 days (fast tracking).",
          "Adding a second programmer to shorten coding is called crashing and increases the cost.",
        ],
      },
      summary:
        "Managing a software project requires planning, estimation, monitoring and control, supported by configuration management and professional conduct.",
      questions: [
        "State four responsibilities of a software project manager.",
        "What is the critical path in a project schedule?",
        "Explain the activities of software configuration management.",
        "Discuss three legal issues that affect software engineers.",
      ],
    },
  ],
  assignments: [
    {
      title: "Software Engineering",
      questions: [
        "Explain the software life cycle and compare the waterfall and agile approaches, stating when each is appropriate.",
        "Write a software requirements specification for a CBT examination system, including three functional and three non functional requirements.",
        "Prepare a test plan for the CBT system, describing the levels of testing, test cases and acceptance criteria.",
        "Discuss how software configuration management and project management work together to deliver a successful project.",
      ],
    },
  ],
  glossary: [
    { term: "Acceptance testing", definition: "Testing by users to confirm the system meets business needs." },
    { term: "Agile", definition: "Development in short iterations with close customer collaboration." },
    { term: "Baseline", definition: "A formally approved version of a configuration item." },
    { term: "Coupling", definition: "The degree of dependence between modules." },
    { term: "Cohesion", definition: "The degree to which a module performs a single task." },
    { term: "Critical path", definition: "The longest sequence of activities in a project." },
    { term: "Maintenance", definition: "Modifying software after delivery to correct or improve it." },
    { term: "Requirement", definition: "A condition or capability the system must provide." },
    { term: "Risk", definition: "An uncertain event that could affect the project." },
    { term: "SDLC", definition: "Software development life cycle." },
    { term: "Sprint", definition: "A short, time-boxed development cycle in Scrum." },
    { term: "Testing", definition: "Evaluating software to find defects and build confidence." },
    { term: "UML", definition: "Unified Modeling Language for object oriented modelling." },
    { term: "Use case", definition: "A description of interactions between an actor and the system." },
    { term: "Waterfall", definition: "A linear, sequential software process model." },
  ],
  references: [
    "Sommerville, I. (2015). Software Engineering. 10th ed. Pearson.",
    "Pressman, R. S. and Maxim, B. R. (2019). Software Engineering: A Practitioner's Approach. 9th ed. McGraw-Hill.",
    "Project Management Institute (2021). PMBOK Guide. 7th ed.",
    "Prince Learning Hub (2026). Software Engineering Case Studies. Lagos.",
  ],
};

export const security: Chapter = {
  id: "security",
  title: "Security, Ethics and Professional Practice",
  tagline: "Protecting systems and data, and using technology responsibly and lawfully.",
  units: [
    {
      title: "Threats, Vulnerabilities and Attacks",
      objectives: [
        "explain the meaning of information security",
        "identify common threats and attacks",
        "describe how malware spreads",
        "apply safe computing practices",
      ],
      paragraphs: [
        "Information security protects data and systems from unauthorised access, use, disclosure, disruption or destruction. The three goals are confidentiality (only authorised people can see the data), integrity (data is accurate and unaltered) and availability (systems are ready when needed). These are known as the CIA triad.",
        "Threats come in many forms. Malware includes viruses that attach to files, worms that spread through networks, trojans that pretend to be useful software, spyware that watches the user and ransomware that encrypts files and demands payment. Phishing uses fake messages to steal passwords, and social engineering manipulates people into giving away confidential information.",
        "Attacks also include denial of service, where a server is flooded with requests until it cannot serve legitimate users, and man in the middle attacks, where communication is intercepted. Vulnerabilities are weaknesses in software or procedures that attackers exploit, and they are often caused by unpatched software, weak passwords or misconfiguration.",
        "Safe computing practices reduce risk. Use strong, unique passwords and enable multi factor authentication. Keep the operating system and applications updated. Use antivirus and firewall protection. Avoid suspicious links and attachments. Back up important data regularly. These simple measures prevent the majority of successful attacks.",
      ],
      keyPoints: [
        "CIA triad: confidentiality, integrity and availability.",
        "Malware: viruses, worms, trojans, spyware and ransomware.",
        "Phishing and social engineering target people, not just machines.",
        "Prevention: strong passwords, updates, antivirus, backups and caution.",
      ],
      table: {
        caption: "Table 10.1 — Common threats and countermeasures",
        headers: ["Threat", "How it works", "Countermeasure"],
        rows: [
          ["Phishing", "Fake email steals credentials", "Verify sender, never share passwords"],
          ["Ransomware", "Encrypts files for payment", "Backups, updates, antivirus"],
          ["DoS attack", "Floods a server with traffic", "Firewalls, rate limiting"],
          ["Trojan", "Malware disguised as software", "Install from trusted sources"],
          ["SQL injection", "Malicious input to a database", "Parameterised queries"],
        ],
      },
      image: "cybersecurity.jpg",
      imageCaption: "Figure 12.1 — Protecting systems and data",
      summary:
        "Security threats are diverse and constantly changing. Understanding them and applying basic safeguards protects personal data and organisational systems.",
      questions: [
        "Explain the CIA triad.",
        "Differentiate between a virus and a worm.",
        "What is phishing and how can it be recognised?",
        "State five safe computing practices.",
      ],
    },
    {
      title: "Cryptography, Access Control and Security Tools",
      objectives: [
        "explain the difference between symmetric and asymmetric encryption",
        "describe hashing and digital signatures",
        "explain authentication, authorisation and access control",
        "describe firewalls, antivirus and intrusion detection",
      ],
      paragraphs: [
        "Cryptography protects information by converting it into an unreadable form. Symmetric encryption uses the same key to encrypt and decrypt, and is fast and suitable for large amounts of data; examples are AES and DES. Asymmetric encryption uses a pair of keys, a public key and a private key; the public key encrypts and the private key decrypts. RSA is the best known example and it is used to exchange keys securely.",
        "Hashing converts data into a fixed length value that cannot be reversed. It is used to check the integrity of files and to store passwords. A salt (random value) is added to each password before hashing to prevent attacks using precomputed tables. Algorithms such as SHA-256, bcrypt and Argon2 are used for these purposes.",
        "Authentication verifies who a user is, while authorisation determines what that user may do. Access control models include discretionary access control, mandatory access control and role based access control. The principle of least privilege gives each user only the permissions required for the work.",
        "Security tools include firewalls that filter traffic, antivirus software that detects malicious code, intrusion detection systems that monitor for suspicious activity and encryption tools that protect stored and transmitted data. Security works best in layers, so that failure of one control does not expose the whole system.",
      ],
      keyPoints: [
        "Symmetric encryption uses one key; asymmetric uses a public/private key pair.",
        "Hashing is one way and is used for passwords and file integrity.",
        "Authentication identifies; authorisation grants permissions.",
        "Use defence in depth: firewalls, antivirus, encryption and least privilege.",
      ],
      example: {
        heading: "Worked example — securing a password",
        lines: [
          "A user chooses the password 'Godisgood2026'.",
          "The system generates a random salt, e.g. 'a7f3', and stores salt + password.",
          "It computes hash = Argon2('a7f3Godisgood2026') and stores the salt with the hash.",
          "When the user logs in, the system repeats the process and compares the hashes; the plain password is never stored.",
        ],
      },
      summary:
        "Cryptography, access control and layered security tools protect data. Applying them correctly is a core skill of the security professional.",
      questions: [
        "Compare symmetric and asymmetric encryption.",
        "What is a digital signature and what does it guarantee?",
        "Explain the principle of least privilege.",
        "Describe the role of a firewall in network security.",
      ],
    },
    {
      title: "Computer Ethics, Law and Professional Conduct",
      objectives: [
        "explain computer ethics and its importance",
        "describe Nigerian laws on cybercrime and data protection",
        "explain intellectual property and software licensing",
        "apply professional codes of conduct",
      ],
      paragraphs: [
        "Computer ethics deals with the moral principles that guide the use of technology. It covers issues such as privacy, accuracy, property and access. Users must respect the privacy of others, use information accurately, respect intellectual property and accept that access to technology brings responsibility. Unauthorised access to computer systems, even out of curiosity, is unethical and illegal.",
        "Nigeria has laws that address the misuse of computers. The Cybercrimes (Prohibition, Prevention, etc.) Act 2015 criminalises offences such as hacking, cyberstalking, identity theft and online fraud. The Nigeria Data Protection Act 2023 governs how personal data is collected and processed and established the Nigeria Data Protection Commission. Professionals must know these laws and comply with them.",
        "Intellectual property protects the work of creators. Copyright protects the expression of ideas, such as source code and documentation. Patents protect inventions, trademarks protect brand names and logos, and trade secrets protect confidential business information. Software is normally licensed to users rather than sold, and the licence states how it may be used; copying licensed software without permission is software piracy.",
        "Professional bodies publish codes of conduct. The ACM/IEEE Software Engineering Code of Ethics requires professionals to act in the public interest, avoid harm, be honest and reliable, maintain integrity and confidentiality, and improve their professional competence. Where these values conflict with instructions from an employer, the professional should raise the concern through the proper channels.",
      ],
      keyPoints: [
        "Ethics: respect privacy, accuracy, property and access.",
        "Nigerian law: Cybercrimes Act 2015 and Nigeria Data Protection Act 2023.",
        "Copyright protects code; patents protect inventions; trademarks protect brands.",
        "Professional codes require honesty, confidentiality and competence.",
      ],
      summary:
        "Ethical and legal awareness is as important as technical skill. Computing professionals must protect users, respect the law and uphold the reputation of the profession.",
      questions: [
        "What is computer ethics? State four issues it addresses.",
        "Describe two provisions of the Nigerian Cybercrimes Act.",
        "Differentiate between copyright, patent and trademark.",
        "Explain why software piracy is both illegal and unethical.",
      ],
    },
    {
      title: "Entrepreneurship and Career Development in Computing",
      objectives: [
        "explain entrepreneurship and the lean startup approach",
        "describe business models for software products",
        "explain intellectual property in business",
        "plan a career and professional development path",
      ],
      paragraphs: [
        "Entrepreneurship is the process of identifying opportunities and taking the risk of creating value through a new venture. Software entrepreneurs build products and services that solve real problems. The lean startup approach encourages building a minimum viable product, measuring how customers respond and learning from the results before investing heavily.",
        "Business models describe how a venture creates and captures value. Common models in software include one time licences, subscriptions (software as a service), advertising supported free services, freemium products and consulting. The business model canvas summarises the value proposition, customers, channels, revenue and costs on a single page.",
        "Intellectual property is often the most valuable asset of a software business. Founders should decide early how the code will be licensed, register trademarks where appropriate and protect trade secrets with non disclosure agreements. In Nigeria, business names and companies are registered with the Corporate Affairs Commission.",
        "Career development requires continuous learning. Computing professionals should master the fundamentals, specialise in an area of demand such as cybersecurity, data science, mobile development or cloud computing, build a portfolio of projects, and obtain relevant certifications. Professional associations, mentorship and participation in the wider community all support growth.",
      ],
      keyPoints: [
        "Lean startup: build, measure and learn.",
        "Software models: licence, subscription, freemium, advertising and consulting.",
        "Protect intellectual property early; register with the CAC in Nigeria.",
        "Grow a career through fundamentals, specialisation, projects and certifications.",
      ],
      summary:
        "Entrepreneurship allows computing professionals to create value and employment. Sound business practice, protected intellectual property and continuous learning are the foundations of success.",
      questions: [
        "What is a minimum viable product and why is it useful?",
        "Compare the subscription and one time licence business models.",
        "State three ways a software business can protect its intellectual property.",
        "Outline a five year professional development plan for a computing graduate.",
      ],
    },
  ],
  assignments: [
    {
      title: "Security and Professional Practice",
      questions: [
        "Explain the CIA triad and describe how a bank protects each of the three goals.",
        "A staff member receives an email asking for the school's password. Describe the attack and the correct response.",
        "Discuss the provisions of the Nigeria Data Protection Act 2023 and their effect on a school's student records.",
        "Write an essay of not less than 500 words on 'Ethical issues in the use of artificial intelligence and data'.",
      ],
    },
  ],
  glossary: [
    { term: "Access control", definition: "Rules that determine who may use which resources." },
    { term: "Authentication", definition: "Verifying the identity of a user." },
    { term: "Authorisation", definition: "Granting permissions to an authenticated user." },
    { term: "Confidentiality", definition: "Keeping data from unauthorised disclosure." },
    { term: "Cryptography", definition: "Protecting information by encoding it." },
    { term: "Encryption", definition: "Converting data into an unreadable coded form." },
    { term: "Firewall", definition: "A system that filters network traffic by rules." },
    { term: "Hashing", definition: "Converting data to a fixed length value that cannot be reversed." },
    { term: "Integrity", definition: "Ensuring data is accurate and unaltered." },
    { term: "Malware", definition: "Software designed to damage or exploit systems." },
    { term: "Phishing", definition: "Fraudulent messages that trick users into revealing secrets." },
    { term: "Plagiarism", definition: "Presenting another person's work as your own." },
    { term: "Ransomware", definition: "Malware that encrypts files and demands payment." },
    { term: "Salt", definition: "Random data added to a password before hashing." },
    { term: "Vulnerability", definition: "A weakness that may be exploited by an attacker." },
  ],
  references: [
    "Stallings, W. (2017). Cryptography and Network Security: Principles and Practice. 7th ed. Pearson.",
    "Nigerian Communications Commission (2024). Cybersecurity Guidelines.",
    "Federal Republic of Nigeria (2015). Cybercrimes (Prohibition, Prevention, etc.) Act.",
    "Prince Learning Hub (2026). Cybersecurity Awareness Handbook. Lagos.",
  ],
};

export const research: Chapter = {
  id: "research",
  title: "Study Skills, Library Use and Research Methods",
  tagline: "Learning how to learn: libraries, information literacy, academic writing and research practice.",
  units: [
    {
      title: "Libraries, Information Resources and Digital Literacy",
      objectives: [
        "explain the role and types of libraries",
        "use library catalogues and digital resources",
        "apply information literacy skills",
        "evaluate information sources for credibility",
      ],
      paragraphs: [
        "A library is an organised collection of information resources made available for use. Types include academic libraries serving universities and polytechnics, public libraries serving communities, special libraries serving organisations and digital libraries available online. The library is central to learning because it provides access to books, journals, databases and expert guidance.",
        "Library resources include print materials (textbooks, reference works, journals, newspapers) and digital materials (e books, e journals, online databases and institutional repositories). Materials are organised using classification schemes such as the Dewey Decimal Classification and the Library of Congress Classification, and they are found through the Online Public Access Catalogue (OPAC), which can be searched by author, title, subject or call number.",
        "Information literacy is the ability to recognise when information is needed and to find, evaluate and use it effectively. Searching uses keywords and Boolean operators (AND, OR, NOT), phrase searching and truncation. Evaluation frameworks such as the CRAAP test ask about currency, relevance, authority, accuracy and purpose before information is used.",
        "Digital literacy extends these skills to online tools: e libraries, academic databases such as Google Scholar and JSTOR, reference management tools such as Zotero and Mendeley, and collaboration platforms such as Google Workspace and Microsoft Teams. Students who master these tools complete assignments faster and produce better work.",
      ],
      keyPoints: [
        "Academic, public, special and digital libraries serve different users.",
        "Find materials with the OPAC using author, title, subject or call number.",
        "Boolean operators: AND narrows, OR broadens, NOT excludes.",
        "Evaluate sources with the CRAAP test before using them.",
      ],
      table: {
        caption: "Table 11.1 — Types of libraries",
        headers: ["Type", "Serves", "Example collection"],
        rows: [
          ["Academic", "Students and lecturers", "Textbooks, journals, theses"],
          ["Public", "The general community", "Fiction, reference, newspapers"],
          ["Special", "An organisation or profession", "Law reports, medical records"],
          ["Digital", "Remote users online", "E books, databases, repositories"],
        ],
      },
      image: "library.jpg",
      imageCaption: "Figure 13.1 — Library and digital information resources",
      summary:
        "Libraries provide the resources for learning, and information literacy tells the student how to find, judge and use those resources responsibly.",
      questions: [
        "List four types of libraries and give an example of each.",
        "Explain how the OPAC is used to find a book.",
        "What are Boolean operators? Give an example search.",
        "Apply the CRAAP test to a website you used recently.",
      ],
    },
    {
      title: "Study Skills and Examination Preparation",
      objectives: [
        "manage study time effectively",
        "apply reading and note-taking techniques",
        "summarise and revise efficiently",
        "prepare properly for examinations and presentations",
      ],
      paragraphs: [
        "Effective study begins with time management. Prepare a realistic timetable that covers every subject, set specific goals for each study session, and break work into focused blocks of about twenty five minutes separated by short breaks. Begin revision early, review notes within twenty four hours of a lecture, and keep a list of tasks to avoid forgetting important work.",
        "Reading strategies save time. Skimming gives the general idea of a text quickly by reading headings and summaries. Scanning searches quickly for a particular fact or figure. Critical reading examines arguments, evidence and assumptions. Reading with a purpose, and marking or highlighting key points, improves understanding and recall.",
        "Good notes capture meaning rather than every word. The Cornell method divides the page into cues, notes and a summary. Mind mapping shows the relationships between ideas. Summarising in your own words is one of the most effective ways to learn, because it forces you to understand before you write.",
        "Examinations test understanding and recall. Prepare by revising past questions, practising under timed conditions, and using active recall rather than simply re-reading. During the examination, read the instructions, plan the time for each question, answer what is asked and review if time allows. For presentations, prepare early, structure the talk clearly, practise aloud and keep slides simple.",
      ],
      keyPoints: [
        "Study in focused blocks and follow a written timetable.",
        "Skim for the big picture, scan for facts, read critically for arguments.",
        "Summarise notes in your own words using the Cornell method.",
        "Revise actively with past questions and timed practice.",
      ],
      example: {
        heading: "Worked example — a weekly study plan",
        lines: [
          "Monday to Friday: two focused blocks of 25 minutes per subject, with 5 minute breaks.",
          "Saturday: revise the week's notes and complete one past question per subject.",
          "Sunday: light review and planning for the coming week.",
          "Total: about 15 focused hours per week, which is far more effective than long, unstructured hours.",
        ],
      },
      summary:
        "Good study skills multiply the value of the time spent learning. Planning, active reading, summarising and practising under exam conditions lead to better results.",
      questions: [
        "Explain the Pomodoro technique and its benefit.",
        "Compare skimming and scanning.",
        "Describe the Cornell note-taking method.",
        "Give five tips for preparing for a CBT examination.",
      ],
    },
    {
      title: "Academic Writing, Referencing and Avoiding Plagiarism",
      objectives: [
        "structure an academic essay or report",
        "use APA, MLA and IEEE citation styles",
        "paraphrase and quote correctly",
        "avoid plagiarism in all forms of assessment",
      ],
      paragraphs: [
        "Academic writing presents ideas clearly and supports them with evidence. An essay has an introduction with a thesis, a body with paragraphs that develop the argument and a conclusion that summarises. A report usually adds sections such as abstract, methodology, findings and references. Each paragraph should open with a topic sentence, give evidence and explain how the evidence supports the point.",
        "Referencing acknowledges the sources used. In text citations point the reader to a reference list at the end. APA uses an author and date style, for example (Okafor, 2023). IEEE uses numbers in square brackets, for example [1]. MLA uses author and page number. The chosen style must be used consistently throughout the work.",
        "Plagiarism is presenting the work or ideas of another person as your own without acknowledgement. It includes copying text without quotation marks, submitting another person's work, and reusing your own previous work without permission. It is a serious academic offence and can lead to failure or expulsion.",
        "To avoid plagiarism, take notes in your own words, record full bibliographic details as you read, quote directly only when the exact words matter, and cite every source. Software tools may be used to check similarity before submission. Academic integrity is the foundation of a credible qualification.",
      ],
      keyPoints: [
        "An essay needs an introduction, evidence based body and a conclusion.",
        "APA = author and date; IEEE = numbered references; MLA = author and page.",
        "Plagiarism includes copying without quotation marks and resubmitting your own work.",
        "Record sources as you read and cite every idea that is not your own.",
      ],
      example: {
        heading: "Worked example — citation styles",
        lines: [
          "APA (in text): (Okafor, 2023) with a reference list entry: Okafor, A. (2023). Computing in Africa. Lagos Press.",
          "IEEE (in text): [1] with a reference list entry: [1] A. Okafor, Computing in Africa. Lagos Press, 2023.",
          "Direct quote (APA): \"Data is the new oil\" (Okafor, 2023, p. 14).",
          "Paraphrase (APA): Okafor (2023) argues that data has become a key economic resource.",
        ],
      },
      summary:
        "Academic writing and correct referencing are essential skills for every student. They protect you from plagiarism and give your work authority and credibility.",
      questions: [
        "List the parts of a standard academic essay.",
        "Write an APA style reference for a book you have used this semester.",
        "What is plagiarism? Give three examples.",
        "How does paraphrasing differ from quoting?",
      ],
    },
    {
      title: "Research Methodology and Project Writing",
      objectives: [
        "explain the meaning and types of research",
        "design research questions and hypotheses",
        "describe sampling and data collection methods",
        "structure a final year project report",
      ],
      paragraphs: [
        "Research is a systematic investigation carried out to discover new knowledge or to solve a problem. Basic (pure) research expands theory, while applied research solves practical problems. Research may be quantitative (collecting numbers), qualitative (collecting opinions and observations) or mixed methods. In computing, design science research creates and evaluates artefacts such as systems and algorithms.",
        "Good research begins with a clear problem statement and specific, measurable, achievable, relevant and time bound (SMART) objectives. A hypothesis is a testable statement predicting a relationship between variables. A literature review shows what is already known and identifies the gap that the research will fill.",
        "Sampling selects a part of a population for study. Probability sampling (random, stratified, systematic) gives every member a known chance of selection, while non probability sampling (convenience, snowball) does not. Data is collected through questionnaires, interviews, observation, experiments and existing documents. Instruments must be valid (measuring what is intended) and reliable (giving consistent results).",
        "A project report normally contains the title page, abstract, introduction, literature review, methodology, analysis or implementation, results, discussion, conclusion and references, with appendices where necessary. Research must be ethical: participants give informed consent, data is kept confidential, and sources are properly cited.",
      ],
      keyPoints: [
        "Basic research expands knowledge; applied research solves problems.",
        "SMART objectives are specific, measurable, achievable, relevant and time bound.",
        "Sampling may be probability or non probability; instruments must be valid and reliable.",
        "A project report needs abstract, introduction, literature review, methodology, results and conclusion.",
      ],
      table: {
        caption: "Table 11.2 — Data collection methods compared",
        headers: ["Method", "Strength", "Limitation"],
        rows: [
          ["Questionnaire", "Reaches many respondents quickly", "Low response rate possible"],
          ["Interview", "Depth and follow up questions", "Time consuming"],
          ["Observation", "Records actual behaviour", "Observer bias"],
          ["Experiment", "Establishes cause and effect", "Control can be difficult"],
        ],
      },
      summary:
        "Research methods give structure to investigation. A clear problem, sound sampling, valid instruments and ethical conduct produce findings that can be trusted.",
      questions: [
        "Differentiate between basic and applied research.",
        "What is a hypothesis? Write one for a study of student performance in CBT.",
        "Compare probability and non probability sampling.",
        "List the sections of a final year project report.",
      ],
    },
  ],
  assignments: [
    {
      title: "Study Skills and Research",
      questions: [
        "Prepare a personal study timetable for a semester and explain the principles behind it.",
        "Search the library catalogue for five books on your course and present the results in standard reference format.",
        "Write a literature review of not less than 600 words on 'The effectiveness of computer based testing'.",
        "Design a questionnaire of ten items to investigate students' use of the Prince Learning Hub platform, and explain your sampling method.",
      ],
    },
  ],
  glossary: [
    { term: "Abstract", definition: "A brief summary of a research work." },
    { term: "APA", definition: "American Psychological Association citation style (author and date)." },
    { term: "Boolean operators", definition: "AND, OR and NOT used to combine search terms." },
    { term: "Call number", definition: "The code on a book showing where it is shelved." },
    { term: "Citation", definition: "A reference to a source used in your work." },
    { term: "Copyright", definition: "The legal right that protects an original work." },
    { term: "Digital literacy", definition: "The ability to use digital tools to find and share information." },
    { term: "Hypothesis", definition: "A testable statement predicting a relationship." },
    { term: "IEEE", definition: "A numbered citation style common in engineering." },
    { term: "Literature review", definition: "A summary and evaluation of existing research." },
    { term: "OPAC", definition: "Online Public Access Catalogue for finding library materials." },
    { term: "Plagiarism", definition: "Using another person's work without acknowledgement." },
    { term: "Population", definition: "The whole group a study aims to describe." },
    { term: "Sample", definition: "The part of a population selected for study." },
    { term: "Validity", definition: "The degree to which a tool measures what it should." },
  ],
  references: [
    "Kothari, C. R. (2019). Research Methodology: Methods and Techniques. 4th ed. New Age International.",
    "American Psychological Association (2020). Publication Manual of the APA. 7th ed.",
    "Booth, A., Papaioannou, D. and Sutton, A. (2012). Systematic Approaches to a Successful Literature Review. Sage.",
    "Prince Learning Hub (2026). Study Skills and Research Handbook. Lagos.",
  ],
};
