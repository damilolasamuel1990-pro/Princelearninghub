import { StandardFonts, PDFDocument, rgb, type PDFImage, type PDFPage, type PDFFont as Font } from "pdf-lib";
import { readFileSync } from "fs";
import path from "path";
import { pdfSafe } from "@/lib/pdf";
import { CONTACT } from "@/lib/academics";

export type Unit = {
  title: string;
  objectives: string[];
  paragraphs: string[];
  keyPoints?: string[];
  table?: { caption: string; headers: string[]; rows: string[][] };
  diagram?: "blocks" | "osi" | "flowchart" | "sdlc" | "tree";
  image?: string;
  imageCaption?: string;
  example?: { heading: string; lines: string[] };
  summary: string;
  questions: string[];
};

export type Chapter = {
  id: string;
  title: string;
  tagline: string;
  units: Unit[];
  assignments: { title: string; questions: string[] }[];
  glossary: { term: string; definition: string }[];
  references: string[];
};

export type Practice = {
  question: string;
  options: string[];
  answerIndex: number;
  explanation: string;
};

export type HandoutInput = {
  courseCode: string;
  title: string;
  department: string;
  level: string;
  semester: string;
  categoryLabel: string;
  description: string;
  outcomes: string[];
  chapters: Chapter[];
  practice: Practice[];
};

/* ------------------------------------------------------------------ */
/* palette                                                             */
/* ------------------------------------------------------------------ */
const NAVY = rgb(0.06, 0.15, 0.25);
const NAVY_SOFT = rgb(0.11, 0.22, 0.35);
const GOLD = rgb(0.79, 0.65, 0.36);
const GOLD_PALE = rgb(0.95, 0.88, 0.72);
const INK = rgb(0.16, 0.19, 0.25);
const MUTED = rgb(0.42, 0.47, 0.55);
const RULE = rgb(0.82, 0.82, 0.8);
const CREAM = rgb(0.985, 0.975, 0.955);
const BOX = rgb(0.945, 0.955, 0.965);
const GOLD_BOX = rgb(0.975, 0.945, 0.875);

const PAGE_W = 595.28;
const PAGE_H = 841.89;
const M = 56;
const CW = PAGE_W - M * 2;

const LECTURER = "Mr. Damilola";
const SESSION = "2025 / 2026 Academic Session";

function imageBytes(file: string) {
  try {
    return readFileSync(path.join(process.cwd(), "public", "images", file));
  } catch {
    return null;
  }
}

/* ------------------------------------------------------------------ */
/* page furniture                                                      */
/* ------------------------------------------------------------------ */
type Face = { serif: Font; serifBold: Font; sans: Font; sansBold: Font; sansItalic: Font };

async function faces(doc: PDFDocument): Promise<Face> {
  return {
    serif: await doc.embedFont(StandardFonts.TimesRoman),
    serifBold: await doc.embedFont(StandardFonts.TimesRomanBold),
    sans: await doc.embedFont(StandardFonts.Helvetica),
    sansBold: await doc.embedFont(StandardFonts.HelveticaBold),
    sansItalic: await doc.embedFont(StandardFonts.HelveticaOblique),
  };
}

function wrap(text: string, font: Font, size: number, width: number) {
  const lines: string[] = [];
  for (const para of text.split("\n")) {
    if (!para.trim()) {
      lines.push("");
      continue;
    }
    let line = "";
    for (const word of para.split(/\s+/)) {
      const test = line ? `${line} ${word}` : word;
      if (font.widthOfTextAtSize(test, size) > width && line) {
        lines.push(line);
        line = word;
      } else line = test;
    }
    if (line) lines.push(line);
  }
  return lines;
}

class Book {
  doc: PDFDocument;
  f: Face;
  pages: PDFPage[] = [];
  page!: PDFPage;
  y = 0;
  marks: Record<string, number> = {};
  total = 0;

  constructor(doc: PDFDocument, f: Face) {
    this.doc = doc;
    this.f = f;
  }

  /** running header + footer on content pages */
  furniture(p: PDFPage, course: string, title: string) {
    p.drawLine({ start: { x: M, y: PAGE_H - 42 }, end: { x: PAGE_W - M, y: PAGE_H - 42 }, thickness: 0.7, color: RULE });
    p.drawText(pdfSafe(`${course} — ${title}`.slice(0, 78)), { x: M, y: PAGE_H - 36, size: 7.5, font: this.f.sans, color: MUTED });
    p.drawText(pdfSafe(LECTURER), { x: PAGE_W - M - this.f.sans.widthOfTextAtSize(LECTURER, 7.5), y: PAGE_H - 36, size: 7.5, font: this.f.sans, color: MUTED });
    p.drawLine({ start: { x: M, y: 52 }, end: { x: PAGE_W - M, y: 52 }, thickness: 0.7, color: RULE });
    p.drawText(pdfSafe(`Prince Learning Hub · ${CONTACT.email} · ${CONTACT.whatsapp}`), { x: M, y: 38, size: 7, font: this.f.sans, color: MUTED });
    const label = `Page ${this.pages.indexOf(p) + 2} of ${this.total || "—"}`;
    p.drawText(label, { x: PAGE_W - M - this.f.sans.widthOfTextAtSize(label, 7), y: 38, size: 7, font: this.f.sans, color: MUTED });
  }

  newPage(course: string, title: string) {
    this.page = this.doc.addPage([PAGE_W, PAGE_H]);
    this.pages.push(this.page);
    this.furniture(this.page, course, title);
    this.y = PAGE_H - 78;
  }

  ensure(h: number, course: string, title: string) {
    if (this.y - h < 74) this.newPage(course, title);
  }

  mark(key: string) {
    // +1 accounts for the cover page, so numbers match the footer
    this.marks[key] = this.pages.length + 1;
  }
}

/* ------------------------------------------------------------------ */
/* cover page                                                          */
/* ------------------------------------------------------------------ */
async function drawCover(doc: PDFDocument, f: Face, h: HandoutInput) {
  const p = doc.addPage([PAGE_W, PAGE_H]);
  p.drawRectangle({ x: 0, y: 0, width: PAGE_W, height: PAGE_H, color: NAVY });

  // decorative gold ornament band (cover is fully vector so it stays sharp at any size)
  p.drawRectangle({ x: 0, y: 372, width: PAGE_W, height: 3, color: GOLD });
  p.drawRectangle({ x: 0, y: 384, width: PAGE_W, height: 1, color: GOLD, opacity: 0.55 });
  for (let i = 0; i < 7; i++) {
    p.drawRectangle({
      x: PAGE_W / 2 - 78 + i * 26,
      y: 396,
      width: 8,
      height: 8,
      color: GOLD,
      opacity: i === 3 ? 1 : 0.5,
    });
  }

  // gold frame
  p.drawRectangle({ x: 26, y: 26, width: PAGE_W - 52, height: PAGE_H - 52, borderColor: GOLD, borderWidth: 1.2, opacity: 0 });
  p.drawRectangle({ x: 33, y: 33, width: PAGE_W - 66, height: PAGE_H - 66, borderColor: GOLD, borderWidth: 0.5, opacity: 0 });

  // crest ornament: ring + crown + open book drawn in gold
  const cx = PAGE_W / 2;
  const cy = PAGE_H - 148;
  p.drawCircle({ x: cx, y: cy, size: 52, borderColor: GOLD, borderWidth: 1, opacity: 0 });
  p.drawCircle({ x: cx, y: cy, size: 45, borderColor: GOLD, borderWidth: 0.4, opacity: 0 });
  // crown
  p.drawLine({ start: { x: cx - 22, y: cy + 6 }, end: { x: cx - 22, y: cy + 24 }, thickness: 2, color: GOLD });
  p.drawLine({ start: { x: cx + 22, y: cy + 6 }, end: { x: cx + 22, y: cy + 24 }, thickness: 2, color: GOLD });
  p.drawLine({ start: { x: cx - 22, y: cy + 24 }, end: { x: cx - 11, y: cy + 13 }, thickness: 2, color: GOLD });
  p.drawLine({ start: { x: cx - 11, y: cy + 13 }, end: { x: cx, y: cy + 30 }, thickness: 2, color: GOLD });
  p.drawLine({ start: { x: cx, y: cy + 30 }, end: { x: cx + 11, y: cy + 13 }, thickness: 2, color: GOLD });
  p.drawLine({ start: { x: cx + 11, y: cy + 13 }, end: { x: cx + 22, y: cy + 24 }, thickness: 2, color: GOLD });
  p.drawLine({ start: { x: cx - 22, y: cy + 6 }, end: { x: cx + 22, y: cy + 6 }, thickness: 2, color: GOLD });
  // open book
  p.drawLine({ start: { x: cx - 30, y: cy - 6 }, end: { x: cx, y: cy + 2 }, thickness: 1.6, color: GOLD_PALE });
  p.drawLine({ start: { x: cx + 30, y: cy - 6 }, end: { x: cx, y: cy + 2 }, thickness: 1.6, color: GOLD_PALE });
  p.drawLine({ start: { x: cx - 30, y: cy - 6 }, end: { x: cx - 30, y: cy - 14 }, thickness: 1.6, color: GOLD_PALE });
  p.drawLine({ start: { x: cx + 30, y: cy - 6 }, end: { x: cx + 30, y: cy - 14 }, thickness: 1.6, color: GOLD_PALE });
  p.drawLine({ start: { x: cx - 30, y: cy - 14 }, end: { x: cx, y: cy - 6 }, thickness: 1.6, color: GOLD_PALE });
  p.drawLine({ start: { x: cx + 30, y: cy - 14 }, end: { x: cx, y: cy - 6 }, thickness: 1.6, color: GOLD_PALE });

  // institution + session
  p.drawText("PRINCE LEARNING HUB", { x: cx - f.sansBold.widthOfTextAtSize("PRINCE LEARNING HUB", 13) / 2, y: PAGE_H - 236, size: 13, font: f.sansBold, color: GOLD, });
  p.drawText("ONLINE  CAMPUS  ·  HANDOUT  SERIES", {
    x: cx - f.sans.widthOfTextAtSize("ONLINE  CAMPUS  ·  HANDOUT  SERIES", 8) / 2,
    y: PAGE_H - 252,
    size: 8,
    font: f.sans,
    color: GOLD_PALE,
  });
  p.drawLine({ start: { x: cx - 90, y: PAGE_H - 266 }, end: { x: cx + 90, y: PAGE_H - 266 }, thickness: 0.8, color: GOLD });

  // course code
  p.drawText(pdfSafe(h.courseCode), {
    x: cx - f.serifBold.widthOfTextAtSize(h.courseCode, 26) / 2,
    y: PAGE_H - 312,
    size: 26,
    font: f.serifBold,
    color: GOLD,
  });

  // course title (wrapped, centred)
  const titleLines = wrap(pdfSafe(h.title.toUpperCase()), f.serifBold, 27, CW - 110);
  let ty = PAGE_H - 356;
  for (const line of titleLines.slice(0, 4)) {
    p.drawText(line, { x: cx - f.serifBold.widthOfTextAtSize(line, 27) / 2, y: ty, size: 27, font: f.serifBold, color: rgb(1, 1, 1) });
    ty -= 36;
  }

  ty -= 6;
  p.drawText("LECTURE HANDOUT & STUDY GUIDE", {
    x: cx - f.sans.widthOfTextAtSize("LECTURE HANDOUT & STUDY GUIDE", 10) / 2,
    y: ty,
    size: 10,
    font: f.sans,
    color: GOLD_PALE,
  });

  // course details
  const rows: [string, string][] = [
    ["Faculty / Department", h.department],
    ["Level", `${h.level}${h.semester ? ` · ${h.semester}` : ""}`],
    ["Course Lecturer", LECTURER],
    ["Session", SESSION],
  ];
  let dy = 268;
  for (const [k, v] of rows) {
    p.drawText(pdfSafe(k.toUpperCase()), { x: 70, y: dy, size: 7.5, font: f.sansBold, color: GOLD });
    p.drawText(pdfSafe(v), { x: 250, y: dy - 1, size: 10, font: f.serif, color: rgb(1, 1, 1) });
    p.drawLine({ start: { x: 70, y: dy - 8 }, end: { x: PAGE_W - 70, y: dy - 8 }, thickness: 0.3, color: GOLD, opacity: 0.35 });
    dy -= 26;
  }

  // contact bar
  p.drawRectangle({ x: 0, y: 60, width: PAGE_W, height: 46, color: rgb(0.04, 0.1, 0.18) });
  p.drawLine({ start: { x: 0, y: 106 }, end: { x: PAGE_W, y: 106 }, thickness: 1, color: GOLD });
  p.drawText(`Email: ${CONTACT.email}`, { x: 70, y: 80, size: 8.5, font: f.sans, color: GOLD_PALE });
  const tel = `WhatsApp / Call: ${CONTACT.whatsapp}`;
  p.drawText(tel, { x: PAGE_W - 70 - f.sans.widthOfTextAtSize(tel, 8.5), y: 80, size: 8.5, font: f.sans, color: GOLD_PALE });
  const note = "Prepared for Prince Learning Hub students · For academic use only";
  p.drawText(note, { x: cx - f.sans.widthOfTextAtSize(note, 7) / 2, y: 40, size: 7, font: f.sans, color: rgb(0.6, 0.66, 0.74) });
}

/* ------------------------------------------------------------------ */
/* vector diagrams                                                     */
/* ------------------------------------------------------------------ */
function drawDiagram(p: PDFPage, f: Face, kind: Unit["diagram"], x: number, y: number) {
  const box = (bx: number, by: number, w: number, hh: number, label: string, fill = BOX) => {
    p.drawRectangle({ x: bx, y: by, width: w, height: hh, color: fill, borderColor: NAVY_SOFT, borderWidth: 0.8 });
    p.drawText(label, { x: bx + (w - f.sansBold.widthOfTextAtSize(label, 8.5)) / 2, y: by + hh / 2 - 3, size: 8.5, font: f.sansBold, color: NAVY });
  };
  const arrow = (x1: number, y1: number, x2: number, y2: number) => {
    p.drawLine({ start: { x: x1, y: y1 }, end: { x: x2, y: y2 }, thickness: 1, color: NAVY_SOFT });
    p.drawLine({ start: { x: x2, y: y2 }, end: { x: x2 - 5, y: y2 + (y2 > y1 ? 5 : -5) }, thickness: 1, color: NAVY_SOFT });
  };

  if (kind === "blocks") {
    box(x, y + 24, 96, 30, "INPUT");
    box(x + 150, y + 24, 160, 30, "CPU  (ALU + Control)");
    box(x + 360, y + 24, 96, 30, "OUTPUT");
    box(x + 150, y - 30, 160, 30, "MEMORY (RAM / ROM)");
    arrow(x + 96, y + 39, x + 150, y + 39);
    arrow(x + 310, y + 39, x + 360, y + 39);
    arrow(x + 230, y + 24, x + 230, y);
  } else if (kind === "osi") {
    const layers = ["7 · Application", "6 · Presentation", "5 · Session", "4 · Transport", "3 · Network", "2 · Data Link", "1 · Physical"];
    layers.forEach((l, i) => {
      const shade = 0.06 + i * 0.02;
      p.drawRectangle({ x, y: y - i * 22, width: 300, height: 19, color: rgb(0.93 - shade, 0.95 - shade, 0.97 - shade), borderColor: NAVY_SOFT, borderWidth: 0.6 });
      p.drawText(l, { x: x + 12, y: y - i * 22 + 6, size: 8.5, font: f.sans, color: NAVY });
    });
    p.drawText("USER DATA", { x: x + 315, y: y + 6, size: 8, font: f.sansBold, color: MUTED });
    p.drawText("BITS ON THE MEDIUM", { x: x + 315, y: y - 136, size: 8, font: f.sansBold, color: MUTED });
    arrow(x + 308, y + 8, x + 308, y - 130);
  } else if (kind === "flowchart") {
    box(x + 120, y + 60, 130, 26, "START", GOLD_BOX);
    box(x + 120, y + 10, 130, 26, "READ  A, B");
    p.drawRectangle({ x: x + 115, y: y - 46, width: 140, height: 34, borderColor: NAVY_SOFT, borderWidth: 0.8, color: BOX });
    p.drawText("A > B ?", { x: x + 172, y: y - 34, size: 8.5, font: f.sansBold, color: NAVY });
    box(x + 10, y - 42, 86, 26, "PRINT A");
    box(x + 280, y - 42, 86, 26, "PRINT B");
    box(x + 120, y - 104, 130, 26, "STOP", GOLD_BOX);
    arrow(x + 185, y + 60, x + 185, y + 36);
    arrow(x + 185, y + 10, x + 185, y - 12);
    arrow(x + 115, y - 30, x + 96, y - 30);
    arrow(x + 255, y - 30, x + 280, y - 30);
    arrow(x + 53, y - 42, x + 185, y - 104);
    arrow(x + 323, y - 42, x + 185, y - 104);
    p.drawText("YES", { x: x + 100, y: y - 22, size: 7, font: f.sansBold, color: MUTED });
    p.drawText("NO", { x: x + 262, y: y - 22, size: 7, font: f.sansBold, color: MUTED });
  } else if (kind === "sdlc") {
    const steps = ["Requirements", "Design", "Implementation", "Testing", "Maintenance"];
    steps.forEach((s, i) => {
      const bx = x + i * 92;
      const by = y - i * 26;
      box(bx, by, 86, 22, s, i === 4 ? GOLD_BOX : BOX);
      if (i < 4) arrow(bx + 86, by + 11, bx + 92, by + 11);
    });
    p.drawText("Waterfall life-cycle model", { x, y: y - 150, size: 8, font: f.sansItalic, color: MUTED });
  } else if (kind === "tree") {
    box(x + 170, y + 40, 60, 24, "root");
    [[x + 90, y - 4], [x + 170, y - 4], [x + 250, y - 4]].forEach(([bx, by], i) => {
      box(bx, by, 60, 24, ["A", "B", "C"][i]);
      arrow(x + 200, y + 40, bx + 30, by + 24);
    });
    [[x + 50, y - 56], [x + 130, y - 56], [x + 210, y - 56], [x + 290, y - 56]].forEach(([bx, by], i) => {
      box(bx, by, 52, 22, `n${i + 1}`);
    });
    arrow(x + 120, y - 4, x + 76, y - 34);
    arrow(x + 200, y - 4, x + 156, y - 34);
    arrow(x + 280, y - 4, x + 236, y - 34);
  }
}

/* ------------------------------------------------------------------ */
/* main builder                                                        */
/* ------------------------------------------------------------------ */
export async function buildHandout(input: HandoutInput): Promise<Uint8Array> {
  const run = async (marks: Record<string, number>, totalIn: number) => {
    const doc = await PDFDocument.create();
    doc.setTitle(pdfSafe(`${input.courseCode} — ${input.title}`));
    doc.setAuthor(LECTURER);
    doc.setSubject(pdfSafe(`Lecture handout for ${input.title}`));
    doc.setCreator("Prince Learning Hub");
    const f = await faces(doc);
    await drawCover(doc, f, input);

    const b = new Book(doc, f);
    b.total = totalIn;

    const contentTitle = input.courseCode;

    /* ---- foreword ---- */
    b.newPage(contentTitle, input.title);
    b.mark("foreword");
    b.page.drawText("FOREWORD", { x: M, y: b.y, size: 17, font: b.f.serifBold, color: NAVY });
    b.y -= 8;
    b.page.drawLine({ start: { x: M, y: b.y }, end: { x: M + 60, y: b.y }, thickness: 2, color: GOLD });
    b.y -= 26;
    const foreword = [
      `This handout has been prepared for ${input.courseCode}: ${input.title}, offered to ${input.categoryLabel} students${input.semester ? ` in the ${input.semester}` : ""}. It is written to serve both as a lecture companion and as an independent study text.`,
      input.description,
      "Each unit opens with clear learning objectives, develops the theory in simple language, provides worked examples and tables where they help, and closes with a summary and self-check questions. Assignments, a glossary of key terms, practice questions with answers and a reference list are provided at the end.",
      `Students are encouraged to attend lectures, participate in the online discussion rooms on the Prince Learning Hub website, and contact the course lecturer for guidance. The handout will be updated from time to time, so always use the current edition.`,
    ];
    for (const t of foreword) {
      for (const line of wrap(pdfSafe(t), b.f.serif, 11.5, CW)) {
        b.ensure(16, contentTitle, input.title);
        b.page.drawText(line, { x: M, y: b.y, size: 11.5, font: b.f.serif, color: INK });
        b.y -= 16;
      }
      b.y -= 8;
    }
    b.ensure(120, contentTitle, input.title);
    b.page.drawText(pdfSafe(LECTURER), { x: M, y: b.y, size: 13, font: b.f.serifBold, color: NAVY });
    b.y -= 16;
    b.page.drawText("Course Lecturer", { x: M, y: b.y, size: 9, font: b.f.sans, color: MUTED });
    b.y -= 26;
    for (const line of [
      `Email: ${CONTACT.email}`,
      `WhatsApp / Call: ${CONTACT.whatsapp}`,
      `Website: Prince Learning Hub (online lectures, materials, CBT and discussions)`,
    ]) {
      b.page.drawText(pdfSafe(line), { x: M, y: b.y, size: 9.5, font: b.f.sans, color: INK });
      b.y -= 15;
    }

    /* ---- course outline ---- */
    b.newPage(contentTitle, input.title);
    b.mark("outline");
    b.page.drawText("COURSE OUTLINE", { x: M, y: b.y, size: 17, font: b.f.serifBold, color: NAVY });
    b.y -= 8;
    b.page.drawLine({ start: { x: M, y: b.y }, end: { x: M + 60, y: b.y }, thickness: 2, color: GOLD });
    b.y -= 24;
    b.page.drawText("Course description", { x: M, y: b.y, size: 11, font: b.f.sansBold, color: NAVY });
    b.y -= 16;
    for (const line of wrap(pdfSafe(input.description), b.f.serif, 11, CW)) {
      b.page.drawText(line, { x: M, y: b.y, size: 11, font: b.f.serif, color: INK });
      b.y -= 15;
    }
    b.y -= 12;
    b.page.drawText("Learning outcomes", { x: M, y: b.y, size: 11, font: b.f.sansBold, color: NAVY });
    b.y -= 16;
    input.outcomes.slice(0, 10).forEach((o, i) => {
      for (const [k, line] of wrap(pdfSafe(`${i + 1}. ${o}`), b.f.serif, 11, CW - 10).entries()) {
        b.ensure(15, contentTitle, input.title);
        b.page.drawText(line, { x: M + (k ? 14 : 0), y: b.y, size: 11, font: b.f.serif, color: INK });
        b.y -= 15;
      }
    });

    /* ---- scheme of work ---- */
    b.ensure(260, contentTitle, input.title);
    b.y -= 6;
    b.page.drawText("Scheme of work", { x: M, y: b.y, size: 11, font: b.f.sansBold, color: NAVY });
    b.y -= 18;
    const weeks = input.chapters.flatMap((c) => c.units.map((u) => u.title));
    let week = 1;
    const cellW = [70, 330, 80];
    b.page.drawRectangle({ x: M, y: b.y - 12, width: cellW[0] + cellW[1] + cellW[2], height: 18, color: NAVY });
    ["Week", "Topic", "Reading"].forEach((h, i) => {
      const xs = M + cellW.slice(0, i).reduce((a, c) => a + c, 0);
      b.page.drawText(pdfSafe(h), { x: xs + 6, y: b.y - 7, size: 8.5, font: b.f.sansBold, color: rgb(1, 1, 1) });
    });
    b.y -= 30;
    for (const t of weeks.slice(0, 16)) {
      b.ensure(18, contentTitle, input.title);
      const hgt = 16;
      b.page.drawRectangle({ x: M, y: b.y - 4, width: cellW[0] + cellW[1] + cellW[2], height: hgt, borderColor: RULE, borderWidth: 0.4, opacity: 0 });
      b.page.drawText(`Week ${week}`, { x: M + 6, y: b.y, size: 8.5, font: b.f.sans, color: MUTED });
      for (const line of wrap(pdfSafe(t), b.f.sans, 8.5, cellW[1] - 12)) {
        b.page.drawText(line, { x: M + cellW[0] + 6, y: b.y, size: 8.5, font: b.f.sans, color: INK });
      }
      b.page.drawText("Handout", { x: M + cellW[0] + cellW[1] + 6, y: b.y, size: 8.5, font: b.f.sans, color: MUTED });
      b.y -= hgt + 2;
      week++;
    }

    /* ---- table of contents ---- */
    b.newPage(contentTitle, input.title);
    b.mark("toc");
    b.page.drawText("TABLE OF CONTENTS", { x: M, y: b.y, size: 17, font: b.f.serifBold, color: NAVY });
    b.y -= 8;
    b.page.drawLine({ start: { x: M, y: b.y }, end: { x: M + 60, y: b.y }, thickness: 2, color: GOLD });
    b.y -= 24;
    const tocEntries: [string, string][] = [
      ["Foreword", marks.foreword ? String(marks.foreword) : ""],
      ["Course outline and scheme of work", marks.outline ? String(marks.outline) : ""],
    ];
    input.chapters.forEach((c, i) => tocEntries.push([`Chapter ${i + 1}: ${c.title}`, marks[c.id] ? String(marks[c.id]) : ""]));
    tocEntries.push(["Assignments", marks.assignments ? String(marks.assignments) : ""]);
    tocEntries.push(["Practice questions with answers", marks.practice ? String(marks.practice) : ""]);
    tocEntries.push(["Glossary of key terms", marks.glossary ? String(marks.glossary) : ""]);
    tocEntries.push(["References and further reading", marks.refs ? String(marks.refs) : ""]);
    tocEntries.push(["Appendix A: Study and examination guide", marks.appA ? String(marks.appA) : ""]);
    tocEntries.push(["Appendix B: Quick reference tables", marks.appB ? String(marks.appB) : ""]);

    for (const [label, pg] of tocEntries) {
      b.ensure(18, contentTitle, input.title);
      const num = pg ? pg : "—";
      const labelW = b.f.serif.widthOfTextAtSize(pdfSafe(label), 11);
      b.page.drawText(pdfSafe(label), { x: M, y: b.y, size: 11, font: b.f.serif, color: INK });
      const dotsX = M + labelW + 6;
      const numX = PAGE_W - M - b.f.serif.widthOfTextAtSize(num, 11);
      b.page.drawLine({ start: { x: dotsX, y: b.y + 3 }, end: { x: numX - 6, y: b.y + 3 }, thickness: 0.4, color: RULE });
      b.page.drawText(num, { x: numX, y: b.y, size: 11, font: b.f.serif, color: NAVY });
      b.y -= 18;
    }

    // pre-embed chapter photographs (no async work inside the render loop)
    const imageCache = new Map<string, PDFImage | null>();
    const wanted = new Set<string>();
    input.chapters.forEach((c) => c.units.forEach((u) => u.image && wanted.add(u.image)));
    for (const file of wanted) {
      const bytes = imageBytes(file);
      if (!bytes) {
        imageCache.set(file, null);
        continue;
      }
      try {
        imageCache.set(file, await doc.embedJpg(bytes));
      } catch {
        imageCache.set(file, null);
      }
    }

    /* ---- chapters ---- */
    input.chapters.forEach((ch, ci) => {
      b.newPage(contentTitle, input.title);
      b.mark(ch.id);
      b.page.drawText(`CHAPTER ${ci + 1}`, { x: M, y: b.y, size: 10, font: b.f.sansBold, color: GOLD });
      b.y -= 30;
      for (const line of wrap(pdfSafe(ch.title), b.f.serifBold, 24, CW)) {
        b.page.drawText(line, { x: M, y: b.y, size: 24, font: b.f.serifBold, color: NAVY });
        b.y -= 30;
      }
      b.y -= 6;
      for (const line of wrap(pdfSafe(ch.tagline), b.f.serif, 13, CW - 60)) {
        b.page.drawText(line, { x: M, y: b.y, size: 13, font: b.f.serif, color: MUTED });
        b.y -= 18;
      }
      b.page.drawLine({ start: { x: M, y: b.y }, end: { x: M + 80, y: b.y }, thickness: 2, color: GOLD });
      b.y -= 26;

      ch.units.forEach((u, ui) => {
        b.ensure(80, contentTitle, input.title);
        b.page.drawRectangle({ x: M, y: b.y - 5, width: CW, height: 22, color: NAVY });
        b.page.drawText(pdfSafe(`${ci + 1}.${ui + 1}  ${u.title}`.toUpperCase()), {
          x: M + 10,
          y: b.y + 1,
          size: 9.5,
          font: b.f.sansBold,
          color: GOLD_PALE,
        });
        b.y -= 30;

        b.page.drawText("Learning objectives — at the end of this unit you should be able to:", {
          x: M,
          y: b.y,
          size: 9.5,
          font: b.f.sansBold,
          color: NAVY,
        });
        b.y -= 15;
        for (const o of u.objectives) {
          for (const [k, line] of wrap(pdfSafe(`•  ${o}`), b.f.serif, 10.5, CW - 16).entries()) {
            b.ensure(14, contentTitle, input.title);
            b.page.drawText(line, { x: M + (k ? 14 : 0), y: b.y, size: 10.5, font: b.f.serif, color: INK });
            b.y -= 14;
          }
        }
        b.y -= 6;

        for (const para of u.paragraphs) {
          for (const line of wrap(pdfSafe(para), b.f.serif, 11.5, CW)) {
            b.ensure(16, contentTitle, input.title);
            b.page.drawText(line, { x: M, y: b.y, size: 11.5, font: b.f.serif, color: INK });
            b.y -= 16;
          }
          b.y -= 7;
        }

        if (u.keyPoints?.length) {
          b.ensure(30 + u.keyPoints.length * 15, contentTitle, input.title);
          const lines = u.keyPoints.flatMap((k) => wrap(pdfSafe(`✓  ${k}`), b.f.sans, 9.5, CW - 44));
          const h = lines.length * 13 + 26;
          b.page.drawRectangle({ x: M, y: b.y - h + 16, width: CW, height: h, color: BOX });
          b.page.drawRectangle({ x: M, y: b.y - h + 16, width: 3, height: h, color: NAVY });
          b.page.drawText("KEY POINTS", { x: M + 16, y: b.y, size: 8.5, font: b.f.sansBold, color: NAVY });
          b.y -= 15;
          for (const line of lines) {
            b.page.drawText(line, { x: M + 16, y: b.y, size: 9.5, font: b.f.sans, color: INK });
            b.y -= 13;
          }
          b.y -= 12;
        }

        if (u.table) {
          b.ensure(40 + (u.table.rows.length + 1) * 17, contentTitle, input.title);
          b.page.drawText(pdfSafe(u.table.caption), { x: M, y: b.y, size: 9, font: b.f.sansItalic, color: MUTED });
          b.y -= 14;
          const cols = u.table.headers.length;
          const colW = CW / cols;
          b.page.drawRectangle({ x: M, y: b.y - 11, width: CW, height: 18, color: NAVY });
          u.table.headers.forEach((h, i) => b.page.drawText(pdfSafe(h), { x: M + i * colW + 6, y: b.y - 6, size: 8.5, font: b.f.sansBold, color: rgb(1, 1, 1) }));
          b.y -= 29;
          u.table.rows.forEach((row, ri) => {
            const rowLines = row.map((c) => wrap(pdfSafe(c), b.f.sans, 8.5, colW - 12));
            const rowH = Math.max(...rowLines.map((l) => l.length)) * 11 + 6;
            b.ensure(rowH + 4, contentTitle, input.title);
            b.page.drawRectangle({ x: M, y: b.y - rowH + 8, width: CW, height: rowH, color: ri % 2 ? CREAM : rgb(1, 1, 1), borderColor: RULE, borderWidth: 0.3, opacity: 0 });
            rowLines.forEach((lines, ci2) =>
              lines.forEach((line, li) =>
                b.page.drawText(line, { x: M + ci2 * colW + 6, y: b.y - li * 11, size: 8.5, font: b.f.sans, color: INK }),
              ),
            );
            b.y -= rowH;
          });
          b.y -= 12;
        }

        if (u.diagram) {
          b.ensure(190, contentTitle, input.title);
          drawDiagram(b.page, b.f, u.diagram, M + 30, b.y - 130);
          b.y -= 172;
          b.page.drawText("Figure: worked diagram", { x: M + 30, y: b.y, size: 8, font: b.f.sansItalic, color: MUTED });
          b.y -= 18;
        }

        const cached = u.image ? imageCache.get(u.image) : null;
        if (cached) {
          const w = 300;
          const hgt = (cached.height / cached.width) * w;
          b.ensure(hgt + 40, contentTitle, input.title);
          b.page.drawImage(cached, { x: M, y: b.y - hgt, width: w, height: hgt });
          b.page.drawText(pdfSafe(u.imageCaption ?? "Figure"), { x: M, y: b.y - hgt - 12, size: 8, font: b.f.sansItalic, color: MUTED });
          b.y -= hgt + 26;
        }

        if (u.example) {
          const lines = u.example.lines.flatMap((l) => wrap(pdfSafe(l), b.f.sans, 9.5, CW - 60));
          const h = lines.length * 13 + 30;
          b.ensure(h + 10, contentTitle, input.title);
          b.page.drawRectangle({ x: M, y: b.y - h + 16, width: CW, height: h, color: GOLD_BOX });
          b.page.drawRectangle({ x: M, y: b.y - h + 16, width: 3, height: h, color: GOLD });
          b.page.drawText(pdfSafe(u.example.heading), { x: M + 16, y: b.y, size: 9, font: b.f.sansBold, color: NAVY });
          b.y -= 15;
          for (const line of lines) {
            b.page.drawText(line, { x: M + 16, y: b.y, size: 9.5, font: b.f.sans, color: INK });
            b.y -= 13;
          }
          b.y -= 12;
        }

        // summary + self check
        b.ensure(90, contentTitle, input.title);
        b.page.drawText("Unit summary", { x: M, y: b.y, size: 9.5, font: b.f.sansBold, color: GOLD });
        b.y -= 14;
        for (const line of wrap(pdfSafe(u.summary), b.f.serif, 10.5, CW)) {
          b.page.drawText(line, { x: M, y: b.y, size: 10.5, font: b.f.serif, color: INK });
          b.y -= 14;
        }
        b.y -= 8;
        b.page.drawText("Self-check questions", { x: M, y: b.y, size: 9.5, font: b.f.sansBold, color: NAVY });
        b.y -= 14;
        u.questions.forEach((q, qi) => {
          for (const [k, line] of wrap(pdfSafe(`${qi + 1}. ${q}`), b.f.serif, 10.5, CW - 10).entries()) {
            b.ensure(14, contentTitle, input.title);
            b.page.drawText(line, { x: M + (k ? 12 : 0), y: b.y, size: 10.5, font: b.f.serif, color: INK });
            b.y -= 14;
          }
        });
        b.y -= 16;
      });

      // chapter revision checklist + key terms
      b.ensure(120, contentTitle, input.title);
      b.y -= 6;
      b.page.drawRectangle({ x: M, y: b.y - 5, width: CW, height: 22, color: NAVY });
      b.page.drawText(pdfSafe(`CHAPTER ${ci + 1} — REVISION CHECKLIST`.toUpperCase()), {
        x: M + 10,
        y: b.y + 1,
        size: 9.5,
        font: b.f.sansBold,
        color: GOLD_PALE,
      });
      b.y -= 30;
      b.page.drawText("Tick each item when you can explain it without looking at the text:", {
        x: M,
        y: b.y,
        size: 9.5,
        font: b.f.sans,
        color: MUTED,
      });
      b.y -= 17;
      ch.units.forEach((u) => {
        u.objectives.forEach((o) => {
          for (const [k, line] of wrap(pdfSafe(o), b.f.serif, 10, CW - 34).entries()) {
            b.ensure(15, contentTitle, input.title);
            b.page.drawRectangle({ x: M + (k ? 14 : 0), y: b.y - 1, width: 8, height: 8, borderColor: NAVY_SOFT, borderWidth: 0.7, opacity: 0 });
            b.page.drawText(line, { x: M + 20 + (k ? 14 : 0), y: b.y, size: 10, font: b.f.serif, color: INK });
            b.y -= 15;
          }
        });
      });
      b.y -= 8;
      b.ensure(60, contentTitle, input.title);
      b.page.drawText("Key terms in this chapter", { x: M, y: b.y, size: 11, font: b.f.sansBold, color: NAVY });
      b.y -= 18;
      const termColW = CW / 2;
      const terms = ch.glossary;
      for (let i = 0; i < terms.length; i += 2) {
        b.ensure(15, contentTitle, input.title);
        [terms[i], terms[i + 1]].forEach((g, gi) => {
          if (!g) return;
          const x0 = M + gi * termColW;
          b.page.drawText(pdfSafe(g.term), { x: x0, y: b.y, size: 9.5, font: b.f.sansBold, color: NAVY });
          const def = wrap(pdfSafe(g.definition), b.f.serif, 9, termColW - 90);
          if (def[0]) b.page.drawText(def[0], { x: x0 + 82, y: b.y, size: 9, font: b.f.serif, color: INK });
        });
        b.y -= 15;
      }
      b.y -= 12;
    });

    /* ---- assignments ---- */
    b.newPage(contentTitle, input.title);
    b.mark("assignments");
    b.page.drawText("ASSIGNMENTS", { x: M, y: b.y, size: 17, font: b.f.serifBold, color: NAVY });
    b.y -= 8;
    b.page.drawLine({ start: { x: M, y: b.y }, end: { x: M + 60, y: b.y }, thickness: 2, color: GOLD });
    b.y -= 22;
    const note = "Answer ALL questions. Submit your work through the Prince Learning Hub discussion room or by email to the course lecturer on or before the stated deadline.";
    for (const line of wrap(pdfSafe(note), b.f.serif, 10.5, CW)) {
      b.page.drawText(line, { x: M, y: b.y, size: 10.5, font: b.f.serif, color: INK });
      b.y -= 14;
    }
    b.y -= 10;
    input.chapters.forEach((ch, ci) => {
      ch.assignments.forEach((a) => {
        b.ensure(60, contentTitle, input.title);
        b.page.drawText(pdfSafe(`Assignment ${ci + 1} — ${a.title}`), { x: M, y: b.y, size: 11, font: b.f.sansBold, color: NAVY });
        b.y -= 17;
        a.questions.forEach((q, qi) => {
          for (const [k, line] of wrap(pdfSafe(`${qi + 1}. ${q}`), b.f.serif, 10.5, CW - 12).entries()) {
            b.ensure(14, contentTitle, input.title);
            b.page.drawText(line, { x: M + (k ? 12 : 0), y: b.y, size: 10.5, font: b.f.serif, color: INK });
            b.y -= 14;
          }
        });
        b.y -= 12;
      });
    });

    /* ---- practice questions ---- */
    b.newPage(contentTitle, input.title);
    b.mark("practice");
    b.page.drawText("PRACTICE QUESTIONS WITH ANSWERS", { x: M, y: b.y, size: 15, font: b.f.serifBold, color: NAVY });
    b.y -= 8;
    b.page.drawLine({ start: { x: M, y: b.y }, end: { x: M + 60, y: b.y }, thickness: 2, color: GOLD });
    b.y -= 20;
    for (const line of wrap(
      pdfSafe("These questions are in the same format as the Prince Learning Hub computer based tests (CBT). Attempt each question before reading the answer."),
      b.f.serif,
      10.5,
      CW,
    )) {
      b.page.drawText(line, { x: M, y: b.y, size: 10.5, font: b.f.serif, color: MUTED });
      b.y -= 14;
    }
    b.y -= 8;
    input.practice.slice(0, 45).forEach((q, qi) => {
      b.ensure(64, contentTitle, input.title);
      for (const [k, line] of wrap(pdfSafe(`${qi + 1}. ${q.question}`), b.f.serifBold, 11, CW - 12).entries()) {
        b.ensure(15, contentTitle, input.title);
        b.page.drawText(line, { x: M + (k ? 12 : 0), y: b.y, size: 11, font: b.f.serifBold, color: NAVY });
        b.y -= 15;
      }
      q.options.forEach((opt, oi) => {
        for (const [k, line] of wrap(pdfSafe(`(${String.fromCharCode(65 + oi)})  ${opt}`), b.f.serif, 10.5, CW - 30).entries()) {
          b.ensure(14, contentTitle, input.title);
          b.page.drawText(line, { x: M + 18 + (k ? 14 : 0), y: b.y, size: 10.5, font: b.f.serif, color: INK });
          b.y -= 14;
        }
      });
      const ans = `Answer: (${String.fromCharCode(65 + q.answerIndex)}) ${q.options[q.answerIndex]}. ${q.explanation}`.trim();
      for (const line of wrap(pdfSafe(ans), b.f.sansItalic, 9.5, CW - 30)) {
        b.ensure(13, contentTitle, input.title);
        b.page.drawText(line, { x: M + 18, y: b.y, size: 9.5, font: b.f.sansItalic, color: rgb(0.25, 0.35, 0.3) });
        b.y -= 13;
      }
      b.y -= 11;
    });

    /* ---- theory questions ---- */
    b.ensure(70, contentTitle, input.title);
    b.y -= 6;
    b.page.drawText("SECTION B — THEORY AND SHORT ANSWER QUESTIONS", { x: M, y: b.y, size: 12, font: b.f.serifBold, color: NAVY });
    b.y -= 8;
    b.page.drawLine({ start: { x: M, y: b.y }, end: { x: M + 60, y: b.y }, thickness: 2, color: GOLD });
    b.y -= 20;
    for (const line of wrap(
      pdfSafe("Answer any four questions from this section. Each question carries equal marks. Show all working where necessary."),
      b.f.serif,
      10.5,
      CW,
    )) {
      b.page.drawText(line, { x: M, y: b.y, size: 10.5, font: b.f.serif, color: MUTED });
      b.y -= 14;
    }
    b.y -= 8;
    input.chapters.forEach((ch, ci) => {
      b.ensure(30, contentTitle, input.title);
      b.page.drawText(pdfSafe(`Chapter ${ci + 1}: ${ch.title}`), { x: M, y: b.y, size: 10, font: b.f.sansBold, color: GOLD });
      b.y -= 15;
      ch.units.forEach((u) => {
        u.questions.slice(0, 2).forEach((q) => {
          for (const [k, line] of wrap(pdfSafe(`• ${q}`), b.f.serif, 10.5, CW - 14).entries()) {
            b.ensure(14, contentTitle, input.title);
            b.page.drawText(line, { x: M + (k ? 14 : 0), y: b.y, size: 10.5, font: b.f.serif, color: INK });
            b.y -= 14;
          }
          b.y -= 3;
        });
      });
      b.y -= 8;
    });

    /* ---- glossary ---- */
    b.newPage(contentTitle, input.title);
    b.mark("glossary");
    b.page.drawText("GLOSSARY OF KEY TERMS", { x: M, y: b.y, size: 17, font: b.f.serifBold, color: NAVY });
    b.y -= 8;
    b.page.drawLine({ start: { x: M, y: b.y }, end: { x: M + 60, y: b.y }, thickness: 2, color: GOLD });
    b.y -= 24;
    const terms = new Map<string, string>();
    input.chapters.forEach((c) => c.glossary.forEach((g) => terms.set(g.term, g.definition)));
    [...terms.entries()]
      .sort((a, b2) => a[0].localeCompare(b2[0]))
      .forEach(([term, def]) => {
        b.ensure(30, contentTitle, input.title);
        const defLines = wrap(pdfSafe(def), b.f.serif, 10, CW - 150);
        b.page.drawText(pdfSafe(term), { x: M, y: b.y, size: 10.5, font: b.f.sansBold, color: NAVY });
        defLines.forEach((line, i) => {
          if (i) b.ensure(13, contentTitle, input.title);
          b.page.drawText(line, { x: M + 150, y: b.y, size: 10, font: b.f.serif, color: INK });
          b.y -= 13;
        });
        b.y -= 5;
      });

    /* ---- references ---- */
    b.newPage(contentTitle, input.title);
    b.mark("refs");
    b.page.drawText("REFERENCES AND FURTHER READING", { x: M, y: b.y, size: 15, font: b.f.serifBold, color: NAVY });
    b.y -= 8;
    b.page.drawLine({ start: { x: M, y: b.y }, end: { x: M + 60, y: b.y }, thickness: 2, color: GOLD });
    b.y -= 24;
    const refs = new Set<string>();
    input.chapters.forEach((c) => c.references.forEach((r) => refs.add(r)));
    [...refs].forEach((r) => {
      for (const [k, line] of wrap(pdfSafe(r), b.f.serif, 10.5, CW - 18).entries()) {
        b.ensure(14, contentTitle, input.title);
        b.page.drawText(line, { x: M + (k ? 18 : 0), y: b.y, size: 10.5, font: b.f.serif, color: INK });
        b.y -= 14;
      }
      b.y -= 6;
    });

    /* ---- appendix A ---- */
    b.newPage(contentTitle, input.title);
    b.mark("appA");
    b.page.drawText("APPENDIX A: STUDY AND EXAMINATION GUIDE", { x: M, y: b.y, size: 15, font: b.f.serifBold, color: NAVY });
    b.y -= 8;
    b.page.drawLine({ start: { x: M, y: b.y }, end: { x: M + 60, y: b.y }, thickness: 2, color: GOLD });
    b.y -= 22;
    const appendix = [
      ["How to study with this handout", "Read the objectives first. Study one unit at a time, write your own summary in your own words, and answer the self-check questions before moving on. Revisit difficult sections and bring them to the lecture or the online discussion room."],
      ["Time management", "Prepare a personal study timetable, use focused study blocks of about 25 minutes with short breaks, and start revision at least two weeks before the examination. Cover a little every day rather than everything the night before."],
      ["Reading techniques", "Skim the headings and summary to see the structure, scan for specific facts when answering questions, and read critically when evaluating an argument or a claim."],
      ["Note-taking", "Use the Cornell method: write notes in the main column, cue words in the margin, and a short summary at the bottom of the page. Review your notes within 24 hours."],
      ["During the CBT test", "Read every question completely before answering. Answer the easy questions first, then return to the difficult ones. Watch the timer and leave at least two minutes to review unanswered questions. Remember that answers are submitted automatically when time is up."],
      ["Avoiding plagiarism", "Acknowledge every source you use, put quotations in quotation marks, and paraphrase properly with citations. Plagiarism is a serious academic offence."],
    ];
    for (const [h, t] of appendix) {
      b.ensure(40, contentTitle, input.title);
      b.page.drawText(pdfSafe(h), { x: M, y: b.y, size: 11, font: b.f.sansBold, color: NAVY });
      b.y -= 15;
      for (const line of wrap(pdfSafe(t), b.f.serif, 10.5, CW)) {
        b.ensure(14, contentTitle, input.title);
        b.page.drawText(line, { x: M, y: b.y, size: 10.5, font: b.f.serif, color: INK });
        b.y -= 14;
      }
      b.y -= 10;
    }

    /* ---- appendix B ---- */
    b.newPage(contentTitle, input.title);
    b.mark("appB");
    b.page.drawText("APPENDIX B: QUICK REFERENCE TABLES", { x: M, y: b.y, size: 15, font: b.f.serifBold, color: NAVY });
    b.y -= 8;
    b.page.drawLine({ start: { x: M, y: b.y }, end: { x: M + 60, y: b.y }, thickness: 2, color: GOLD });
    b.y -= 22;
    const refTables: { caption: string; headers: string[]; rows: string[][] }[] = [
      {
        caption: "Table B1 — Units of data storage",
        headers: ["Unit", "Symbol", "Value"],
        rows: [
          ["Bit", "b", "A single binary digit (0 or 1)"],
          ["Nibble", "—", "4 bits"],
          ["Byte", "B", "8 bits"],
          ["Kilobyte", "KB", "1,024 bytes"],
          ["Megabyte", "MB", "1,024 KB"],
          ["Gigabyte", "GB", "1,024 MB"],
          ["Terabyte", "TB", "1,024 GB"],
        ],
      },
      {
        caption: "Table B2 — Number system conversions",
        headers: ["Decimal", "Binary", "Hexadecimal"],
        rows: [
          ["0", "0000", "0"],
          ["5", "0101", "5"],
          ["10", "1010", "A"],
          ["15", "1111", "F"],
          ["16", "10000", "10"],
          ["255", "11111111", "FF"],
        ],
      },
      {
        caption: "Table B3 — Common SI prefixes and data rates",
        headers: ["Prefix", "Symbol", "Value"],
        rows: [
          ["Kilo", "K", "10³"],
          ["Mega", "M", "10⁶"],
          ["Giga", "G", "10⁹"],
          ["Tera", "T", "10¹²"],
          ["Peta", "P", "10¹⁵"],
        ],
      },
    ];
    for (const t of refTables) {
      b.ensure(40 + (t.rows.length + 1) * 17, contentTitle, input.title);
      b.page.drawText(pdfSafe(t.caption), { x: M, y: b.y, size: 9, font: b.f.sansItalic, color: MUTED });
      b.y -= 14;
      const colW = CW / t.headers.length;
      b.page.drawRectangle({ x: M, y: b.y - 11, width: CW, height: 18, color: NAVY });
      t.headers.forEach((h, i) => b.page.drawText(pdfSafe(h), { x: M + i * colW + 6, y: b.y - 6, size: 8.5, font: b.f.sansBold, color: rgb(1, 1, 1) }));
      b.y -= 29;
      t.rows.forEach((row, ri) => {
        b.page.drawRectangle({ x: M, y: b.y - 8, width: CW, height: 17, color: ri % 2 ? CREAM : rgb(1, 1, 1), borderColor: RULE, borderWidth: 0.3, opacity: 0 });
        row.forEach((c, ci2) => b.page.drawText(pdfSafe(c), { x: M + ci2 * colW + 6, y: b.y - 3, size: 8.5, font: b.f.sans, color: INK }));
        b.y -= 17;
      });
      b.y -= 14;
    }
    /* ---- appendix C: planner and notes ---- */
    b.newPage(contentTitle, input.title);
    b.mark("appC");
    b.page.drawText("APPENDIX C: REVISION TIMETABLE AND NOTES", { x: M, y: b.y, size: 15, font: b.f.serifBold, color: NAVY });
    b.y -= 8;
    b.page.drawLine({ start: { x: M, y: b.y }, end: { x: M + 60, y: b.y }, thickness: 2, color: GOLD });
    b.y -= 22;
    for (const line of wrap(
      pdfSafe("Complete this timetable at the start of your revision and use the space below for your own notes."),
      b.f.serif,
      10.5,
      CW,
    )) {
      b.page.drawText(line, { x: M, y: b.y, size: 10.5, font: b.f.serif, color: INK });
      b.y -= 14;
    }
    b.y -= 12;
    const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
    const slots = ["Morning", "Afternoon", "Evening"];
    const col0 = 70;
    const colW3 = (CW - col0) / 3;
    b.page.drawRectangle({ x: M, y: b.y - 11, width: CW, height: 18, color: NAVY });
    b.page.drawText("Week", { x: M + 6, y: b.y - 6, size: 8.5, font: b.f.sansBold, color: rgb(1, 1, 1) });
    slots.forEach((sl, i) => b.page.drawText(sl, { x: M + col0 + i * colW3 + 6, y: b.y - 6, size: 8.5, font: b.f.sansBold, color: rgb(1, 1, 1) }));
    b.y -= 29;
    days.forEach((d, ri) => {
      b.page.drawRectangle({ x: M, y: b.y - 8, width: CW, height: 22, color: ri % 2 ? CREAM : rgb(1, 1, 1), borderColor: RULE, borderWidth: 0.4, opacity: 0 });
      b.page.drawText(d, { x: M + 6, y: b.y + 2, size: 8.5, font: b.f.sansBold, color: NAVY });
      for (let c = 0; c < 3; c++) {
        b.page.drawRectangle({ x: M + col0 + c * colW3, y: b.y - 8, width: colW3, height: 22, borderColor: RULE, borderWidth: 0.4, opacity: 0 });
      }
      b.y -= 22;
    });
    b.y -= 18;
    b.page.drawText("Notes", { x: M, y: b.y, size: 11, font: b.f.sansBold, color: NAVY });
    b.y -= 20;
    while (b.y > 96) {
      b.page.drawLine({ start: { x: M, y: b.y }, end: { x: PAGE_W - M, y: b.y }, thickness: 0.4, color: RULE });
      b.y -= 22;
    }

    b.ensure(80, contentTitle, input.title);
    b.page.drawText("END OF HANDOUT", { x: M, y: b.y - 10, size: 11, font: b.f.sansBold, color: GOLD });
    b.y -= 30;
    for (const line of wrap(
      pdfSafe(`For questions, video lectures and CBT practice, log in to Prince Learning Hub. Contact ${LECTURER} on ${CONTACT.whatsapp} or ${CONTACT.email}.`),
      b.f.serif,
      10.5,
      CW,
    )) {
      b.page.drawText(line, { x: M, y: b.y, size: 10.5, font: b.f.serif, color: INK });
      b.y -= 14;
    }

    return { doc, marks: b.marks, pages: b.pages.length };
  };

  // two passes: pass 1 discovers where each section starts, pass 2 prints real page numbers
  const first = await run({}, 0);
  const second = await run(first.marks, first.doc.getPageCount());
  return second.doc.save();
}
