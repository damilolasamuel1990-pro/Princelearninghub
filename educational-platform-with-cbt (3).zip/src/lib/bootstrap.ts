import { db, pool } from "@/db";
import { lectures, materials, messages, news, questions, tests } from "@/db/schema";
import { seedLectures, seedMessages, seedNews } from "./seed-data";
import { ALL_TESTS } from "./tests";
import { MATERIALS } from "./materials-data";
import { buildMaterialPdf } from "./pdf";
import { audienceLabel } from "./academics";
import { buildHandouts } from "./handout/courses";
import { buildHandout } from "./handout/pdf-handout";

const SEED_VERSION = "9";

const CREATE_SQL = `
CREATE TABLE IF NOT EXISTS meta (
  key text PRIMARY KEY,
  value text NOT NULL
);
CREATE TABLE IF NOT EXISTS news (
  id serial PRIMARY KEY,
  title text NOT NULL,
  body text NOT NULL,
  category text NOT NULL DEFAULT 'General',
  pinned boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS lectures (
  id serial PRIMARY KEY,
  title text NOT NULL,
  course_code text NOT NULL,
  lecturer text NOT NULL,
  description text NOT NULL DEFAULT '',
  video_id text NOT NULL,
  scheduled_at timestamptz NOT NULL,
  duration_min integer NOT NULL DEFAULT 60,
  status text NOT NULL DEFAULT 'upcoming',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS messages (
  id serial PRIMARY KEY,
  room text NOT NULL,
  sender_name text NOT NULL,
  reg_no text NOT NULL,
  body text NOT NULL,
  is_question boolean NOT NULL DEFAULT false,
  reply_to integer,
  created_at timestamptz NOT NULL DEFAULT now()
);
`;

const ACADEMIC_SQL = `
CREATE TABLE IF NOT EXISTS materials (
  id serial PRIMARY KEY,
  title text NOT NULL,
  course_code text NOT NULL,
  course_title text NOT NULL,
  category text NOT NULL DEFAULT 'ALL',
  department text NOT NULL DEFAULT 'ALL',
  level text NOT NULL DEFAULT 'All Levels',
  description text NOT NULL DEFAULT '',
  file_name text NOT NULL,
  mime_type text NOT NULL DEFAULT 'application/pdf',
  data text NOT NULL,
  size_bytes integer NOT NULL DEFAULT 0,
  downloads integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS tests (
  id serial PRIMARY KEY,
  code text NOT NULL,
  title text NOT NULL,
  category text NOT NULL,
  department text NOT NULL,
  level text NOT NULL,
  levels text NOT NULL DEFAULT '',
  semester text NOT NULL DEFAULT '',
  duration_min integer NOT NULL DEFAULT 10,
  description text NOT NULL DEFAULT '',
  sort integer NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS questions (
  id serial PRIMARY KEY,
  test_id integer NOT NULL,
  question text NOT NULL,
  options jsonb NOT NULL,
  answer_index integer NOT NULL,
  explanation text NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS results (
  id serial PRIMARY KEY,
  student_name text NOT NULL,
  reg_no text NOT NULL,
  test_id integer NOT NULL,
  course_code text NOT NULL,
  test_title text NOT NULL,
  category text NOT NULL,
  department text NOT NULL,
  level text NOT NULL,
  score integer NOT NULL,
  total integer NOT NULL,
  percentage integer NOT NULL,
  time_taken integer NOT NULL,
  duration_sec integer NOT NULL,
  answers jsonb NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
`;

const globalForBoot = globalThis as typeof globalThis & { __plhBoot?: Promise<void> };

/** Deterministically shuffle options so the correct answer letter is evenly spread. */
function shuffleOptions(question: string, options: string[], answerIndex: number) {
  let h = 2166136261;
  for (const ch of question) h = Math.imul(h ^ ch.charCodeAt(0), 16777619) >>> 0;
  const rand = () => {
    h = Math.imul(h ^ (h >>> 15), 2246822507) >>> 0;
    h = Math.imul(h ^ (h >>> 13), 3266489909) >>> 0;
    return ((h ^= h >>> 16) >>> 0) / 4294967296;
  };
  const order = options.map((_, i) => i);
  for (let i = order.length - 1; i > 0; i--) {
    const j = Math.floor(rand() * (i + 1));
    [order[i], order[j]] = [order[j], order[i]];
  }
  return { options: order.map((i) => options[i]), answerIndex: order.indexOf(answerIndex) };
}

const count = async (table: string) => (await pool.query(`SELECT count(*)::int AS c FROM ${table}`)).rows[0].c as number;

function pdfFileName(code: string, title: string) {
  const slug = title
    .replace(/—.*$/, "")
    .replace(/[^A-Za-z0-9]+/g, "_")
    .replace(/^_|_$/g, "");
  return `${code.replace(/[^A-Za-z0-9-]+/g, "")}_${slug}.pdf`;
}

async function seedAcademic() {
  // Tests + questions
  let sort = 0;
  for (const t of ALL_TESTS) {
    const [row] = await db
      .insert(tests)
      .values({
        code: t.code,
        title: t.title,
        category: t.category,
        department: t.department,
        level: t.level,
        levels: `|${(t.levels ?? [t.level]).join("|")}|`,
        semester: t.semester ?? "",
        durationMin: t.durationMin,
        description: t.description,
        sort: sort++,
      })
      .returning({ id: tests.id });
    await db.insert(questions).values(
      t.questions.map(([question, options, answerIndex, explanation]) => ({
        testId: row.id,
        question,
        ...shuffleOptions(question, options, answerIndex),
        explanation,
      })),
    );
  }

  // Lecture handouts (45+ page PDFs) for every university and polytechnic course
  for (const h of buildHandouts()) {
    const bytes = await buildHandout(h);
    const buf = Buffer.from(bytes);
    await db.insert(materials).values({
      title: `${h.courseCode} — ${h.title}`,
      courseCode: h.courseCode,
      courseTitle: h.title,
      category: h.categoryLabel.toLowerCase(),
      department: h.department,
      level: `${h.level}${h.semester ? ` · ${h.semester}` : ""}`,
      description: `Lecture handout and study guide with units, worked examples, diagrams, assignments, glossary and practice questions. Prepared by ${"Mr. Damilola"}.`,
      fileName: `${h.courseCode.replace(/[^A-Za-z0-9-]+/g, "")}_Handout.pdf`,
      mimeType: "application/pdf",
      data: buf.toString("base64"),
      sizeBytes: buf.length,
    });
  }

  // Study notes for primary and secondary students
  for (const m of MATERIALS.filter((x) => x.category === "primary" || x.category === "secondary")) {
    const bytes = await buildMaterialPdf({
      title: m.title,
      courseCode: m.courseCode,
      courseTitle: m.courseTitle,
      audience: audienceLabel(m.category, m.department, m.level),
      sections: m.sections,
    });
    const buf = Buffer.from(bytes);
    await db.insert(materials).values({
      title: m.title,
      courseCode: m.courseCode,
      courseTitle: m.courseTitle,
      category: m.category,
      department: m.department,
      level: m.level,
      description: m.description,
      fileName: pdfFileName(m.courseCode, m.title),
      mimeType: "application/pdf",
      data: buf.toString("base64"),
      sizeBytes: buf.length,
    });
  }
}

async function run() {
  await pool.query(CREATE_SQL);

  const version = (await pool.query("SELECT value FROM meta WHERE key = 'seed_version'")).rows[0]?.value as string | undefined;

  if (version !== SEED_VERSION) {
    // (Re)build academic tables with the current structure and seed data.
    await pool.query("DROP TABLE IF EXISTS questions, results, materials, tests CASCADE");
    await pool.query(ACADEMIC_SQL);
    await seedAcademic();
    await pool.query("UPDATE news SET category = 'CBT Tests' WHERE category = 'Exams'");
    await pool.query(
      "UPDATE news SET title = 'CBT Practice Tests Now Open', body = 'CBT practice tests are now live for every class. Each test has 10 questions and its own timer. Results are released immediately after submission with full corrections.' WHERE title = 'GST 101 CBT Practice Test Now Open'",
    );
    if (version) {
      await pool.query("UPDATE news SET pinned = false WHERE category = 'CBT Tests'");
      await db.insert(news).values({
        title: "New Lecture Handouts Available for Download",
        body: "Every university and polytechnic course now has a complete lecture handout of 45 to 52 pages, prepared by Mr. Damilola. Each handout has a designed cover page, course outline, units with objectives and summaries, worked examples, diagrams, tables, assignments, a glossary, practice questions with answers and revision checklists. Open the Materials page, choose your school, department and level, and download the PDF for reading.",
        category: "Materials",
        pinned: true,
      });
      await db.insert(news).values({
        title: "CBT Now Live for Computer Science & Software Engineering (100–400 Level)",
        body: "New 40-question CBT tests are available. Computer Science 300 Level: CSC 301, CSC 303, CSC 305, CSC 307, CSC 309 and MAT 303. Computer Science 400 Level: CSC 401, 403, 405, 407, 409, 419 and 427. Software Engineering 100 Level: COS 101, WUI-LIB 001, WUI-CSC 101, WUI-CSC 103. 200 Level: COS 201, SEN 201, WUI-SEN 263, WUI-CSC 201. 300 Level: SEN 301, 303, 305, 309, 311, 312, CSC 304, CSC 330, CSC 312 and STA 322. 400 Level: SEN 401, 403, 405, 407, 409, 411, 413, 415 and 417. Courses with the same title share the same question bank because the students attend the same classes.",
        category: "CBT Tests",
        pinned: true,
      });
    }
    await pool.query(
      "INSERT INTO meta (key, value) VALUES ('seed_version', $1) ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value",
      [SEED_VERSION],
    );
  } else {
    await pool.query(ACADEMIC_SQL);
  }

  if ((await count("news")) === 0) await db.insert(news).values(seedNews);
  if ((await count("lectures")) === 0) await db.insert(lectures).values(seedLectures());
  if ((await count("messages")) === 0) await db.insert(messages).values(seedMessages);
}

export function ensureDb(): Promise<void> {
  if (!globalForBoot.__plhBoot) {
    globalForBoot.__plhBoot = (async () => {
      const client = await pool.connect();
      try {
        // Serialise bootstrap across processes.
        await client.query("SELECT pg_advisory_lock(424242)");
        await run();
      } finally {
        await client.query("SELECT pg_advisory_unlock(424242)").catch(() => {});
        client.release();
      }
    })().catch((err) => {
      globalForBoot.__plhBoot = undefined;
      throw err;
    });
  }
  return globalForBoot.__plhBoot;
}
