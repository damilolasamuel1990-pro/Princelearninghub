export const seedNews = [
  {
    title: "Welcome to the 2026 Academic Session!",
    body: "Prince Learning Hub warmly welcomes all new and returning students. All course materials for the first semester are now available for download in the Materials section. Please update your profile with your correct registration number before writing any CBT test.",
    category: "Announcement",
    pinned: true,
  },
  {
    title: "CBT Practice Tests Now Open",
    body: "CBT practice tests are now live for every class. Each test has 10 questions and its own timer. Results are released immediately after submission with full corrections. Attempt them as many times as you like.",
    category: "CBT Tests",
    pinned: false,
  },
  {
    title: "Live Lecture: Introduction to Programming",
    body: "Dr. Adebayo will hold a live online lecture on Introduction to Programming this week. Join from the Lectures page and use the lecture chat to ask questions in real time.",
    category: "Lectures",
    pinned: false,
  },
  {
    title: "Mid-Semester Break Schedule",
    body: "The mid-semester break will run for one week. Recorded lectures remain available during the break, and the chat rooms will stay open for peer discussions and tutor support.",
    category: "Calendar",
    pinned: false,
  },
  {
    title: "New Study Materials Uploaded for MTH 101",
    body: "Lecture notes on Sets, Functions and Basic Calculus have been uploaded. Head over to the Materials page to download them.",
    category: "Materials",
    pinned: false,
  },
];

function notes(code: string, title: string, sections: string[]) {
  return [
    `PRINCE LEARNING HUB`,
    `${code} — ${title}`,
    `=`.repeat(50),
    ``,
    ...sections.flatMap((s, i) => [`${i + 1}. ${s}`, ``]),
    `-`.repeat(50),
    `© Prince Learning Hub. For registered students only.`,
  ].join("\n");
}

export const seedMaterials = [
  {
    title: "Introduction to Computer Science — Lecture Notes",
    courseCode: "CSC101",
    courseTitle: "Introduction to Computer Science",
    description: "Covers the history of computing, hardware and software components, number systems and basic algorithms.",
    fileName: "CSC101_Lecture_Notes.txt",
    content: notes("CSC101", "Introduction to Computer Science", [
      "HISTORY OF COMPUTING: From the abacus to Charles Babbage's Analytical Engine, to modern microprocessors.",
      "COMPUTER HARDWARE: Input devices (keyboard, mouse), output devices (monitor, printer), the CPU (ALU + Control Unit) and memory (RAM, ROM).",
      "SOFTWARE: System software (operating systems, utilities) vs application software (word processors, browsers).",
      "NUMBER SYSTEMS: Binary (base 2), Octal (base 8), Decimal (base 10) and Hexadecimal (base 16). Example: 1010 (binary) = 10 (decimal).",
      "ALGORITHMS: A finite, ordered set of well-defined steps for solving a problem. Represented using pseudocode or flowcharts.",
    ]),
  },
  {
    title: "Elementary Mathematics I — Sets & Functions",
    courseCode: "MTH101",
    courseTitle: "Elementary Mathematics I",
    description: "Set theory, Venn diagrams, relations, functions and an introduction to limits.",
    fileName: "MTH101_Sets_and_Functions.txt",
    content: notes("MTH101", "Elementary Mathematics I", [
      "SETS: A set is a well-defined collection of objects. Notation: A = {1, 2, 3}.",
      "SET OPERATIONS: Union (A ∪ B), Intersection (A ∩ B), Complement (A'), Difference (A − B).",
      "VENN DIAGRAMS: n(A ∪ B) = n(A) + n(B) − n(A ∩ B).",
      "FUNCTIONS: A function f: A → B assigns each element of A exactly one element in B.",
      "LIMITS: lim(x→a) f(x) describes the value f(x) approaches as x approaches a.",
    ]),
  },
  {
    title: "Use of English — Communication Skills Handbook",
    courseCode: "GST101",
    courseTitle: "Use of English & Communication Skills",
    description: "Parts of speech, sentence structure, essay writing and effective communication.",
    fileName: "GST101_Communication_Handbook.txt",
    content: notes("GST101", "Use of English & Communication Skills", [
      "PARTS OF SPEECH: Noun, Pronoun, Verb, Adjective, Adverb, Preposition, Conjunction, Interjection.",
      "SENTENCE TYPES: Simple, Compound, Complex and Compound-Complex sentences.",
      "CONCORD: The subject and verb must agree in number. E.g. 'The list of items IS on the desk.'",
      "ESSAY WRITING: Introduction, body paragraphs with topic sentences, and conclusion.",
      "COMMUNICATION PROCESS: Sender → Message → Channel → Receiver → Feedback.",
    ]),
  },
  {
    title: "General Physics I — Mechanics Summary",
    courseCode: "PHY101",
    courseTitle: "General Physics I",
    description: "Units and dimensions, motion in a straight line, Newton's laws and work-energy.",
    fileName: "PHY101_Mechanics_Summary.txt",
    content: notes("PHY101", "General Physics I", [
      "UNITS: SI base units — metre (m), kilogram (kg), second (s), ampere (A), kelvin (K), mole (mol), candela (cd).",
      "KINEMATICS: v = u + at; s = ut + ½at²; v² = u² + 2as.",
      "NEWTON'S LAWS: (1) Inertia, (2) F = ma, (3) Action and reaction are equal and opposite.",
      "WORK & ENERGY: W = F·d; KE = ½mv²; PE = mgh.",
      "MOMENTUM: p = mv. Momentum is conserved in a closed system.",
    ]),
  },
  {
    title: "CBT Exam Guide & Past Question Tips",
    courseCode: "GST101",
    courseTitle: "Use of English & Communication Skills",
    description: "How the CBT system works, timing strategies and tips for scoring high.",
    fileName: "CBT_Exam_Guide.txt",
    content: notes("CBT", "Exam Guide", [
      "Sign in with your full name and registration number before starting.",
      "Each test is timed. The timer starts as soon as you click 'Start Test'.",
      "Use the question navigator to jump between questions. Unanswered questions are shown in grey.",
      "The test is automatically submitted when time runs out.",
      "Your result and corrections are displayed immediately after submission.",
    ]),
  },
];

export const seedQuestions = [
  {
    question: "Which part of the computer is known as the 'brain' of the computer?",
    options: ["Monitor", "Central Processing Unit (CPU)", "Keyboard", "Hard Disk"],
    answerIndex: 1,
    explanation: "The CPU processes instructions and controls all other components, so it is called the brain of the computer.",
  },
  {
    question: "What is the binary equivalent of the decimal number 10?",
    options: ["1001", "1100", "1010", "1110"],
    answerIndex: 2,
    explanation: "10 = 8 + 2 = 1×2³ + 0×2² + 1×2¹ + 0×2⁰ = 1010.",
  },
  {
    question: "Choose the correct sentence:",
    options: [
      "The list of items are on the desk.",
      "The list of items is on the desk.",
      "The list of items were on the desk.",
      "The list of items be on the desk.",
    ],
    answerIndex: 1,
    explanation: "The subject is 'list' (singular), so the verb must be singular: 'is'.",
  },
  {
    question: "If A = {1, 2, 3, 4} and B = {3, 4, 5}, what is A ∩ B?",
    options: ["{1, 2}", "{3, 4}", "{1, 2, 3, 4, 5}", "{5}"],
    answerIndex: 1,
    explanation: "The intersection contains elements common to both sets: 3 and 4.",
  },
  {
    question: "What is the SI unit of force?",
    options: ["Joule", "Watt", "Newton", "Pascal"],
    answerIndex: 2,
    explanation: "Force is measured in Newtons (N), where 1 N = 1 kg·m/s².",
  },
  {
    question: "Which of the following is an example of system software?",
    options: ["Microsoft Word", "Windows Operating System", "Google Chrome", "Adobe Photoshop"],
    answerIndex: 1,
    explanation: "An operating system manages hardware and provides services for applications, making it system software.",
  },
  {
    question: "Solve for x: 2x + 6 = 14",
    options: ["x = 3", "x = 4", "x = 5", "x = 10"],
    answerIndex: 1,
    explanation: "2x = 14 − 6 = 8, so x = 4.",
  },
  {
    question: "The word 'quickly' in the sentence 'She ran quickly' is a/an:",
    options: ["Adjective", "Noun", "Adverb", "Verb"],
    answerIndex: 2,
    explanation: "'Quickly' modifies the verb 'ran', describing how she ran, so it is an adverb.",
  },
  {
    question: "What does 'www' stand for in a website address?",
    options: ["World Wide Web", "Wide World Web", "Web World Wide", "World Web Wide"],
    answerIndex: 0,
    explanation: "WWW stands for World Wide Web, the system of interlinked web pages accessed via the Internet.",
  },
  {
    question: "A car accelerates from rest at 2 m/s² for 5 seconds. What is its final velocity?",
    options: ["5 m/s", "7 m/s", "10 m/s", "25 m/s"],
    answerIndex: 2,
    explanation: "Using v = u + at: v = 0 + (2 × 5) = 10 m/s.",
  },
];

const HOUR = 60 * 60 * 1000;
const DAY = 24 * HOUR;

export function seedLectures(now = Date.now()) {
  return [
    {
      title: "Introduction to Programming & Computer Science",
      courseCode: "CSC101",
      lecturer: "Dr. Adebayo Okafor",
      description: "Live class: what programming is, how computers execute instructions, and writing your first algorithm.",
      videoId: "zOjov-2OZ0E",
      scheduledAt: new Date(now - 15 * 60 * 1000),
      durationMin: 120,
      status: "live",
    },
    {
      title: "Python for Beginners",
      courseCode: "CSC101",
      lecturer: "Engr. Grace Bello",
      description: "Hands-on Python session: variables, data types, conditionals and loops.",
      videoId: "kqtD5dpn9C8",
      scheduledAt: new Date(now + 2 * DAY),
      durationMin: 60,
      status: "upcoming",
    },
    {
      title: "The Essence of Calculus",
      courseCode: "MTH101",
      lecturer: "Prof. Samuel Eze",
      description: "An intuitive introduction to derivatives, integrals and limits.",
      videoId: "WUvTyaaNkzM",
      scheduledAt: new Date(now + 4 * DAY),
      durationMin: 90,
      status: "upcoming",
    },
    {
      title: "Vectors — What Even Are They?",
      courseCode: "MTH101",
      lecturer: "Prof. Samuel Eze",
      description: "Recorded lecture: vectors from the physics, computer science and mathematics viewpoints.",
      videoId: "fNk_zzaMoSs",
      scheduledAt: new Date(now - 3 * DAY),
      durationMin: 60,
      status: "recorded",
    },
    {
      title: "Learn Python — Full Course",
      courseCode: "CSC101",
      lecturer: "Engr. Grace Bello",
      description: "Recorded full-length Python course for self-paced revision.",
      videoId: "rfscVS0vtbw",
      scheduledAt: new Date(now - 7 * DAY),
      durationMin: 240,
      status: "recorded",
    },
  ];
}

export const seedMessages = [
  { room: "general", senderName: "Tutor Prince", regNo: "STAFF-001", body: "Welcome to the Prince Learning Hub chat! Ask your questions here and tutors or classmates will help. 🎓", isQuestion: false },
  { room: "general", senderName: "Amaka Johnson", regNo: "PLH/2026/014", body: "When is the deadline for the GST 101 practice CBT?", isQuestion: true },
  { room: "general", senderName: "Tutor Prince", regNo: "STAFF-001", body: "The practice test is open all semester — you can attempt it as many times as you like.", isQuestion: false },
  { room: "MTH101", senderName: "Tunde Bakare", regNo: "PLH/2026/022", body: "Can someone explain the difference between union and intersection?", isQuestion: true },
  { room: "CSC101", senderName: "Fatima Musa", regNo: "PLH/2026/031", body: "The CSC101 notes are really helpful, especially the number systems part!", isQuestion: false },
];
