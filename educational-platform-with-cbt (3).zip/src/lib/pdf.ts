import { PDFDocument, StandardFonts, rgb, type PDFFont, type PDFPage } from "pdf-lib";
import { CONTACT } from "./academics";

const NAVY = rgb(0.071, 0.11, 0.192);
const GOLD = rgb(0.788, 0.643, 0.353);
const INK = rgb(0.17, 0.2, 0.27);
const MUTED = rgb(0.42, 0.47, 0.55);

const REPLACEMENTS: Record<string, string> = {
  "→": "->", "←": "<-", "∪": " U ", "∩": " n ", "≤": "<=", "≥": ">=", "≠": "!=", "×": "x", "÷": "/",
  "−": "-", "√": "sqrt", "π": "pi", "∑": "Sum", "∫": "integral", "Ω": " ohms", "₦": "N", "²": "^2", "³": "^3",
  "⁴": "^4", "ⁿ": "^n", "⁻": "^-", "₂": "2", "₁": "1", "₀": "0", "°": " deg", "✓": "*", "≈": "~",
};

/** Make text safe for the standard (WinAnsi) PDF fonts. */
export function pdfSafe(s: string) {
  let out = "";
  for (const ch of s) {
    if (REPLACEMENTS[ch] !== undefined) out += REPLACEMENTS[ch];
    else if (ch.charCodeAt(0) <= 0xff || "—–‘’“”•…€™".includes(ch)) out += ch;
    else out += "?";
  }
  return out;
}

function wrap(text: string, font: PDFFont, size: number, maxWidth: number) {
  const lines: string[] = [];
  for (const para of text.split("\n")) {
    if (!para.trim()) {
      lines.push("");
      continue;
    }
    let line = "";
    for (const word of para.split(/\s+/)) {
      const test = line ? `${line} ${word}` : word;
      if (font.widthOfTextAtSize(test, size) > maxWidth && line) {
        lines.push(line);
        line = word;
      } else line = test;
    }
    if (line) lines.push(line);
  }
  return lines;
}

export type PdfSection = { heading: string; body: string };

export async function buildMaterialPdf(opts: {
  title: string;
  courseCode: string;
  courseTitle: string;
  audience: string;
  sections: PdfSection[];
}): Promise<Uint8Array> {
  const doc = await PDFDocument.create();
  doc.setTitle(pdfSafe(`${opts.courseCode} — ${opts.title}`));
  doc.setAuthor("Prince Learning Hub");
  doc.setSubject(pdfSafe(opts.courseTitle));
  doc.setCreator("Prince Learning Hub");

  const serif = await doc.embedFont(StandardFonts.TimesRoman);
  const serifBold = await doc.embedFont(StandardFonts.TimesRomanBold);
  const sans = await doc.embedFont(StandardFonts.Helvetica);
  const sansBold = await doc.embedFont(StandardFonts.HelveticaBold);

  const W = 595.28;
  const H = 841.89;
  const M = 56;
  const contentW = W - M * 2;
  const pages: PDFPage[] = [];
  let page!: PDFPage;
  let y = 0;

  const newPage = (first = false) => {
    page = doc.addPage([W, H]);
    pages.push(page);
    if (first) {
      page.drawRectangle({ x: 0, y: H - 150, width: W, height: 150, color: NAVY });
      page.drawRectangle({ x: 0, y: H - 154, width: W, height: 4, color: GOLD });
      page.drawText("PRINCE LEARNING HUB", { x: M, y: H - 50, size: 10, font: sansBold, color: GOLD });
      page.drawText(pdfSafe(opts.audience.toUpperCase()), { x: M, y: H - 66, size: 8, font: sans, color: rgb(0.75, 0.8, 0.88) });
      const titleLines = wrap(pdfSafe(opts.title), serifBold, 22, contentW);
      let ty = H - 98;
      for (const l of titleLines.slice(0, 2)) {
        page.drawText(l, { x: M, y: ty, size: 22, font: serifBold, color: rgb(1, 1, 1) });
        ty -= 26;
      }
      page.drawText(pdfSafe(`${opts.courseCode}  ·  ${opts.courseTitle}`), { x: M, y: H - 172, size: 10, font: sansBold, color: INK });
      page.drawLine({ start: { x: M, y: H - 182 }, end: { x: W - M, y: H - 182 }, thickness: 0.5, color: rgb(0.85, 0.85, 0.85) });
      y = H - 210;
    } else {
      page.drawText(pdfSafe(`${opts.courseCode} — ${opts.title}`), { x: M, y: H - 36, size: 8, font: sans, color: MUTED });
      page.drawLine({ start: { x: M, y: H - 44 }, end: { x: W - M, y: H - 44 }, thickness: 0.5, color: rgb(0.88, 0.88, 0.88) });
      y = H - 72;
    }
  };

  const ensure = (needed: number) => {
    if (y - needed < 70) newPage();
  };

  newPage(true);

  opts.sections.forEach((s, i) => {
    ensure(50);
    page.drawText(`${i + 1}.`, { x: M, y, size: 13, font: serifBold, color: GOLD });
    const headLines = wrap(pdfSafe(s.heading), serifBold, 13, contentW - 22);
    for (const hl of headLines) {
      page.drawText(hl, { x: M + 22, y, size: 13, font: serifBold, color: NAVY });
      y -= 18;
    }
    y -= 2;
    for (const line of wrap(pdfSafe(s.body), serif, 11.5, contentW - 22)) {
      ensure(16);
      if (line) page.drawText(line, { x: M + 22, y, size: 11.5, font: serif, color: INK });
      y -= 16;
    }
    y -= 12;
  });

  pages.forEach((p, i) => {
    p.drawLine({ start: { x: M, y: 48 }, end: { x: W - M, y: 48 }, thickness: 0.5, color: rgb(0.88, 0.88, 0.88) });
    p.drawText(pdfSafe(`WhatsApp: ${CONTACT.whatsapp}   ·   Email: ${CONTACT.email}`), { x: M, y: 32, size: 8, font: sans, color: MUTED });
    const label = `Page ${i + 1} of ${pages.length}`;
    p.drawText(label, { x: W - M - sans.widthOfTextAtSize(label, 8), y: 32, size: 8, font: sans, color: MUTED });
  });

  return doc.save();
}
