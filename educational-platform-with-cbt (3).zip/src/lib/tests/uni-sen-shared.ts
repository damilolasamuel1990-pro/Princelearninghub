import type { TestDef } from "./types";
import { pick, share } from "./shared";
import { csc100Tests } from "./uni-csc-100";
import { csc200Tests } from "./uni-csc-200";

/**
 * Software Engineering 100 & 200 Level courses that have the same titles as
 * Computer Science courses — the students attend the same classes, so the
 * question banks are shared exactly.
 */
const SEN = { department: "SEN" };

export const senSharedTests: TestDef[] = [
  // 100 LEVEL — FIRST SEMESTER
  share(pick(csc100Tests, "COS 101"), {
    ...SEN,
    title: "Introduction to Computer Sciences",
    description: "Shared with Computer Science (COS 101) — history of computing, components, applications, information processing, the Internet and computing careers.",
  }),
  share(pick(csc100Tests, "WUI-LBS 001"), {
    ...SEN,
    code: "WUI-LIB 001",
    title: "Use of Library, Study Skills and Information Communication Technology",
    description: "Shared with Computer Science (WUI-LBS 001) — libraries, study skills, information retrieval, ICT tools, referencing and lifelong learning.",
  }),
  share(pick(csc100Tests, "WUI-CSC 101"), { ...SEN }),
  share(pick(csc100Tests, "WUI-CSC 103"), { ...SEN }),

  // 200 LEVEL — FIRST SEMESTER
  share(pick(csc200Tests, "COS 201"), { ...SEN }),
  share(pick(csc200Tests, "SEN 201"), { ...SEN }),
  share(pick(csc200Tests, "COS 201"), {
    ...SEN,
    code: "WUI-SEN 263",
    title: "Computer Programming I Lab",
    description: "Same question bank as COS 201 Computer Programming I — paradigms, Java basics, OOP, strings, control structures, arrays and recursion.",
  }),
  share(pick(csc200Tests, "WUI-CSC 201"), { ...SEN }),
];
