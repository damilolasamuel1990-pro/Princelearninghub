import { universityTests } from "./university";
import { csc100Tests } from "./uni-csc-100";
import { csc200Tests } from "./uni-csc-200";
import { csc300Tests } from "./uni-csc-300";
import { csc400Tests } from "./uni-csc-400";
import { senSharedTests } from "./uni-sen-shared";
import { sen300aTests } from "./uni-sen-300a";
import { sen300bTests } from "./uni-sen-300b";
import { sen400aTests } from "./uni-sen-400a";
import { sen400bTests } from "./uni-sen-400b";
import { nd1FirstTests } from "./nd1-first";
import { nd1SecondTests } from "./nd1-second";
import { nd2FirstTests } from "./nd2-first";
import { nd2SecondTests } from "./nd2-second";
import { polytechnicTests } from "./polytechnic";
import { digitalTechTests } from "./digital";
import { schoolTests } from "./schools";
import type { TestDef } from "./types";

/**
 * Remaining university general courses (department "ALL") are offered to Computer
 * Engineering. Computer Science and Software Engineering use their own curricula.
 */
const expandGeneral = (t: TestDef): TestDef[] =>
  t.category === "university" && t.department === "ALL" ? [{ ...t, department: "CPE" }] : [t];

export const ALL_TESTS: TestDef[] = [
  // University — Computer Science
  ...csc100Tests,
  ...csc200Tests,
  ...csc300Tests,
  ...csc400Tests,
  // University — Software Engineering
  ...senSharedTests,
  ...sen300aTests,
  ...sen300bTests,
  ...sen400aTests,
  ...sen400bTests,
  // University — Computer Engineering & general
  ...universityTests.flatMap(expandGeneral),
  // Polytechnic
  ...nd1FirstTests,
  ...nd1SecondTests,
  ...nd2FirstTests,
  ...nd2SecondTests,
  ...polytechnicTests,
  // Secondary & Primary
  ...digitalTechTests,
  ...schoolTests,
];
export type { TestDef, QDef, CQ } from "./types";
