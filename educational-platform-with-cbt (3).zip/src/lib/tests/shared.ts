import type { TestDef } from "./types";

/** Find a test by code in a list (throws at build/seed time if missing). */
export function pick(list: TestDef[], code: string): TestDef {
  const t = list.find((x) => x.code === code);
  if (!t) throw new Error(`Shared test source not found: ${code}`);
  return t;
}

/**
 * Re-use the exact same question bank for a course with the same title
 * offered under another code, level or department (students attend the same class).
 */
export function share(src: TestDef, overrides: Partial<TestDef>): TestDef {
  return { ...src, levels: undefined, ...overrides };
}
