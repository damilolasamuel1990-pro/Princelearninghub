export type QDef = [question: string, options: string[], answerIndex: number, explanation: string];

/**
 * Compact question format: the correct answer is always written first.
 * Options are shuffled deterministically when the database is seeded,
 * so the correct letter is spread evenly across A–D.
 */
export type CQ = [question: string, correct: string, wrong1: string, wrong2: string, wrong3: string, explanation?: string];

export const fromCompact = (qs: CQ[]): QDef[] => qs.map(([q, c, w1, w2, w3, e]) => [q, [c, w1, w2, w3], 0, e ?? ""]);

export type TestDef = {
  code: string;
  title: string;
  category: "university" | "polytechnic" | "secondary" | "primary";
  department: string;
  /** Display label, e.g. "ND 1" or "JSS 1 – 3". */
  level: string;
  /** Levels this test is available to. Defaults to [level]. */
  levels?: string[];
  semester?: string;
  durationMin: number;
  description: string;
  questions: QDef[];
};
