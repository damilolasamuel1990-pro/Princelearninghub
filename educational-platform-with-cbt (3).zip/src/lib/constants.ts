export const COURSES: Record<string, string> = {
  CSC101: "Introduction to Computer Science",
  MTH101: "Elementary Mathematics I",
  GST101: "Use of English & Communication Skills",
  PHY101: "General Physics I",
};

export const COURSE_IMAGES: Record<string, string> = {
  CSC101: "/images/course-csc.jpg",
  MTH101: "/images/course-mth.jpg",
  GST101: "/images/course-gst.jpg",
  PHY101: "/images/course-phy.jpg",
};

export const NEWS_IMAGES: Record<string, string> = {
  Announcement: "/images/graduation.jpg",
  "CBT Tests": "/images/exam.jpg",
  Exams: "/images/exam.jpg",
  Lectures: "/images/lecturer.jpg",
  Calendar: "/images/library.jpg",
  Materials: "/images/computers-library.jpg",
  General: "/images/group-study.jpg",
};

export function materialImage(m: { category: string; department: string; courseCode: string }) {
  const code = m.courseCode.toUpperCase();
  if (m.category === "primary") return "/images/primary.jpg";
  if (m.category === "secondary") {
    if (code.includes("PHY") || code.includes("CHM")) return "/images/course-phy.jpg";
    if (code.includes("MTH")) return "/images/course-mth.jpg";
    return "/images/secondary.jpg";
  }
  if (m.department === "HND-NCC") return "/images/networking.jpg";
  if (m.department === "HND-CYB") return "/images/cybersecurity.jpg";
  if (m.department === "HND-AI") return "/images/computers-library.jpg";
  if (m.department === "CPE") return "/images/engineering.jpg";
  if (code.startsWith("MTH")) return "/images/course-mth.jpg";
  if (code.startsWith("GST")) return "/images/course-gst.jpg";
  if (code.startsWith("PHY")) return "/images/course-phy.jpg";
  if (m.category === "ALL") return "/images/notebook.jpg";
  return "/images/course-csc.jpg";
}

export function newsImage(category: string) {
  return NEWS_IMAGES[category] ?? NEWS_IMAGES.General;
}

export const CHAT_ROOMS = [
  { id: "general", name: "General Lounge", desc: "Open to all students" },
  { id: "CSC101", name: "CSC 101", desc: "Computer Science" },
  { id: "MTH101", name: "MTH 101", desc: "Mathematics" },
  { id: "GST101", name: "GST 101", desc: "Use of English" },
  { id: "PHY101", name: "PHY 101", desc: "Physics" },
];

export const CBT_DURATION_SECONDS = 10 * 60;

export function formatBytes(n: number) {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / (1024 * 1024)).toFixed(1)} MB`;
}

export function formatDuration(sec: number) {
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return `${m}m ${s.toString().padStart(2, "0")}s`;
}

export function grade(pct: number) {
  if (pct >= 70) return { letter: "A", label: "Excellent", color: "text-emerald-700" };
  if (pct >= 60) return { letter: "B", label: "Very Good", color: "text-teal-700" };
  if (pct >= 50) return { letter: "C", label: "Good", color: "text-sky-700" };
  if (pct >= 45) return { letter: "D", label: "Fair", color: "text-amber-700" };
  if (pct >= 40) return { letter: "E", label: "Pass", color: "text-orange-700" };
  return { letter: "F", label: "Fail", color: "text-rose-700" };
}
