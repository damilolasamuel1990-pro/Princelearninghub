export type CategoryId = "university" | "polytechnic" | "secondary" | "primary";

export type Department = { id: string; name: string; levels: string[] };
export type Category = {
  id: CategoryId;
  name: string;
  tagline: string;
  idLabel: string;
  idPlaceholder: string;
  image: string;
  departments: Department[];
};

const uniLevels = (n: number) => Array.from({ length: n }, (_, i) => `${(i + 1) * 100} Level`);

export const CATEGORIES: Category[] = [
  {
    id: "university",
    name: "University",
    tagline: "Computer Science · Software Engineering · Computer Engineering",
    idLabel: "Matriculation number",
    idPlaceholder: "e.g. CSC/2026/014",
    image: "/images/lecture-hall.jpg",
    departments: [
      { id: "CSC", name: "Computer Science", levels: uniLevels(4) },
      { id: "SEN", name: "Software Engineering", levels: uniLevels(4) },
      { id: "CPE", name: "Computer Engineering", levels: uniLevels(5) },
    ],
  },
  {
    id: "polytechnic",
    name: "Polytechnic",
    tagline: "ND Computer Science · HND (unbundled) programmes",
    idLabel: "Matriculation number",
    idPlaceholder: "e.g. ND/COM/2026/031",
    image: "/images/computers-library.jpg",
    departments: [
      { id: "ND-CSC", name: "ND Computer Science", levels: ["ND 1", "ND 2"] },
      { id: "HND-SWD", name: "HND Software & Web Development", levels: ["HND 1", "HND 2"] },
      { id: "HND-NCC", name: "HND Networking & Cloud Computing", levels: ["HND 1", "HND 2"] },
      { id: "HND-CYB", name: "HND Cybersecurity & Data Protection", levels: ["HND 1", "HND 2"] },
      { id: "HND-AI", name: "HND Artificial Intelligence", levels: ["HND 1", "HND 2"] },
    ],
  },
  {
    id: "secondary",
    name: "Secondary School",
    tagline: "Junior (JSS 1–3) and Senior (SSS 1–3) secondary",
    idLabel: "Admission number",
    idPlaceholder: "e.g. SSS/2026/112",
    image: "/images/secondary.jpg",
    departments: [
      { id: "JSS", name: "Junior Secondary (JSS)", levels: ["JSS 1", "JSS 2", "JSS 3"] },
      { id: "SSS", name: "Senior Secondary (SSS)", levels: ["SSS 1", "SSS 2", "SSS 3"] },
    ],
  },
  {
    id: "primary",
    name: "Primary School",
    tagline: "Primary 1 to Primary 6",
    idLabel: "Admission number",
    idPlaceholder: "e.g. PRY/2026/045",
    image: "/images/primary.jpg",
    departments: [{ id: "PRI", name: "Primary School", levels: ["Primary 1", "Primary 2", "Primary 3", "Primary 4", "Primary 5", "Primary 6"] }],
  },
];

export function getCategory(id?: string | null) {
  return CATEGORIES.find((c) => c.id === id);
}

export function getDepartment(catId?: string | null, depId?: string | null) {
  return getCategory(catId)?.departments.find((d) => d.id === depId);
}

export function departmentName(catId: string, depId: string) {
  if (depId === "ALL") return catId === "university" ? "All Departments" : "All";
  return getDepartment(catId, depId)?.name ?? depId;
}

export function audienceLabel(catId: string, depId: string, level: string) {
  const cat = getCategory(catId)?.name ?? catId;
  if (catId === "primary") return `${cat} · ${level}`;
  return `${cat} · ${departmentName(catId, depId)} · ${level}`;
}

export const CONTACT = {
  whatsapp: "07036042766",
  whatsappIntl: "2347036042766",
  email: "damilolasamuel1990@gmail.com",
};

export const whatsappLink = (text = "Hello Prince Learning Hub, I need help with…") =>
  `https://wa.me/${CONTACT.whatsappIntl}?text=${encodeURIComponent(text)}`;
