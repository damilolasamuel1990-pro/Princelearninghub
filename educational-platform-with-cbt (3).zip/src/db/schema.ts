import { boolean, integer, jsonb, pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";

export const meta = pgTable("meta", {
  key: text("key").primaryKey(),
  value: text("value").notNull(),
});

export const news = pgTable("news", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  body: text("body").notNull(),
  category: text("category").notNull().default("General"),
  pinned: boolean("pinned").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const materials = pgTable("materials", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  courseCode: text("course_code").notNull(),
  courseTitle: text("course_title").notNull(),
  category: text("category").notNull().default("ALL"),
  department: text("department").notNull().default("ALL"),
  level: text("level").notNull().default("All Levels"),
  description: text("description").notNull().default(""),
  fileName: text("file_name").notNull(),
  mimeType: text("mime_type").notNull().default("application/pdf"),
  data: text("data").notNull(),
  sizeBytes: integer("size_bytes").notNull().default(0),
  downloads: integer("downloads").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const tests = pgTable("tests", {
  id: serial("id").primaryKey(),
  code: text("code").notNull(),
  title: text("title").notNull(),
  category: text("category").notNull(),
  department: text("department").notNull(),
  level: text("level").notNull(),
  levels: text("levels").notNull().default(""),
  semester: text("semester").notNull().default(""),
  durationMin: integer("duration_min").notNull().default(10),
  description: text("description").notNull().default(""),
  sort: integer("sort").notNull().default(0),
});

export const questions = pgTable("questions", {
  id: serial("id").primaryKey(),
  testId: integer("test_id").notNull(),
  question: text("question").notNull(),
  options: jsonb("options").$type<string[]>().notNull(),
  answerIndex: integer("answer_index").notNull(),
  explanation: text("explanation").notNull().default(""),
});

export const results = pgTable("results", {
  id: serial("id").primaryKey(),
  studentName: text("student_name").notNull(),
  regNo: text("reg_no").notNull(),
  testId: integer("test_id").notNull(),
  courseCode: text("course_code").notNull(),
  testTitle: text("test_title").notNull(),
  category: text("category").notNull(),
  department: text("department").notNull(),
  level: text("level").notNull(),
  score: integer("score").notNull(),
  total: integer("total").notNull(),
  percentage: integer("percentage").notNull(),
  timeTaken: integer("time_taken").notNull(),
  durationSec: integer("duration_sec").notNull(),
  answers: jsonb("answers").$type<Record<string, number>>().notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const lectures = pgTable("lectures", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  courseCode: text("course_code").notNull(),
  lecturer: text("lecturer").notNull(),
  description: text("description").notNull().default(""),
  videoId: text("video_id").notNull(),
  scheduledAt: timestamp("scheduled_at", { withTimezone: true }).notNull(),
  durationMin: integer("duration_min").notNull().default(60),
  status: text("status").notNull().default("upcoming"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  room: text("room").notNull(),
  senderName: text("sender_name").notNull(),
  regNo: text("reg_no").notNull(),
  body: text("body").notNull(),
  isQuestion: boolean("is_question").notNull().default(false),
  replyTo: integer("reply_to"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type News = typeof news.$inferSelect;
export type Material = typeof materials.$inferSelect;
export type Test = typeof tests.$inferSelect;
export type Question = typeof questions.$inferSelect;
export type Result = typeof results.$inferSelect;
export type Lecture = typeof lectures.$inferSelect;
export type Message = typeof messages.$inferSelect;
