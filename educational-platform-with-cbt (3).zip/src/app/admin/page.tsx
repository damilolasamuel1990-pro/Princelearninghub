"use client";

import { useEffect, useState } from "react";
import PageHeader from "@/components/PageHeader";
import { COURSES } from "@/lib/constants";
import MaterialForm from "./MaterialForm";

type Lecture = { id: number; title: string; courseCode: string; status: string };
type News = { id: number; title: string; category: string };

const input = "w-full rounded-sm border border-stone-300 px-3 py-2 text-sm outline-none focus:border-ink-700 focus:ring-4 focus:ring-ink-100";

export default function AdminPage() {
  const [code, setCode] = useState("");
  const [unlocked, setUnlocked] = useState(false);
  const [tab, setTab] = useState<"news" | "material" | "lecture">("news");
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [lecs, setLecs] = useState<Lecture[]>([]);
  const [newsList, setNewsList] = useState<News[]>([]);

  useEffect(() => {
    const saved = sessionStorage.getItem("plh-admin");
    if (saved) {
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setCode(saved);
      setUnlocked(true);
    }
  }, []);

  const refresh = () => {
    fetch("/api/lectures").then((r) => r.json()).then(setLecs).catch(() => {});
    fetch("/api/news").then((r) => r.json()).then(setNewsList).catch(() => {});
  };
  useEffect(() => {
    if (unlocked) refresh();
  }, [unlocked]);

  const headers = { "x-admin-code": code };

  async function handle(res: Response, okText: string, form?: HTMLFormElement) {
    const data = await res.json().catch(() => ({}));
    if (res.ok) {
      setMsg({ ok: true, text: okText });
      form?.reset();
      refresh();
    } else {
      setMsg({ ok: false, text: data.error || "Something went wrong" });
      if (res.status === 401) {
        setUnlocked(false);
        sessionStorage.removeItem("plh-admin");
      }
    }
  }

  if (!unlocked) {
    return (
      <div>
        <PageHeader eyebrow="Staff Only" title="Staff Portal" subtitle="Publish news, upload course materials and manage the lecture timetable." image="/images/lecturer.jpg" />
        <form
          onSubmit={(e) => {
            e.preventDefault();
            sessionStorage.setItem("plh-admin", code);
            setUnlocked(true);
          }}
          className="mx-auto mt-10 max-w-sm rounded-md border border-stone-200 bg-white p-6 "
        >
          <label className="mb-1 block text-sm font-semibold text-ink-700">Admin access code</label>
          <input type="password" value={code} onChange={(e) => setCode(e.target.value)} className={input} placeholder="Enter access code" />
          <p className="mt-2 text-xs text-ink-500">Default demo code: <code className="rounded bg-stone-100 px-1">prince-admin</code></p>
          {msg && !msg.ok && <p className="mt-2 text-sm text-rose-600">{msg.text}</p>}
          <button className="mt-4 w-full rounded-sm bg-ink-900 py-2.5 font-semibold text-white hover:bg-ink-800">Unlock</button>
        </form>
      </div>
    );
  }

  return (
    <div>
      <PageHeader eyebrow="Staff Only" title="Staff Portal" subtitle="Publish news, upload course materials and manage the lecture timetable." image="/images/lecturer.jpg" />
      <div className="mx-auto max-w-5xl px-4 py-8">
        <div className="mb-6 flex flex-wrap gap-2">
          {(
            [
              ["news", "Publish News"],
              ["material", "Upload PDF Material"],
              ["lecture", "Lectures"],
            ] as const
          ).map(([k, l]) => (
            <button
              key={k}
              onClick={() => {
                setTab(k);
                setMsg(null);
              }}
              className={`rounded-sm px-4 py-2.5 text-sm font-semibold ${tab === k ? "bg-ink-900 text-white" : "border border-stone-300 bg-white text-ink-700"}`}
            >
              {l}
            </button>
          ))}
          <button
            onClick={() => {
              sessionStorage.removeItem("plh-admin");
              setUnlocked(false);
              setCode("");
            }}
            className="ml-auto rounded-sm px-4 py-2.5 text-sm font-semibold text-rose-600 hover:bg-rose-50"
          >
            Lock
          </button>
        </div>

        {msg && (
          <div className={`mb-4 rounded-sm p-3 text-sm font-medium ${msg.ok ? "bg-emerald-50 text-emerald-800" : "bg-rose-50 text-rose-700"}`}>{msg.text}</div>
        )}

        {tab === "news" && (
          <div className="grid gap-6 md:grid-cols-2">
            <form
              onSubmit={async (e) => {
                e.preventDefault();
                const f = e.currentTarget;
                const fd = new FormData(f);
                const res = await fetch("/api/news", {
                  method: "POST",
                  headers: { ...headers, "Content-Type": "application/json" },
                  body: JSON.stringify({ title: fd.get("title"), body: fd.get("body"), category: fd.get("category"), pinned: fd.get("pinned") === "on" }),
                });
                handle(res, "News published!", f);
              }}
              className="space-y-3 rounded-md border border-stone-200 bg-white p-6 "
            >
              <h3 className="font-serif text-xl text-ink-950">Publish news</h3>
              <input name="title" required placeholder="Headline" className={input} />
              <select name="category" className={input}>
                {["Announcement", "CBT Tests", "Lectures", "Materials", "Calendar", "General"].map((c) => (
                  <option key={c}>{c}</option>
                ))}
              </select>
              <textarea name="body" required rows={5} placeholder="News content…" className={input} />
              <label className="flex items-center gap-2 text-sm"><input type="checkbox" name="pinned" className="accent-ink-900" /> Pin to top</label>
              <button className="w-full rounded-sm bg-ink-900 py-2.5 font-semibold text-white hover:bg-ink-800">Publish</button>
            </form>
            <div className="rounded-md border border-stone-200 bg-white p-6 ">
              <h3 className="mb-3 font-serif text-xl text-ink-950">Existing news</h3>
              <ul className="divide-y divide-stone-100">
                {newsList.map((n) => (
                  <li key={n.id} className="flex items-center justify-between gap-2 py-2 text-sm">
                    <span className="min-w-0 truncate">{n.title}</span>
                    <button
                      onClick={async () => {
                        if (!confirm("Delete this news item?")) return;
                        handle(await fetch(`/api/news?id=${n.id}`, { method: "DELETE", headers }), "News deleted");
                      }}
                      className="shrink-0 text-xs font-semibold text-rose-600 hover:underline"
                    >
                      Delete
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        )}

        {tab === "material" && <MaterialForm headers={headers} onResult={handle} />}

        {tab === "lecture" && (
          <div className="grid gap-6 md:grid-cols-2">
            <form
              onSubmit={async (e) => {
                e.preventDefault();
                const f = e.currentTarget;
                const fd = new FormData(f);
                const res = await fetch("/api/lectures", {
                  method: "POST",
                  headers: { ...headers, "Content-Type": "application/json" },
                  body: JSON.stringify(Object.fromEntries(fd.entries())),
                });
                handle(res, "Lecture scheduled!", f);
              }}
              className="space-y-3 rounded-md border border-stone-200 bg-white p-6 "
            >
              <h3 className="font-serif text-xl text-ink-950">Schedule a lecture</h3>
              <input name="title" required placeholder="Lecture title" className={input} />
              <div className="grid grid-cols-2 gap-3">
                <select name="courseCode" className={input}>
                  {Object.keys(COURSES).map((c) => (
                    <option key={c}>{c}</option>
                  ))}
                </select>
                <input name="lecturer" required placeholder="Lecturer name" className={input} />
              </div>
              <input name="video" required placeholder="YouTube link or video ID (live or recorded)" className={input} />
              <div className="grid grid-cols-2 gap-3">
                <input name="scheduledAt" type="datetime-local" required className={input} />
                <input name="durationMin" type="number" min={10} defaultValue={60} className={input} />
              </div>
              <select name="status" className={input}>
                <option value="upcoming">Upcoming</option>
                <option value="live">Live now</option>
                <option value="recorded">Recorded</option>
              </select>
              <textarea name="description" rows={3} placeholder="Description" className={input} />
              <button className="w-full rounded-sm bg-ink-900 py-2.5 font-semibold text-white hover:bg-ink-800">Schedule</button>
            </form>
            <div className="rounded-md border border-stone-200 bg-white p-6 ">
              <h3 className="mb-3 font-serif text-xl text-ink-950">Manage lecture status</h3>
              <ul className="divide-y divide-stone-100">
                {lecs.map((l) => (
                  <li key={l.id} className="flex items-center justify-between gap-2 py-2 text-sm">
                    <span className="min-w-0 truncate"><b>{l.courseCode}</b> · {l.title}</span>
                    <select
                      value={l.status}
                      onChange={async (e) =>
                        handle(
                          await fetch("/api/lectures", {
                            method: "PATCH",
                            headers: { ...headers, "Content-Type": "application/json" },
                            body: JSON.stringify({ id: l.id, status: e.target.value }),
                          }),
                          "Lecture status updated",
                        )
                      }
                      className="rounded border border-stone-300 px-2 py-1 text-xs"
                    >
                      <option value="upcoming">Upcoming</option>
                      <option value="live">Live</option>
                      <option value="recorded">Recorded</option>
                    </select>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
