"use client";

import { useState } from "react";
import { CATEGORIES, getCategory } from "@/lib/academics";

const input = "w-full rounded-sm border border-stone-300 px-3 py-2 text-sm outline-none focus:border-ink-700 focus:ring-4 focus:ring-ink-100";

export default function MaterialForm({
  headers,
  onResult,
}: {
  headers: Record<string, string>;
  onResult: (res: Response, okText: string, form?: HTMLFormElement) => void;
}) {
  const [category, setCategory] = useState("university");
  const cat = getCategory(category);
  const [department, setDepartment] = useState("ALL");
  const dep = cat?.departments.find((d) => d.id === department);
  const levels = dep ? dep.levels : Array.from(new Set(cat?.departments.flatMap((d) => d.levels) ?? []));
  const [busy, setBusy] = useState(false);
  const [fileError, setFileError] = useState("");

  return (
    <form
      onSubmit={async (e) => {
        e.preventDefault();
        const f = e.currentTarget;
        const file = (f.elements.namedItem("file") as HTMLInputElement).files?.[0];
        if (!file || !(file.type === "application/pdf" || file.name.toLowerCase().endsWith(".pdf"))) {
          setFileError("Please choose a PDF file.");
          return;
        }
        setFileError("");
        setBusy(true);
        try {
          const res = await fetch("/api/materials", { method: "POST", headers, body: new FormData(f) });
          onResult(res, "PDF uploaded! Students can now download it.", f);
        } finally {
          setBusy(false);
        }
      }}
      className="max-w-2xl space-y-4 rounded-md border border-stone-200 bg-white p-6"
    >
      <h3 className="font-serif text-xl text-ink-950">Upload course material (PDF)</h3>
      <input name="title" required placeholder="Material title, e.g. Data Structures — Week 3 Notes" className={input} />
      <div className="grid gap-3 sm:grid-cols-2">
        <input name="courseCode" required placeholder="Course code, e.g. CSC301" className={`${input} uppercase placeholder:normal-case`} />
        <input name="courseTitle" placeholder="Course title" className={input} />
      </div>
      <div className="grid gap-3 sm:grid-cols-3">
        <select
          name="category"
          value={category}
          onChange={(e) => {
            setCategory(e.target.value);
            setDepartment("ALL");
          }}
          className={input}
        >
          {CATEGORIES.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name}
            </option>
          ))}
          <option value="ALL">All students</option>
        </select>
        <select name="department" value={department} onChange={(e) => setDepartment(e.target.value)} className={input} disabled={!cat}>
          <option value="ALL">All departments</option>
          {cat?.departments.map((d) => (
            <option key={d.id} value={d.id}>
              {d.name}
            </option>
          ))}
        </select>
        <select name="level" className={input} disabled={!cat}>
          <option value="All Levels">All levels</option>
          {levels.map((l) => (
            <option key={l}>{l}</option>
          ))}
        </select>
      </div>
      <textarea name="description" rows={3} placeholder="Short description" className={input} />
      <input
        name="file"
        type="file"
        accept="application/pdf,.pdf"
        required
        className="block w-full text-sm file:mr-3 file:rounded-sm file:border-0 file:bg-gold-50 file:px-4 file:py-2 file:font-semibold file:text-gold-700"
      />
      <p className="text-xs text-ink-500">PDF files only, max 10 MB.</p>
      {fileError && <p className="text-sm text-rose-700">{fileError}</p>}
      <button disabled={busy} className="w-full rounded-sm bg-ink-900 py-2.5 font-semibold text-white hover:bg-ink-800 disabled:opacity-60">
        {busy ? "Uploading…" : "Upload PDF"}
      </button>
    </form>
  );
}
