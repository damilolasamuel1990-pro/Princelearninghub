import { NextResponse } from "next/server";
import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { lectures } from "@/db/schema";
import { ensureDb } from "@/lib/bootstrap";
import { isAdmin } from "@/lib/admin";

export const dynamic = "force-dynamic";

function parseVideoId(input: string) {
  const s = input.trim();
  const m = s.match(/(?:v=|youtu\.be\/|embed\/|live\/)([A-Za-z0-9_-]{11})/);
  return m ? m[1] : s;
}

export async function GET() {
  await ensureDb();
  return NextResponse.json(await db.select().from(lectures).orderBy(asc(lectures.scheduledAt)));
}

export async function POST(req: Request) {
  if (!isAdmin(req)) return NextResponse.json({ error: "Invalid admin code" }, { status: 401 });
  await ensureDb();
  const b = await req.json();
  const title = String(b.title ?? "").trim();
  const video = parseVideoId(String(b.video ?? ""));
  if (!title || !video || !b.scheduledAt) {
    return NextResponse.json({ error: "Title, YouTube link and date are required" }, { status: 400 });
  }
  const [row] = await db
    .insert(lectures)
    .values({
      title,
      courseCode: String(b.courseCode || "GST101"),
      lecturer: String(b.lecturer || "Lecturer"),
      description: String(b.description || ""),
      videoId: video,
      scheduledAt: new Date(b.scheduledAt),
      durationMin: Number(b.durationMin) || 60,
      status: ["live", "upcoming", "recorded"].includes(b.status) ? b.status : "upcoming",
    })
    .returning();
  return NextResponse.json(row, { status: 201 });
}

export async function PATCH(req: Request) {
  if (!isAdmin(req)) return NextResponse.json({ error: "Invalid admin code" }, { status: 401 });
  const b = await req.json();
  if (!["live", "upcoming", "recorded"].includes(b.status)) {
    return NextResponse.json({ error: "Invalid status" }, { status: 400 });
  }
  await db.update(lectures).set({ status: b.status }).where(eq(lectures.id, Number(b.id)));
  return NextResponse.json({ ok: true });
}
