import { NextResponse } from "next/server";
import { and, asc, desc, eq, gt } from "drizzle-orm";
import { db } from "@/db";
import { messages } from "@/db/schema";
import { ensureDb } from "@/lib/bootstrap";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  await ensureDb();
  const url = new URL(req.url);
  const room = url.searchParams.get("room") || "general";
  const after = Number(url.searchParams.get("after") || 0);
  if (after > 0) {
    const rows = await db
      .select()
      .from(messages)
      .where(and(eq(messages.room, room), gt(messages.id, after)))
      .orderBy(asc(messages.id));
    return NextResponse.json(rows);
  }
  const rows = await db.select().from(messages).where(eq(messages.room, room)).orderBy(desc(messages.id)).limit(150);
  return NextResponse.json(rows.reverse());
}

export async function POST(req: Request) {
  await ensureDb();
  const b = await req.json();
  const senderName = String(b.name ?? "").trim().slice(0, 60);
  const regNo = String(b.regNo ?? "").trim().toUpperCase().slice(0, 40);
  const text = String(b.body ?? "").trim().slice(0, 1000);
  const room = String(b.room || "general").slice(0, 40);
  if (!senderName || !regNo || !text) return NextResponse.json({ error: "Missing fields" }, { status: 400 });
  const [row] = await db
    .insert(messages)
    .values({
      room,
      senderName,
      regNo,
      body: text,
      isQuestion: Boolean(b.isQuestion),
      replyTo: b.replyTo ? Number(b.replyTo) : null,
    })
    .returning();
  return NextResponse.json(row, { status: 201 });
}
