import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { materials } from "@/db/schema";
import { ensureDb } from "@/lib/bootstrap";

export const dynamic = "force-dynamic";

export async function GET(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  await ensureDb();
  const { id } = await ctx.params;
  const numId = Number(id);
  if (!Number.isInteger(numId)) return new Response("Not found", { status: 404 });
  const [row] = await db.select().from(materials).where(eq(materials.id, numId));
  if (!row) return new Response("Not found", { status: 404 });
  await db.update(materials).set({ downloads: sql`${materials.downloads} + 1` }).where(eq(materials.id, row.id));
  const buf = Buffer.from(row.data, "base64");
  const safeName = `${row.fileName.replace(/\.pdf$/i, "").replace(/[^A-Za-z0-9._-]+/g, "_")}.pdf`;
  return new Response(new Uint8Array(buf), {
    headers: {
      "Content-Type": "application/pdf",
      "Content-Length": String(buf.length),
      "Content-Disposition": `attachment; filename="${safeName}"; filename*=UTF-8''${encodeURIComponent(safeName)}`,
      "Content-Transfer-Encoding": "binary",
      "X-Content-Type-Options": "nosniff",
      "Cache-Control": "private, max-age=0, must-revalidate",
    },
  });
}
