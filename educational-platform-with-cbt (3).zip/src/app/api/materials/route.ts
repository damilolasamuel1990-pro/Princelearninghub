import { NextResponse } from "next/server";
import { desc } from "drizzle-orm";
import { db } from "@/db";
import { materials } from "@/db/schema";
import { ensureDb } from "@/lib/bootstrap";
import { isAdmin } from "@/lib/admin";

export const dynamic = "force-dynamic";

export async function GET() {
  await ensureDb();
  const rows = await db
    .select({
      id: materials.id,
      title: materials.title,
      courseCode: materials.courseCode,
      courseTitle: materials.courseTitle,
      category: materials.category,
      department: materials.department,
      level: materials.level,
      description: materials.description,
      fileName: materials.fileName,
      mimeType: materials.mimeType,
      sizeBytes: materials.sizeBytes,
      downloads: materials.downloads,
      createdAt: materials.createdAt,
    })
    .from(materials)
    .orderBy(desc(materials.createdAt), materials.id);
  return NextResponse.json(rows);
}

export async function POST(req: Request) {
  if (!isAdmin(req)) return NextResponse.json({ error: "Invalid admin code" }, { status: 401 });
  await ensureDb();
  const form = await req.formData();
  const file = form.get("file");
  const title = String(form.get("title") ?? "").trim();
  const courseCode = String(form.get("courseCode") ?? "").trim().toUpperCase();
  const courseTitle = String(form.get("courseTitle") ?? "").trim();
  const category = String(form.get("category") ?? "ALL");
  const department = String(form.get("department") ?? "ALL");
  const level = String(form.get("level") ?? "All Levels");
  const description = String(form.get("description") ?? "").trim();

  if (!(file instanceof File) || !title || !courseCode) {
    return NextResponse.json({ error: "Title, course code and a PDF file are required" }, { status: 400 });
  }
  if (file.size > 10 * 1024 * 1024) return NextResponse.json({ error: "PDF must be under 10 MB" }, { status: 400 });

  const buf = Buffer.from(await file.arrayBuffer());
  const isPdf = buf.subarray(0, 5).toString("latin1") === "%PDF-";
  if (!isPdf) return NextResponse.json({ error: "Only PDF files can be uploaded" }, { status: 400 });

  const fileName = file.name.toLowerCase().endsWith(".pdf") ? file.name : `${file.name}.pdf`;
  const [row] = await db
    .insert(materials)
    .values({
      title,
      courseCode,
      courseTitle: courseTitle || courseCode,
      category,
      department,
      level,
      description,
      fileName,
      mimeType: "application/pdf",
      data: buf.toString("base64"),
      sizeBytes: buf.length,
    })
    .returning({ id: materials.id });
  return NextResponse.json(row, { status: 201 });
}
