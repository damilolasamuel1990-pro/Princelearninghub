import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { questions, tests } from "@/db/schema";
import { ensureDb } from "@/lib/bootstrap";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  await ensureDb();
  const testId = Number(new URL(req.url).searchParams.get("testId"));
  if (!Number.isInteger(testId) || testId <= 0) return NextResponse.json({ error: "testId is required" }, { status: 400 });

  const [test] = await db.select().from(tests).where(eq(tests.id, testId));
  if (!test) return NextResponse.json({ error: "Test not found" }, { status: 404 });

  const rows = await db
    .select({ id: questions.id, question: questions.question, options: questions.options })
    .from(questions)
    .where(eq(questions.testId, testId));

  // Shuffle question order — correct answers are never sent to the browser.
  for (let i = rows.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [rows[i], rows[j]] = [rows[j], rows[i]];
  }
  return NextResponse.json({ test, questions: rows });
}
