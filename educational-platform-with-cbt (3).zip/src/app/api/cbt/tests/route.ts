import { NextResponse } from "next/server";
import { and, asc, eq, inArray, like, sql } from "drizzle-orm";
import { db } from "@/db";
import { questions, tests } from "@/db/schema";
import { ensureDb } from "@/lib/bootstrap";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  await ensureDb();
  const url = new URL(req.url);
  const category = url.searchParams.get("category");
  const department = url.searchParams.get("department");
  const level = url.searchParams.get("level");

  const where = [];
  if (category) where.push(eq(tests.category, category));
  if (department) where.push(inArray(tests.department, [department, "ALL"]));
  if (level) where.push(like(tests.levels, `%|${level.replace(/[%_|]/g, "")}|%`));

  const rows = await db
    .select({
      id: tests.id,
      code: tests.code,
      title: tests.title,
      category: tests.category,
      department: tests.department,
      level: tests.level,
      semester: tests.semester,
      durationMin: tests.durationMin,
      description: tests.description,
    })
    .from(tests)
    .where(where.length ? and(...where) : undefined)
    .orderBy(asc(tests.sort));

  const counts = await db
    .select({ testId: questions.testId, n: sql<number>`count(*)::int` })
    .from(questions)
    .groupBy(questions.testId);
  const byTest = new Map(counts.map((c) => [c.testId, c.n]));
  return NextResponse.json(rows.map((r) => ({ ...r, questionCount: byTest.get(r.id) ?? 0 })));
}
