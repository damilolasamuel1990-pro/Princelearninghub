import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { questions, results, tests } from "@/db/schema";
import { ensureDb } from "@/lib/bootstrap";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  await ensureDb();
  const body = await req.json();
  const studentName = String(body.name ?? "").trim().slice(0, 80);
  const regNo = String(body.regNo ?? "").trim().toUpperCase().slice(0, 40);
  const testId = Number(body.testId);
  const rawAnswers = (body.answers ?? {}) as Record<string, unknown>;
  if (!studentName || !regNo || !Number.isInteger(testId)) {
    return NextResponse.json({ error: "Name, registration number and test are required" }, { status: 400 });
  }

  const [test] = await db.select().from(tests).where(eq(tests.id, testId));
  if (!test) return NextResponse.json({ error: "Test not found" }, { status: 404 });
  const qs = await db.select().from(questions).where(eq(questions.testId, testId));
  if (qs.length === 0) return NextResponse.json({ error: "This test has no questions" }, { status: 400 });

  const answers: Record<string, number> = {};
  let score = 0;
  for (const q of qs) {
    const a = rawAnswers[String(q.id)];
    if (typeof a === "number" && Number.isInteger(a) && a >= 0 && a < q.options.length) {
      answers[String(q.id)] = a;
      if (a === q.answerIndex) score++;
    }
  }
  const total = qs.length;
  const durationSec = test.durationMin * 60;
  const timeTaken = Math.max(0, Math.min(durationSec, Math.round(Number(body.timeTaken) || 0)));

  const [row] = await db
    .insert(results)
    .values({
      studentName,
      regNo,
      testId,
      courseCode: test.code,
      testTitle: test.title,
      category: test.category,
      department: test.department,
      level: test.level,
      score,
      total,
      percentage: Math.round((score / total) * 100),
      timeTaken,
      durationSec,
      answers,
    })
    .returning({ id: results.id });

  return NextResponse.json({ id: row.id, score, total });
}
