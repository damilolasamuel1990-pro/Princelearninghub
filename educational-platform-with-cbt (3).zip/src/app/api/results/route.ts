import { NextResponse } from "next/server";
import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { results } from "@/db/schema";
import { ensureDb } from "@/lib/bootstrap";

export const dynamic = "force-dynamic";

const cols = {
  id: results.id,
  studentName: results.studentName,
  regNo: results.regNo,
  testId: results.testId,
  courseCode: results.courseCode,
  testTitle: results.testTitle,
  category: results.category,
  department: results.department,
  level: results.level,
  score: results.score,
  total: results.total,
  percentage: results.percentage,
  timeTaken: results.timeTaken,
  durationSec: results.durationSec,
  createdAt: results.createdAt,
};

export async function GET(req: Request) {
  await ensureDb();
  const url = new URL(req.url);
  const regNo = url.searchParams.get("regNo")?.trim().toUpperCase();
  const category = url.searchParams.get("category");

  const mine = regNo ? await db.select(cols).from(results).where(eq(results.regNo, regNo)).orderBy(desc(results.createdAt)) : [];
  const top = await db
    .select(cols)
    .from(results)
    .where(category ? and(eq(results.category, category)) : undefined)
    .orderBy(desc(results.percentage), results.timeTaken)
    .limit(10);
  return NextResponse.json({ mine, top });
}
