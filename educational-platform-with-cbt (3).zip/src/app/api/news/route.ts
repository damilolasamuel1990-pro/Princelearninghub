import { NextResponse } from "next/server";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { news } from "@/db/schema";
import { ensureDb } from "@/lib/bootstrap";
import { isAdmin } from "@/lib/admin";

export const dynamic = "force-dynamic";

export async function GET() {
  await ensureDb();
  const rows = await db.select().from(news).orderBy(desc(news.pinned), desc(news.createdAt));
  return NextResponse.json(rows);
}

export async function POST(req: Request) {
  if (!isAdmin(req)) return NextResponse.json({ error: "Invalid admin code" }, { status: 401 });
  await ensureDb();
  const body = await req.json();
  const title = String(body.title ?? "").trim();
  const text = String(body.body ?? "").trim();
  if (!title || !text) return NextResponse.json({ error: "Title and body are required" }, { status: 400 });
  const [row] = await db
    .insert(news)
    .values({ title, body: text, category: String(body.category || "General"), pinned: Boolean(body.pinned) })
    .returning();
  return NextResponse.json(row, { status: 201 });
}

export async function DELETE(req: Request) {
  if (!isAdmin(req)) return NextResponse.json({ error: "Invalid admin code" }, { status: 401 });
  const id = Number(new URL(req.url).searchParams.get("id"));
  if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });
  await db.delete(news).where(eq(news.id, id));
  return NextResponse.json({ ok: true });
}
