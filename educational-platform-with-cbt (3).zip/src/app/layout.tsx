import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { StudentProvider } from "@/components/StudentProvider";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import WhatsAppFloat from "@/components/WhatsApp";

export const metadata: Metadata = {
  title: "Prince Learning Hub — Online Lectures, Materials & CBT",
  description: "Download course materials, attend online lectures, write CBT tests, view results and chat with tutors at Prince Learning Hub.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
        {/* eslint-disable-next-line @next/next/no-page-custom-font */}
        <link
          rel="stylesheet"
          href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,500;9..144,600&family=Inter:wght@400;500;600;700&display=swap"
        />
      </head>
      <body className="flex min-h-screen flex-col bg-ivory font-sans text-ink-900 antialiased">
        <StudentProvider>
          <Navbar />
          <main className="flex-1">{children}</main>
          <Footer />
          <WhatsAppFloat />
        </StudentProvider>
      </body>
    </html>
  );
}
