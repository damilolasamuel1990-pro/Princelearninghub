"use client";

import { useState } from "react";
import { Hash, HelpCircle } from "lucide-react";
import ChatBox from "@/components/ChatBox";
import PageHeader from "@/components/PageHeader";
import { CHAT_ROOMS } from "@/lib/constants";

export default function ChatPage() {
  const [room, setRoom] = useState("general");
  const current = CHAT_ROOMS.find((r) => r.id === room)!;
  return (
    <div>
      <PageHeader
        eyebrow="Student Community"
        title="Discussions"
        subtitle="Ask tutors questions, share ideas and study with classmates in course discussion rooms."
        image="/images/discussion.jpg"
      />
      <div className="mx-auto grid max-w-7xl gap-8 px-6 py-12 lg:grid-cols-[280px_1fr]">
        <aside className="space-y-6">
          <div className="overflow-hidden rounded-md border border-stone-200 bg-white">
            <h3 className="border-b border-stone-200 px-5 py-4 text-[11px] font-semibold uppercase tracking-[0.25em] text-ink-400">Rooms</h3>
            <div className="flex gap-1 overflow-x-auto p-2 lg:flex-col">
              {CHAT_ROOMS.map((r) => (
                <button
                  key={r.id}
                  onClick={() => setRoom(r.id)}
                  className={`flex shrink-0 items-center gap-3 rounded-sm px-3 py-3 text-left transition ${
                    room === r.id ? "bg-ink-900 text-white" : "text-ink-700 hover:bg-stone-50"
                  }`}
                >
                  <Hash className={`h-4 w-4 ${room === r.id ? "text-gold-300" : "text-ink-300"}`} />
                  <span>
                    <span className="block text-sm font-semibold">{r.name}</span>
                    <span className={`block text-xs ${room === r.id ? "text-ink-300" : "text-ink-400"}`}>{r.desc}</span>
                  </span>
                </button>
              ))}
            </div>
          </div>
          <div className="hidden rounded-md border border-gold-200 bg-gold-50 p-5 text-sm leading-relaxed text-ink-700 lg:block">
            <p className="flex items-center gap-2 font-serif text-base text-ink-950">
              <HelpCircle className="h-4 w-4 text-gold-600" /> Asking a question?
            </p>
            <p className="mt-2">
              Click <b>Ask</b> before sending so tutors can find your message. Use <b>Questions only</b> to see just questions and their answers.
            </p>
          </div>
        </aside>
        <ChatBox room={room} title={current.name} subtitle={current.desc} heightClass="h-[62vh]" />
      </div>
    </div>
  );
}
