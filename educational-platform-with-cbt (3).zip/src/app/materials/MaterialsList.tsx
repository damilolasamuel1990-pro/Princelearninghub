"use client";

import { useEffect, useMemo, useState } from "react";
import { Download, FileText, Search } from "lucide-react";
import { formatBytes, materialImage } from "@/lib/constants";
import { CATEGORIES, audienceLabel, getCategory } from "@/lib/academics";
import { useStudent } from "@/components/StudentProvider";
import DownloadLink from "@/components/DownloadLink";

type Mat = {
  id: number;
  title: string;
  courseCode: string;
  courseTitle: string;
  category: string;
  department: string;
  level: string;
  description: string;
  fileName: string;
  mimeType: string;
  sizeBytes: number;
  downloads: number;
  createdAt: string;
};

export default function MaterialsList() {
  const { student, ready } = useStudent();
  const [items, setItems] = useState<Mat[] | null>(null);
  const [q, setQ] = useState("");
  const [category, setCategory] = useState("ALL");
  const [department, setDepartment] = useState("ALL");

  const load = () =>
    fetch("/api/materials", { cache: "no-store" })
      .then((r) => r.json())
      .then(setItems)
      .catch(() => setItems([]));

  useEffect(() => {
    load();
  }, []);

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    if (ready && student) setCategory(student.category);
  }, [ready, student]);

  const cat = getCategory(category);

  const filtered = useMemo(() => {
    if (!items) return [];
    const s = q.toLowerCase();
    return items.filter(
      (m) =>
        (category === "ALL" || m.category === category || m.category === "ALL") &&
        (department === "ALL" || m.department === department || m.department === "ALL") &&
        (!s ||
          m.title.toLowerCase().includes(s) ||
          m.description.toLowerCase().includes(s) ||
          m.courseCode.toLowerCase().includes(s) ||
          m.level.toLowerCase().includes(s)),
    );
  }, [items, q, category, department]);

  return (
    <div className="mx-auto max-w-7xl px-6 py-14">
      <div className="flex flex-col gap-6 border-b border-stone-200 pb-6 lg:flex-row lg:items-center lg:justify-between">
        <div className="flex flex-wrap gap-x-7 gap-y-3">
          {[{ id: "ALL", name: "All Materials" }, ...CATEGORIES].map((c) => (
            <button
              key={c.id}
              onClick={() => {
                setCategory(c.id);
                setDepartment("ALL");
              }}
              className={`relative pb-2 text-sm font-medium transition ${category === c.id ? "text-ink-950" : "text-ink-400 hover:text-ink-800"}`}
            >
              {c.name}
              {category === c.id && <span className="absolute bottom-0 left-0 right-0 h-[2px] bg-gold-500" />}
            </button>
          ))}
        </div>
        <div className="relative w-full lg:w-80">
          <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-300" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search by title, code or level"
            className="w-full rounded-sm border border-stone-300 bg-white py-3 pl-10 pr-4 text-sm outline-none focus:border-ink-700 focus:ring-4 focus:ring-ink-100"
          />
        </div>
      </div>

      {cat && cat.departments.length > 1 && (
        <div className="mt-5 flex flex-wrap gap-2">
          {[{ id: "ALL", name: "All departments" }, ...cat.departments].map((d) => (
            <button
              key={d.id}
              onClick={() => setDepartment(d.id)}
              className={`rounded-sm border px-3 py-1.5 text-xs font-semibold transition ${
                department === d.id ? "border-ink-900 bg-ink-900 text-white" : "border-stone-300 bg-white text-ink-600 hover:border-ink-400"
              }`}
            >
              {d.name}
            </button>
          ))}
        </div>
      )}

      <p className="mt-6 text-sm text-ink-400">
        {items ? `${filtered.length} PDF document${filtered.length === 1 ? "" : "s"}` : "Loading…"}
      </p>

      {items === null ? (
        <div className="mt-6 grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {[0, 1, 2].map((i) => (
            <div key={i} className="h-96 animate-pulse rounded-md bg-stone-200" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <p className="py-20 text-center text-ink-400">No materials match your selection yet.</p>
      ) : (
        <div className="mt-6 grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((m) => (
            <article key={m.id} className="group relative flex flex-col overflow-hidden rounded-md border border-stone-200 bg-white transition hover:shadow-lg">
              <DownloadLink
                href={`/api/materials/${m.id}/download`}
                fileName={m.fileName.endsWith(".pdf") ? m.fileName : `${m.fileName}.pdf`}
                ariaLabel={`Download ${m.title} (PDF)`}
                onStarted={() => setTimeout(load, 2500)}
                className="absolute inset-0 z-10 cursor-pointer"
              >
                <span className="sr-only">Download {m.title}</span>
              </DownloadLink>
              <div className="relative aspect-[16/9] overflow-hidden bg-ink-900">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={materialImage(m)} alt="" className="h-full w-full object-cover opacity-90 transition duration-700 group-hover:scale-105" />
                <div className="absolute inset-0 bg-gradient-to-t from-ink-950/75 to-transparent" />
                <span className="absolute bottom-4 left-4 rounded-sm bg-paper px-2.5 py-1 text-[11px] font-bold tracking-wider text-ink-900">{m.courseCode}</span>
                <span className="absolute right-4 top-4 flex items-center gap-1 rounded-sm bg-rose-700 px-2 py-1 text-[10px] font-bold tracking-wider text-white">
                  <FileText className="h-3 w-3" /> PDF
                </span>
              </div>
              <div className="flex flex-1 flex-col p-6">
                <p className="text-[10px] font-semibold uppercase tracking-[0.18em] text-gold-600">
                  {m.category === "ALL" ? "All students" : audienceLabel(m.category, m.department, m.level)}
                </p>
                <h3 className="mt-2 font-serif text-xl leading-snug text-ink-950">{m.title}</h3>
                <p className="mt-3 flex-1 text-sm leading-relaxed text-ink-500">{m.description}</p>
                <div className="mt-6 flex items-center gap-4 border-t border-stone-100 pt-4 text-xs text-ink-400">
                  <span className="flex items-center gap-1.5">
                    <FileText className="h-3.5 w-3.5 text-rose-700" /> PDF · {formatBytes(m.sizeBytes)}
                  </span>
                  <span className="ml-auto">{m.downloads} downloads</span>
                </div>
                <DownloadLink
                  href={`/api/materials/${m.id}/download`}
                  fileName={m.fileName.endsWith(".pdf") ? m.fileName : `${m.fileName}.pdf`}
                  onStarted={() => setTimeout(load, 2500)}
                  className="mt-5 flex items-center justify-center gap-2 rounded-sm bg-ink-900 py-3 text-sm font-semibold tracking-wide text-white transition hover:bg-ink-800"
                >
                  <Download className="h-4 w-4" /> Download PDF
                </DownloadLink>
              </div>
            </article>
          ))}
        </div>
      )}

    </div>
  );
}
