import PageHeader from "@/components/PageHeader";
import MaterialsList from "./MaterialsList";

export default function MaterialsPage() {
  return (
    <div>
      <PageHeader
        eyebrow="Library"
        title="Course Materials"
        subtitle="Download lecture notes, handouts and study guides prepared by your lecturers."
        image="/images/library.jpg"
      />
      <MaterialsList />
    </div>
  );
}
