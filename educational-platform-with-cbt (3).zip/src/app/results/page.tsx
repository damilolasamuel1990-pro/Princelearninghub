"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { ArrowRight, Award, BarChart3, ClipboardList, Lock, Search } from "lucide-react";
import PageHeader from "@/components/PageHeader";
import { useStudent } from "@/components/StudentProvider";
import { formatDuration, grade } from "@/lib/constants";
import { CATEGORIES } from "@/lib/academics";

type R = {
  id: number;
  studentName: string;
  regNo: string;
  courseCode: string;
  testTitle: string;
  category: string;
  level: string;
  score: number;
  total: number;
  percentage: number;
  timeTaken: number;
  createdAt: string;
};

export default function ResultsPage() {
  const { student, ready, openSignIn } = useStudent();
  const [lookup, setLookup] = useState("");
  const [data, setData] = useState<{ mine: R[]; top: R[] } | null>(null);
  const [query, setQuery] = useState<string | null>(null);
  const [board, setBoard] = useState<string>("");

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    if (ready && student && query === null) setQuery(student.regNo);
  }, [ready, student, query]);

  useEffect(() => {
    if (!ready) return;
    const p = new URLSearchParams();
    if (query) p.set("regNo", query);
    if (board) p.set("category", board);
    fetch(`/api/results?${p}`, { cache: "no-store" })
      .then((r) => r.json())
      .then(setData)
      .catch(() => setData({ mine: [], top: [] }));
  }, [query, ready, board]);

  const mine = data?.mine ?? [];
  const best = mine.length ? Math.max(...mine.map((r) => r.percentage)) : 0;
  const avg = mine.length ? Math.round(mine.reduce((a, r) => a + r.percentage, 0) / mine.length) : 0;

  return (
    <div>
      <PageHeader
        eyebrow="Academic Records"
        title="Test Results"
        subtitle="Check your CBT scores, review corrections and see where you stand on the leaderboard."
        image="/images/computers-library.jpg"
      />
      <div className="mx-auto grid max-w-7xl gap-10 px-6 py-14 lg:grid-cols-12">
        <div className="lg:col-span-8">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (lookup.trim()) setQuery(lookup.trim().toUpperCase());
            }}
            className="flex gap-3"
          >
            <div className="relative flex-1">
              <Search className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-300" />
              <input
                value={lookup}
                onChange={(e) => setLookup(e.target.value)}
                placeholder="Enter your matric / admission number"
                className="w-full rounded-sm border border-stone-300 bg-white py-3.5 pl-11 pr-4 text-sm uppercase outline-none placeholder:normal-case focus:border-ink-700 focus:ring-4 focus:ring-ink-100"
              />
            </div>
            <button className="rounded-sm bg-ink-900 px-6 text-sm font-semibold text-white hover:bg-ink-800">Check Result</button>
          </form>

          {!query ? (
            <div className="mt-10 rounded-md border border-dashed border-stone-300 bg-white p-14 text-center">
              <Lock className="mx-auto h-8 w-8 text-ink-300" strokeWidth={1.5} />
              <p className="mt-4 font-serif text-xl text-ink-950">Log in to view your results</p>
              <p className="mt-1 text-sm text-ink-500">Or look up results with a registration number above.</p>
              <button onClick={openSignIn} className="mt-6 rounded-sm bg-ink-900 px-6 py-3 text-sm font-semibold text-white hover:bg-ink-800">
                Student Login
              </button>
            </div>
          ) : (
            <>
              <div className="mt-10 flex items-end justify-between border-b border-stone-200 pb-4">
                <div>
                  <p className="text-[11px] font-semibold uppercase tracking-[0.25em] text-ink-400">Results for</p>
                  <h2 className="mt-1 font-serif text-2xl text-ink-950">{query}</h2>
                </div>
              </div>
              <div className="mt-6 grid grid-cols-3 gap-4">
                {[
                  [ClipboardList, mine.length, "Tests taken"],
                  [Award, `${best}%`, "Best score"],
                  [BarChart3, `${avg}%`, "Average"],
                ].map(([Icon, v, l]) => {
                  const I = Icon as typeof Award;
                  return (
                    <div key={l as string} className="rounded-md border border-stone-200 bg-white p-5">
                      <I className="h-5 w-5 text-gold-600" strokeWidth={1.6} />
                      <p className="mt-3 font-serif text-3xl text-ink-950">{v as string}</p>
                      <p className="text-xs uppercase tracking-wider text-ink-400">{l as string}</p>
                    </div>
                  );
                })}
              </div>

              {data === null ? (
                <div className="mt-6 h-48 animate-pulse rounded-md bg-stone-200" />
              ) : mine.length === 0 ? (
                <div className="mt-6 rounded-md border border-stone-200 bg-white p-12 text-center">
                  <p className="text-ink-500">No results recorded yet.</p>
                  <Link href="/cbt" className="mt-5 inline-flex items-center gap-2 rounded-sm bg-gold-400 px-6 py-3 text-sm font-semibold text-ink-950 hover:bg-gold-300">
                    Take a CBT test <ArrowRight className="h-4 w-4" />
                  </Link>
                </div>
              ) : (
                <div className="mt-6 overflow-hidden rounded-md border border-stone-200 bg-white">
                  <table className="w-full text-sm">
                    <thead className="border-b border-stone-200 bg-paper text-left text-[11px] uppercase tracking-[0.15em] text-ink-400">
                      <tr>
                        <th className="px-5 py-4 font-semibold">Test</th>
                        <th className="px-5 py-4 font-semibold">Score</th>
                        <th className="hidden px-5 py-4 font-semibold sm:table-cell">Duration</th>
                        <th className="hidden px-5 py-4 font-semibold md:table-cell">Date</th>
                        <th className="px-5 py-4 font-semibold">Grade</th>
                        <th className="px-5 py-4" />
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-100">
                      {mine.map((r) => {
                        const g = grade(r.percentage);
                        return (
                          <tr key={r.id} className="hover:bg-paper">
                            <td className="px-5 py-4">
                              <p className="font-semibold text-ink-900">{r.courseCode} · {r.testTitle}</p>
                              <p className="text-xs text-ink-400">{r.level}</p>
                            </td>
                            <td className="px-5 py-4 text-ink-700">
                              {r.score}/{r.total} <span className="text-ink-400">({r.percentage}%)</span>
                            </td>
                            <td className="hidden px-5 py-4 text-ink-500 sm:table-cell">{formatDuration(r.timeTaken)}</td>
                            <td className="hidden px-5 py-4 text-ink-500 md:table-cell">
                              {new Date(r.createdAt).toLocaleString("en-GB", { dateStyle: "medium", timeStyle: "short" })}
                            </td>
                            <td className={`px-5 py-4 font-serif text-xl ${g.color}`}>{g.letter}</td>
                            <td className="px-5 py-4 text-right">
                              <Link href={`/results/${r.id}`} className="inline-flex items-center gap-1 text-sm font-semibold text-ink-900 hover:text-gold-700">
                                View <ArrowRight className="h-3.5 w-3.5" />
                              </Link>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </>
          )}
        </div>

        <aside className="lg:col-span-4">
          <div className="overflow-hidden rounded-md border border-stone-200 bg-white">
            <div className="relative overflow-hidden bg-ink-950 px-6 py-6">
              <div className="absolute inset-0 bg-cover bg-center opacity-20" style={{ backgroundImage: "url(/images/graduation.jpg)" }} />
              <p className="relative text-[11px] font-semibold uppercase tracking-[0.25em] text-gold-300">Hall of Fame</p>
              <h3 className="relative mt-1 font-serif text-2xl text-white">Top 10 Leaderboard</h3>
            </div>
            <div className="flex flex-wrap gap-1 border-b border-stone-200 p-3">
              {[{ id: "", name: "All" }, ...CATEGORIES.map((c) => ({ id: c.id, name: c.name.replace(" School", "") }))].map((c) => (
                <button
                  key={c.id}
                  onClick={() => setBoard(c.id)}
                  className={`rounded-sm px-2.5 py-1.5 text-xs font-semibold transition ${board === c.id ? "bg-ink-900 text-white" : "text-ink-500 hover:bg-stone-100"}`}
                >
                  {c.name}
                </button>
              ))}
            </div>
            <ol className="divide-y divide-stone-100">
              {(data?.top ?? []).length === 0 && <li className="p-6 text-sm text-ink-400">No scores yet. Be the first.</li>}
              {(data?.top ?? []).map((r, i) => (
                <li key={r.id} className="flex items-center gap-4 px-6 py-4">
                  <span
                    className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full font-serif text-sm ${
                      i === 0 ? "bg-gold-400 text-ink-950" : i < 3 ? "bg-ink-900 text-gold-300" : "bg-stone-100 text-ink-500"
                    }`}
                  >
                    {i + 1}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-medium text-ink-900">{r.studentName}</p>
                    <p className="text-xs text-ink-400">
                      {r.courseCode} · {r.level} · {formatDuration(r.timeTaken)}
                    </p>
                  </div>
                  <span className="font-serif text-lg text-ink-950">{r.percentage}%</span>
                </li>
              ))}
            </ol>
          </div>
        </aside>
      </div>
    </div>
  );
}
