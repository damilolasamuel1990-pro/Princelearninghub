"use client";

import { Printer } from "lucide-react";

export default function PrintButton() {
  return (
    <button
      onClick={() => window.print()}
      className="inline-flex items-center gap-2 rounded-sm border border-stone-300 px-5 py-3 text-sm font-semibold text-ink-700 hover:bg-stone-50"
    >
      <Printer className="h-4 w-4" /> Print Result
    </button>
  );
}
