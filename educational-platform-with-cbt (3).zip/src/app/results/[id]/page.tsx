import Link from "next/link";
import { notFound } from "next/navigation";
import { asc, eq } from "drizzle-orm";
import { CheckCircle2, Lightbulb, MinusCircle, RotateCcw, XCircle } from "lucide-react";
import { db } from "@/db";
import { questions, results } from "@/db/schema";
import { ensureDb } from "@/lib/bootstrap";
import { formatDuration, grade } from "@/lib/constants";
import { audienceLabel } from "@/lib/academics";
import { Crest } from "@/components/Logo";
import PrintButton from "./PrintButton";

export const dynamic = "force-dynamic";

const LETTERS = ["A", "B", "C", "D", "E"];

export default async function ResultDetail({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ new?: string }>;
}) {
  await ensureDb();
  const { id } = await params;
  const { new: isNew } = await searchParams;
  const numId = Number(id);
  if (!Number.isInteger(numId)) notFound();
  const [r] = await db.select().from(results).where(eq(results.id, numId));
  if (!r) notFound();
  const qs = await db.select().from(questions).where(eq(questions.testId, r.testId)).orderBy(asc(questions.id));
  const g = grade(r.percentage);
  const unanswered = qs.filter((q) => r.answers[String(q.id)] === undefined).length;
  const wrong = r.total - r.score - unanswered;
  const circ = 2 * Math.PI * 54;

  return (
    <div className="mx-auto max-w-5xl px-6 py-12">
      {isNew && (
        <div className="no-print mb-8 flex items-center gap-3 rounded-md border border-emerald-200 bg-emerald-50 px-5 py-4 text-sm text-emerald-900">
          <CheckCircle2 className="h-5 w-5 text-emerald-700" /> Your test has been submitted and marked.
        </div>
      )}

      <div className="overflow-hidden rounded-md border border-stone-200 bg-white shadow-sm">
        <div className="relative overflow-hidden bg-ink-950 p-8 sm:p-10">
          <div className="absolute inset-0 bg-cover bg-center opacity-15" style={{ backgroundImage: "url(/images/graduation.jpg)" }} />
          <div className="relative flex flex-wrap items-center justify-between gap-8">
            <div className="flex items-start gap-5">
              <Crest tone="light" className="hidden h-20 w-20 sm:block" />
              <div>
                <p className="text-[11px] font-semibold uppercase tracking-[0.3em] text-gold-300">Statement of Result · CBT Test</p>
                <h1 className="mt-2 font-serif text-3xl text-white sm:text-4xl">{r.studentName}</h1>
                <p className="mt-1 text-ink-300">{r.regNo}</p>
                <p className="mt-3 font-serif text-lg text-gold-200">{r.courseCode} — {r.testTitle}</p>
                <p className="text-sm text-ink-300">{audienceLabel(r.category, r.department, r.level)}</p>
                <p className="mt-3 text-sm text-ink-400">{r.createdAt.toLocaleString("en-GB", { dateStyle: "full", timeStyle: "short" })}</p>
              </div>
            </div>
            <div className="relative h-36 w-36">
              <svg viewBox="0 0 120 120" className="h-full w-full -rotate-90">
                <circle cx="60" cy="60" r="54" fill="none" stroke="rgba(255,255,255,0.1)" strokeWidth="6" />
                <circle
                  cx="60"
                  cy="60"
                  r="54"
                  fill="none"
                  stroke="#c9a45a"
                  strokeWidth="6"
                  strokeLinecap="round"
                  strokeDasharray={circ}
                  strokeDashoffset={circ * (1 - r.percentage / 100)}
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="font-serif text-4xl text-white">{r.percentage}%</span>
                <span className="text-xs text-ink-300">
                  {r.score} of {r.total}
                </span>
              </div>
            </div>
          </div>
        </div>
        <div className="grid grid-cols-2 divide-x divide-y divide-stone-100 sm:grid-cols-5 sm:divide-y-0">
          {[
            ["Grade", g.letter, g.label, g.color],
            ["Correct", r.score, "answers", "text-emerald-700"],
            ["Incorrect", wrong, "answers", "text-rose-700"],
            ["Skipped", unanswered, "questions", "text-ink-400"],
            ["Time Used", formatDuration(r.timeTaken), `of ${formatDuration(r.durationSec)}`, "text-ink-900"],
          ].map(([l, v, sub, color], i) => (
            <div key={i} className="p-6 text-center">
              <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-ink-400">{l}</p>
              <p className={`mt-2 font-serif text-3xl ${color}`}>{v}</p>
              <p className="text-xs text-ink-400">{sub}</p>
            </div>
          ))}
        </div>
        <div className="no-print flex flex-wrap gap-3 border-t border-stone-100 p-6">
          <Link href="/cbt" className="inline-flex items-center gap-2 rounded-sm bg-ink-900 px-5 py-3 text-sm font-semibold text-white hover:bg-ink-800">
            <RotateCcw className="h-4 w-4" /> Retake Test
          </Link>
          <Link href="/results" className="rounded-sm border border-stone-300 px-5 py-3 text-sm font-semibold text-ink-700 hover:bg-stone-50">
            All My Results
          </Link>
          <PrintButton />
        </div>
      </div>

      <div className="mb-6 mt-14 border-b border-stone-200 pb-4">
        <p className="text-[11px] font-semibold uppercase tracking-[0.3em] text-gold-600">Review</p>
        <h2 className="mt-1 font-serif text-3xl text-ink-950">Corrections</h2>
      </div>
      <div className="space-y-5">
        {qs.map((q, i) => {
          const chosen = r.answers[String(q.id)];
          const correct = chosen === q.answerIndex;
          const status =
            chosen === undefined
              ? { icon: MinusCircle, label: "Skipped", cls: "text-ink-400" }
              : correct
                ? { icon: CheckCircle2, label: "Correct", cls: "text-emerald-700" }
                : { icon: XCircle, label: "Incorrect", cls: "text-rose-700" };
          return (
            <div key={q.id} className="rounded-md border border-stone-200 bg-white p-7">
              <div className="flex items-start justify-between gap-4">
                <h3 className="font-serif text-lg leading-relaxed text-ink-950">
                  <span className="mr-2 text-gold-600">{String(i + 1).padStart(2, "0")}.</span>
                  {q.question}
                </h3>
                <span className={`flex shrink-0 items-center gap-1.5 text-xs font-semibold uppercase tracking-wider ${status.cls}`}>
                  <status.icon className="h-4 w-4" /> {status.label}
                </span>
              </div>
              <div className="mt-5 grid gap-2 sm:grid-cols-2">
                {q.options.map((opt, oi) => {
                  const isAns = oi === q.answerIndex;
                  const isChosen = oi === chosen;
                  return (
                    <div
                      key={oi}
                      className={`flex items-center gap-3 rounded-sm border px-4 py-3 text-sm ${
                        isAns
                          ? "border-emerald-300 bg-emerald-50 font-medium text-emerald-900"
                          : isChosen
                            ? "border-rose-200 bg-rose-50 text-rose-800"
                            : "border-stone-200 text-ink-500"
                      }`}
                    >
                      <span className="font-serif">{LETTERS[oi]}.</span>
                      <span className={isChosen && !isAns ? "line-through" : ""}>{opt}</span>
                      {isAns && <CheckCircle2 className="ml-auto h-4 w-4 text-emerald-700" />}
                      {isChosen && !isAns && <span className="ml-auto text-[10px] font-semibold uppercase tracking-wider">Your answer</span>}
                    </div>
                  );
                })}
              </div>
              {q.explanation && (
                <p className="mt-4 flex gap-3 border-l-2 border-gold-400 bg-gold-50 px-4 py-3 text-sm leading-relaxed text-ink-800">
                  <Lightbulb className="mt-0.5 h-4 w-4 shrink-0 text-gold-600" />
                  <span>{q.explanation}</span>
                </p>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
