import Link from "next/link";
import { asc } from "drizzle-orm";
import { CalendarDays, Clock, PlayCircle, User } from "lucide-react";
import { db } from "@/db";
import { lectures, type Lecture } from "@/db/schema";
import { ensureDb } from "@/lib/bootstrap";
import PageHeader from "@/components/PageHeader";
import { COURSES } from "@/lib/constants";

export const dynamic = "force-dynamic";

function StatusBadge({ status }: { status: string }) {
  if (status === "live")
    return (
      <span className="flex items-center gap-1.5 rounded-sm bg-rose-700 px-2.5 py-1 text-[10px] font-bold uppercase tracking-[0.15em] text-white">
        <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-white" /> Live
      </span>
    );
  if (status === "upcoming")
    return <span className="rounded-sm bg-paper px-2.5 py-1 text-[10px] font-bold uppercase tracking-[0.15em] text-ink-900">Upcoming</span>;
  return <span className="rounded-sm bg-ink-950/80 px-2.5 py-1 text-[10px] font-bold uppercase tracking-[0.15em] text-gold-200">Recorded</span>;
}

function Card({ l }: { l: Lecture }) {
  return (
    <Link href={`/lectures/${l.id}`} className="group flex flex-col overflow-hidden rounded-md border border-stone-200 bg-white transition hover:shadow-lg">
      <div className="relative aspect-video overflow-hidden bg-ink-900">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={`https://img.youtube.com/vi/${l.videoId}/hqdefault.jpg`} alt={l.title} className="h-full w-full object-cover transition duration-700 group-hover:scale-105" />
        <div className="absolute inset-0 bg-ink-950/20 transition group-hover:bg-ink-950/40" />
        <div className="absolute left-4 top-4">
          <StatusBadge status={l.status} />
        </div>
        <PlayCircle className="absolute left-1/2 top-1/2 h-14 w-14 -translate-x-1/2 -translate-y-1/2 text-white opacity-0 transition group-hover:opacity-100" strokeWidth={1.2} />
      </div>
      <div className="flex flex-1 flex-col p-6">
        <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-gold-600">
          {l.courseCode} · {COURSES[l.courseCode] ?? ""}
        </p>
        <h3 className="mt-2 font-serif text-xl leading-snug text-ink-950 group-hover:text-gold-700">{l.title}</h3>
        <div className="mt-auto space-y-1.5 pt-5 text-sm text-ink-500">
          <p className="flex items-center gap-2"><User className="h-4 w-4 text-ink-300" /> {l.lecturer}</p>
          <p className="flex items-center gap-2">
            <CalendarDays className="h-4 w-4 text-ink-300" />
            {l.scheduledAt.toLocaleString("en-GB", { weekday: "short", day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })}
          </p>
          <p className="flex items-center gap-2"><Clock className="h-4 w-4 text-ink-300" /> {l.durationMin} minutes</p>
        </div>
      </div>
    </Link>
  );
}

export default async function LecturesPage() {
  await ensureDb();
  const all = await db.select().from(lectures).orderBy(asc(lectures.scheduledAt));
  const groups = [
    { key: "live", eyebrow: "Happening now", title: "Live Lectures", items: all.filter((l) => l.status === "live") },
    { key: "upcoming", eyebrow: "Timetable", title: "Upcoming Lectures", items: all.filter((l) => l.status === "upcoming") },
    { key: "recorded", eyebrow: "Archive", title: "Recorded Lectures", items: all.filter((l) => l.status === "recorded").reverse() },
  ];
  return (
    <div>
      <PageHeader
        eyebrow="Virtual Classroom"
        title="Online Lectures"
        subtitle="Join live classes, watch recorded sessions and ask your lecturer questions in each lecture's discussion room."
        image="/images/lecture-hall.jpg"
      />
      <div className="mx-auto max-w-7xl space-y-20 px-6 py-16">
        {groups.map((g) =>
          g.items.length ? (
            <section key={g.key}>
              <div className="mb-8 border-b border-stone-200 pb-5">
                <p className="text-[11px] font-semibold uppercase tracking-[0.3em] text-gold-600">{g.eyebrow}</p>
                <h2 className="mt-2 font-serif text-3xl text-ink-950">{g.title}</h2>
              </div>
              <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
                {g.items.map((l) => (
                  <Card key={l.id} l={l} />
                ))}
              </div>
            </section>
          ) : null,
        )}
        {all.length === 0 && <p className="text-center text-ink-400">No lectures have been scheduled yet.</p>}
      </div>
    </div>
  );
}
