import Link from "next/link";
import { notFound } from "next/navigation";
import { asc, eq } from "drizzle-orm";
import { ArrowLeft, CalendarDays, Clock, Download, User } from "lucide-react";
import { db } from "@/db";
import { lectures, materials } from "@/db/schema";
import { ensureDb } from "@/lib/bootstrap";
import ChatBox from "@/components/ChatBox";
import DownloadLink from "@/components/DownloadLink";
import { COURSES } from "@/lib/constants";

export const dynamic = "force-dynamic";

export default async function LectureRoom({ params }: { params: Promise<{ id: string }> }) {
  await ensureDb();
  const { id } = await params;
  const numId = Number(id);
  if (!Number.isInteger(numId)) notFound();
  const [l] = await db.select().from(lectures).where(eq(lectures.id, numId));
  if (!l) notFound();
  const [allMats, others] = await Promise.all([
    db
      .select({ id: materials.id, title: materials.title, fileName: materials.fileName, courseCode: materials.courseCode })
      .from(materials),
    db.select().from(lectures).orderBy(asc(lectures.scheduledAt)),
  ]);
  const norm = (s: string) => s.toUpperCase().replace(/[^A-Z0-9]/g, "");
  const mats = allMats.filter((m) => norm(m.courseCode) === norm(l.courseCode));

  const statusLabel = l.status === "live" ? "Live now" : l.status === "upcoming" ? "Upcoming" : "Recorded";

  return (
    <div>
      <div className="bg-ink-950">
        <div className="mx-auto max-w-7xl px-6 pb-10 pt-8">
          <Link href="/lectures" className="inline-flex items-center gap-2 text-sm text-ink-300 hover:text-gold-300">
            <ArrowLeft className="h-4 w-4" /> All lectures
          </Link>
          <div className="mt-6 grid gap-8 lg:grid-cols-[1fr_400px]">
            <div className="overflow-hidden rounded-md bg-black shadow-2xl ring-1 ring-white/10">
              <div className="relative aspect-video">
                <iframe
                  className="absolute inset-0 h-full w-full"
                  src={`https://www.youtube-nocookie.com/embed/${l.videoId}?rel=0&modestbranding=1`}
                  title={l.title}
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                />
              </div>
            </div>
            <div className="flex flex-col justify-center text-white">
              <div className="flex items-center gap-3 text-[11px] font-semibold uppercase tracking-[0.2em]">
                <span className={l.status === "live" ? "flex items-center gap-1.5 text-rose-400" : "text-gold-300"}>
                  {l.status === "live" && <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-rose-400" />}
                  {statusLabel}
                </span>
                <span className="text-ink-400">·</span>
                <span className="text-ink-300">{l.courseCode}</span>
              </div>
              <h1 className="mt-4 font-serif text-3xl leading-tight sm:text-4xl">{l.title}</h1>
              <p className="mt-2 text-sm text-ink-300">{COURSES[l.courseCode]}</p>
              <div className="mt-6 space-y-2.5 text-sm text-ink-200">
                <p className="flex items-center gap-3"><User className="h-4 w-4 text-gold-400" /> {l.lecturer}</p>
                <p className="flex items-center gap-3">
                  <CalendarDays className="h-4 w-4 text-gold-400" /> {l.scheduledAt.toLocaleString("en-GB", { dateStyle: "full", timeStyle: "short" })}
                </p>
                <p className="flex items-center gap-3"><Clock className="h-4 w-4 text-gold-400" /> {l.durationMin} minutes</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="mx-auto grid max-w-7xl gap-8 px-6 py-12 lg:grid-cols-[1fr_400px]">
        <div className="space-y-8">
          <section className="rounded-md border border-stone-200 bg-white p-8">
            <h2 className="font-serif text-2xl text-ink-950">About this lecture</h2>
            <p className="mt-4 leading-relaxed text-ink-600">{l.description}</p>
          </section>

          {mats.length > 0 && (
            <section className="rounded-md border border-stone-200 bg-white p-8">
              <h2 className="font-serif text-2xl text-ink-950">Lecture materials</h2>
              <ul className="mt-5 divide-y divide-stone-100">
                {mats.map((m) => (
                  <li key={m.id} className="flex items-center justify-between gap-4 py-4">
                    <div>
                      <p className="font-medium text-ink-900">{m.title}</p>
                      <p className="text-xs text-ink-400">{m.fileName}</p>
                    </div>
                    <DownloadLink
                      href={`/api/materials/${m.id}/download`}
                      fileName={`${m.title.replace(/[^A-Za-z0-9]+/g, "_")}.pdf`}
                      className="flex shrink-0 items-center gap-2 rounded-sm border border-ink-200 px-4 py-2 text-sm font-medium text-ink-800 hover:border-ink-900 hover:bg-ink-900 hover:text-white"
                    >
                      <Download className="h-4 w-4" /> Download
                    </DownloadLink>
                  </li>
                ))}
              </ul>
            </section>
          )}

          <section>
            <h2 className="mb-5 font-serif text-2xl text-ink-950">More lectures</h2>
            <div className="grid gap-6 sm:grid-cols-2">
              {others
                .filter((o) => o.id !== l.id)
                .slice(0, 4)
                .map((o) => (
                  <Link key={o.id} href={`/lectures/${o.id}`} className="group flex gap-4 rounded-md border border-stone-200 bg-white p-3 hover:shadow-md">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={`https://img.youtube.com/vi/${o.videoId}/mqdefault.jpg`} alt="" className="h-20 w-32 shrink-0 rounded-sm object-cover" />
                    <div className="min-w-0 py-1">
                      <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-gold-600">{o.courseCode} · {o.status}</p>
                      <p className="mt-1 line-clamp-2 font-medium leading-snug text-ink-900 group-hover:text-gold-700">{o.title}</p>
                    </div>
                  </Link>
                ))}
            </div>
          </section>
        </div>

        <div className="lg:sticky lg:top-36 lg:h-fit">
          <ChatBox room={`lecture-${l.id}`} title="Lecture Discussion" subtitle="Ask questions during the lecture" heightClass="h-[520px]" />
        </div>
      </div>
    </div>
  );
}
