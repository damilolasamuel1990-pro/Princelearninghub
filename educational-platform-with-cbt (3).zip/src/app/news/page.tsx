import { desc } from "drizzle-orm";
import { CalendarDays, Pin } from "lucide-react";
import { db } from "@/db";
import { news } from "@/db/schema";
import { ensureDb } from "@/lib/bootstrap";
import PageHeader from "@/components/PageHeader";
import { newsImage } from "@/lib/constants";

export const dynamic = "force-dynamic";

const fmt = (d: Date) => d.toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" });

export default async function NewsPage() {
  await ensureDb();
  const rows = await db.select().from(news).orderBy(desc(news.pinned), desc(news.createdAt));
  const [featured, ...rest] = rows;
  const categories = Array.from(new Set(rows.map((r) => r.category)));

  return (
    <div>
      <PageHeader
        eyebrow="News & Notices"
        title="News & Announcements"
        subtitle="Official announcements, CBT test notices, timetable changes and campus news."
        image="/images/graduation.jpg"
      />
      <div className="mx-auto max-w-7xl px-6 py-16">
        {rows.length === 0 && <p className="text-center text-ink-400">No news has been published yet.</p>}

        {featured && (
          <article className="grid overflow-hidden rounded-md border border-stone-200 bg-white lg:grid-cols-5">
            <div className="aspect-[16/10] overflow-hidden lg:col-span-3 lg:aspect-auto">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={newsImage(featured.category)} alt="" className="h-full w-full object-cover" />
            </div>
            <div className="flex flex-col p-8 lg:col-span-2 lg:p-12">
              <div className="flex items-center gap-3 text-[11px] font-semibold uppercase tracking-[0.2em]">
                <span className="text-gold-600">{featured.category}</span>
                {featured.pinned && (
                  <span className="flex items-center gap-1 text-ink-400">
                    <Pin className="h-3 w-3" /> Pinned
                  </span>
                )}
              </div>
              <h2 className="mt-4 font-serif text-3xl leading-tight text-ink-950">{featured.title}</h2>
              <p className="mt-5 whitespace-pre-line leading-relaxed text-ink-600">{featured.body}</p>
              <p className="mt-auto flex items-center gap-2 pt-8 text-sm text-ink-400">
                <CalendarDays className="h-4 w-4" /> {fmt(featured.createdAt)}
              </p>
            </div>
          </article>
        )}

        <div className="mt-16 grid gap-12 lg:grid-cols-12">
          <div className="space-y-10 lg:col-span-8">
            {rest.map((n) => (
              <article key={n.id} className="grid gap-6 border-b border-stone-200 pb-10 sm:grid-cols-[240px_1fr]">
                <div className="aspect-[4/3] overflow-hidden rounded-md">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={newsImage(n.category)} alt="" className="h-full w-full object-cover" />
                </div>
                <div>
                  <div className="flex items-center gap-3 text-[11px] font-semibold uppercase tracking-[0.2em]">
                    <span className="text-gold-600">{n.category}</span>
                    {n.pinned && <span className="text-ink-400">· Pinned</span>}
                  </div>
                  <h3 className="mt-2 font-serif text-2xl leading-snug text-ink-950">{n.title}</h3>
                  <p className="mt-3 whitespace-pre-line leading-relaxed text-ink-600">{n.body}</p>
                  <p className="mt-4 text-sm text-ink-400">{fmt(n.createdAt)}</p>
                </div>
              </article>
            ))}
          </div>
          <aside className="lg:col-span-4">
            <div className="sticky top-36 space-y-6">
              <div className="rounded-md border border-stone-200 bg-white p-6">
                <h3 className="font-serif text-xl text-ink-950">Categories</h3>
                <ul className="mt-4 divide-y divide-stone-100 text-sm">
                  {categories.map((c) => (
                    <li key={c} className="flex justify-between py-3 text-ink-700">
                      {c}
                      <span className="text-ink-400">{rows.filter((r) => r.category === c).length}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="relative overflow-hidden rounded-md bg-ink-950 p-7">
                <div className="absolute inset-0 bg-cover bg-center opacity-25" style={{ backgroundImage: "url(/images/library.jpg)" }} />
                <div className="relative">
                  <h3 className="font-serif text-xl text-white">Stay informed</h3>
                  <p className="mt-2 text-sm text-ink-200">Check this page regularly for exam timetables, lecture schedules and important notices.</p>
                </div>
              </div>
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
}
