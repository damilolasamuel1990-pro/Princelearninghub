"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { AlertTriangle, ArrowLeft, ArrowRight, Check, Clock, ListChecks, Loader2, PlayCircle, UserRound } from "lucide-react";
import { useStudent } from "@/components/StudentProvider";
import { CATEGORIES, audienceLabel, getCategory, type CategoryId } from "@/lib/academics";

type Q = { id: number; question: string; options: string[] };
type TestInfo = {
  id: number;
  code: string;
  title: string;
  category: string;
  department: string;
  level: string;
  semester?: string;
  durationMin: number;
  description: string;
  questionCount?: number;
};

function TestCard({ t, busy, loading, onStart }: { t: TestInfo; busy: boolean; loading: boolean; onStart: () => void }) {
  return (
    <article className="flex flex-col rounded-md border border-stone-200 bg-white p-6 transition hover:border-ink-300 hover:shadow-md">
      <div className="flex items-center justify-between gap-2">
        <span className="rounded-sm bg-ink-900 px-2.5 py-1 text-[11px] font-bold tracking-wider text-gold-300">{t.code}</span>
        {t.department === "ALL" ? (
          <span className="text-[10px] font-semibold uppercase tracking-wider text-ink-400">General course</span>
        ) : t.level.includes("–") ? (
          <span className="text-[10px] font-semibold uppercase tracking-wider text-ink-400">{t.level}</span>
        ) : null}
      </div>
      <h3 className="mt-4 font-serif text-xl leading-snug text-ink-950">{t.title}</h3>
      <p className="mt-2 flex-1 text-sm leading-relaxed text-ink-500">{t.description}</p>
      <div className="mt-5 flex items-center gap-5 border-t border-stone-100 pt-4 text-sm text-ink-600">
        <span className="flex items-center gap-1.5">
          <ListChecks className="h-4 w-4 text-gold-600" /> {t.questionCount} questions
        </span>
        <span className="flex items-center gap-1.5">
          <Clock className="h-4 w-4 text-gold-600" /> {t.durationMin} mins
        </span>
      </div>
      <button
        onClick={onStart}
        disabled={busy}
        className="mt-5 flex items-center justify-center gap-2 rounded-sm bg-ink-900 py-3 text-sm font-semibold tracking-wide text-white transition hover:bg-ink-800 disabled:opacity-50"
      >
        {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <PlayCircle className="h-4 w-4" />}
        Start Test
      </button>
    </article>
  );
}
type Session = { test: TestInfo; startedAt: number; durationSec: number; questions: Q[]; answers: Record<string, number>; current: number };

const SKEY = "plh-cbt-session-v2";
const LETTERS = ["A", "B", "C", "D", "E"];

export default function CbtPage() {
  const router = useRouter();
  const { student, ready, openSignIn } = useStudent();

  const [category, setCategory] = useState<CategoryId>("university");
  const [department, setDepartment] = useState("CSC");
  const [level, setLevel] = useState("100 Level");
  const [list, setList] = useState<TestInfo[] | null>(null);
  const [pending, setPending] = useState<TestInfo | null>(null);

  const [session, setSession] = useState<Session | null>(null);
  const [now, setNow] = useState(() => Date.now());
  const [confirm, setConfirm] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [loadingId, setLoadingId] = useState<number | null>(null);
  const [error, setError] = useState("");
  const submittedRef = useRef(false);

  const cat = getCategory(category)!;
  const dep = cat.departments.find((d) => d.id === department) ?? cat.departments[0];

  /* restore in-progress session */
  useEffect(() => {
    try {
      const raw = sessionStorage.getItem(SKEY);
      if (raw) {
        const s: Session = JSON.parse(raw);
        // eslint-disable-next-line react-hooks/set-state-in-effect
        if (Date.now() - s.startedAt < s.durationSec * 1000) setSession(s);
        else sessionStorage.removeItem(SKEY);
      }
    } catch {}
  }, []);

  /* default the selector to the student's own class */
  useEffect(() => {
    if (ready && student) {
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setCategory(student.category);
      setDepartment(student.department);
      setLevel(student.level);
    }
  }, [ready, student]);

  /* load tests for the selected class */
  useEffect(() => {
    const p = new URLSearchParams({ category, department: dep.id, level });
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setList(null);
    fetch(`/api/cbt/tests?${p}`, { cache: "no-store" })
      .then((r) => r.json())
      .then(setList)
      .catch(() => setList([]));
  }, [category, dep.id, level]);

  useEffect(() => {
    if (session) sessionStorage.setItem(SKEY, JSON.stringify(session));
  }, [session]);

  useEffect(() => {
    if (!session) return;
    const t = setInterval(() => setNow(Date.now()), 250);
    return () => clearInterval(t);
  }, [session]);

  const remaining = session ? Math.max(0, session.durationSec - Math.floor((now - session.startedAt) / 1000)) : 0;

  const submit = useCallback(async () => {
    if (!session || submittedRef.current) return;
    if (!student) return openSignIn();
    submittedRef.current = true;
    setSubmitting(true);
    setConfirm(false);
    try {
      const res = await fetch("/api/cbt/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: student.name,
          regNo: student.regNo,
          testId: session.test.id,
          answers: session.answers,
          timeTaken: Math.min(session.durationSec, Math.round((Date.now() - session.startedAt) / 1000)),
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Submission failed");
      sessionStorage.removeItem(SKEY);
      router.push(`/results/${data.id}?new=1`);
    } catch (e) {
      submittedRef.current = false;
      setSubmitting(false);
      setError(e instanceof Error ? e.message : "Submission failed");
    }
  }, [session, student, openSignIn, router]);

  useEffect(() => {
    if (session && remaining === 0 && !submittedRef.current) submit();
  }, [remaining, session, submit]);

  const choose = useCallback((qid: number, idx: number) => setSession((s) => (s ? { ...s, answers: { ...s.answers, [qid]: idx } } : s)), []);
  const go = useCallback((i: number) => setSession((s) => (s ? { ...s, current: Math.max(0, Math.min(s.questions.length - 1, i)) } : s)), []);

  useEffect(() => {
    if (!session) return;
    const h = (e: KeyboardEvent) => {
      if (confirm || submitting) return;
      const q = session.questions[session.current];
      const k = e.key.toUpperCase();
      const li = LETTERS.indexOf(k);
      if (li >= 0 && li < q.options.length) choose(q.id, li);
      else if (k === "N" || e.key === "ArrowRight") go(session.current + 1);
      else if (k === "P" || e.key === "ArrowLeft") go(session.current - 1);
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [session, confirm, submitting, choose, go]);

  async function start(t: TestInfo) {
    if (!student) return openSignIn();
    setLoadingId(t.id);
    setError("");
    try {
      const res = await fetch(`/api/cbt/questions?testId=${t.id}`, { cache: "no-store" });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Could not load test");
      if (!data.questions.length) throw new Error("This test has no questions yet.");
      submittedRef.current = false;
      setNow(Date.now());
      setPending(null);
      setSession({ test: data.test, startedAt: Date.now(), durationSec: data.test.durationMin * 60, questions: data.questions, answers: {}, current: 0 });
      window.scrollTo({ top: 0 });
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not load test");
    } finally {
      setLoadingId(null);
    }
  }

  const pickCategory = (id: CategoryId) => {
    const c = getCategory(id)!;
    setCategory(id);
    setDepartment(c.departments[0].id);
    setLevel(c.departments[0].levels[0]);
  };
  const pickDepartment = (id: string) => {
    const d = cat.departments.find((x) => x.id === id)!;
    setDepartment(id);
    if (!d.levels.includes(level)) setLevel(d.levels[0]);
  };

  /* ================= TEST SELECTION ================= */
  if (!session) {
    const isMine = student && student.category === category && student.department === dep.id && student.level === level;
    return (
      <div>
        <section className="relative overflow-hidden bg-ink-950">
          <div className="absolute inset-0 bg-cover bg-center" style={{ backgroundImage: "url(/images/exam.jpg)" }} />
          <div className="absolute inset-0 bg-gradient-to-r from-ink-950 via-ink-950/85 to-ink-950/40" />
          <div className="relative mx-auto max-w-7xl px-6 py-16 sm:py-20">
            <p className="text-[11px] font-semibold uppercase tracking-[0.3em] text-gold-400">CBT Centre</p>
            <h1 className="mt-3 font-serif text-4xl font-medium text-white sm:text-5xl">Computer Based Tests</h1>
            <p className="mt-4 max-w-2xl text-ink-200">
              Separate tests for University, Polytechnic, Secondary and Primary students. Choose your school, department and level, then start your timed test.
            </p>
          </div>
        </section>

        {/* Category cards */}
        <div className="mx-auto -mt-10 max-w-7xl px-6">
          <div className="relative grid grid-cols-2 gap-3 lg:grid-cols-4">
            {CATEGORIES.map((c) => (
              <button
                key={c.id}
                onClick={() => pickCategory(c.id)}
                className={`group relative h-36 overflow-hidden rounded-md text-left shadow-lg transition ${
                  category === c.id ? "ring-2 ring-gold-400 ring-offset-2 ring-offset-ivory" : "opacity-90 hover:opacity-100"
                }`}
              >
                <div className="absolute inset-0 bg-cover bg-center transition duration-700 group-hover:scale-105" style={{ backgroundImage: `url(${c.image})` }} />
                <div className={`absolute inset-0 ${category === c.id ? "bg-ink-950/60" : "bg-ink-950/75"}`} />
                <div className="relative flex h-full flex-col justify-end p-5">
                  {category === c.id && (
                    <span className="absolute right-4 top-4 flex h-6 w-6 items-center justify-center rounded-full bg-gold-400">
                      <Check className="h-3.5 w-3.5 text-ink-950" strokeWidth={3} />
                    </span>
                  )}
                  <p className="font-serif text-xl text-white">{c.name}</p>
                  <p className="mt-1 line-clamp-1 text-xs text-ink-200">{c.tagline}</p>
                </div>
              </button>
            ))}
          </div>
        </div>

        <div className="mx-auto max-w-7xl px-6 py-12">
          {/* Department + level */}
          <div className="rounded-md border border-stone-200 bg-white p-6">
            {cat.departments.length > 1 && (
              <div>
                <p className="text-[11px] font-semibold uppercase tracking-[0.25em] text-ink-400">
                  {category === "secondary" ? "Section" : "Department / Programme"}
                </p>
                <div className="mt-3 flex flex-wrap gap-2">
                  {cat.departments.map((d) => (
                    <button
                      key={d.id}
                      onClick={() => pickDepartment(d.id)}
                      className={`rounded-sm border px-4 py-2.5 text-sm font-medium transition ${
                        dep.id === d.id ? "border-ink-900 bg-ink-900 text-white" : "border-stone-300 text-ink-700 hover:border-ink-400"
                      }`}
                    >
                      {d.name}
                    </button>
                  ))}
                </div>
              </div>
            )}
            <div className={cat.departments.length > 1 ? "mt-6" : ""}>
              <p className="text-[11px] font-semibold uppercase tracking-[0.25em] text-ink-400">{category === "university" ? "Level" : "Class"}</p>
              <div className="mt-3 flex flex-wrap gap-2">
                {dep.levels.map((l) => (
                  <button
                    key={l}
                    onClick={() => setLevel(l)}
                    className={`rounded-sm border px-4 py-2 text-sm font-medium transition ${
                      level === l ? "border-gold-500 bg-gold-50 text-gold-700" : "border-stone-300 text-ink-600 hover:border-ink-400"
                    }`}
                  >
                    {l}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Tests */}
          <div className="mt-10 flex flex-wrap items-end justify-between gap-4 border-b border-stone-200 pb-4">
            <div>
              <p className="text-[11px] font-semibold uppercase tracking-[0.3em] text-gold-600">Available tests</p>
              <h2 className="mt-1 font-serif text-3xl text-ink-950">{audienceLabel(category, dep.id, level)}</h2>
            </div>
            {ready &&
              (student ? (
                isMine ? (
                  <span className="flex items-center gap-2 rounded-sm bg-emerald-50 px-3 py-1.5 text-xs font-semibold text-emerald-800">
                    <UserRound className="h-3.5 w-3.5" /> Your class
                  </span>
                ) : (
                  <button
                    onClick={() => {
                      setCategory(student.category);
                      setDepartment(student.department);
                      setLevel(student.level);
                    }}
                    className="text-sm font-semibold text-ink-900 underline decoration-gold-400 underline-offset-4"
                  >
                    Show my class ({student.level})
                  </button>
                )
              ) : (
                <button onClick={openSignIn} className="text-sm font-semibold text-ink-900 underline decoration-gold-400 underline-offset-4">
                  Log in to start a test
                </button>
              ))}
          </div>

          {error && <p className="mt-6 rounded-sm bg-rose-50 p-3 text-sm text-rose-700">{error}</p>}

          {list === null ? (
            <div className="mt-6 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {[0, 1, 2].map((i) => (
                <div key={i} className="h-56 animate-pulse rounded-md bg-stone-200" />
              ))}
            </div>
          ) : list.length === 0 ? (
            <div className="mt-6 rounded-md border border-dashed border-stone-300 bg-white p-12 text-center text-ink-500">
              No tests have been set for this class yet. Please check back soon.
            </div>
          ) : (
            <div className="mt-6 space-y-10">
              {Array.from(
                list.reduce((m, t) => {
                  const k = t.semester || "";
                  m.set(k, [...(m.get(k) ?? []), t]);
                  return m;
                }, new Map<string, TestInfo[]>()),
              ).map(([sem, items]) => (
                <section key={sem || "all"}>
                  {sem && (
                    <div className="mb-4 flex items-center gap-4">
                      <h3 className="font-serif text-2xl text-ink-950">{sem}</h3>
                      <span className="h-px flex-1 bg-stone-200" />
                      <span className="text-xs font-semibold uppercase tracking-wider text-ink-400">
                        {items.length} course{items.length === 1 ? "" : "s"}
                      </span>
                    </div>
                  )}
                  <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                    {items.map((t) => (
                      <TestCard
                        key={t.id}
                        t={t}
                        busy={loadingId !== null}
                        loading={loadingId === t.id}
                        onStart={() => (student ? setPending(t) : openSignIn())}
                      />
                    ))}
                  </div>
                </section>
              ))}
            </div>
          )}

          <div className="mt-12 grid gap-6 rounded-md border border-stone-200 bg-white p-8 md:grid-cols-2">
            <div>
              <h3 className="font-serif text-2xl text-ink-950">Test instructions</h3>
              <p className="mt-2 text-sm text-ink-500">Please read before you start.</p>
            </div>
            <ol className="space-y-3">
              {[
                "The timer starts as soon as you click Start Test.",
                "Each question has one correct answer. Click an option to choose it.",
                "Use Next / Previous or the question navigator to move between questions.",
                "Keyboard shortcuts: A–D to choose an answer, N / P or arrow keys to move.",
                "Your answers are submitted automatically when time runs out.",
              ].map((t, i) => (
                <li key={i} className="flex gap-4 text-sm text-ink-700">
                  <span className="font-serif text-base leading-5 text-gold-600">{String(i + 1).padStart(2, "0")}</span>
                  <span className="leading-5">{t}</span>
                </li>
              ))}
            </ol>
          </div>
        </div>

        {pending && student && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink-950/70 p-4 backdrop-blur-sm" onClick={() => setPending(null)}>
            <div onClick={(e) => e.stopPropagation()} className="w-full max-w-md overflow-hidden rounded-md bg-paper shadow-2xl">
              <div className="bg-ink-950 px-7 py-6">
                <p className="text-[11px] font-semibold uppercase tracking-[0.25em] text-gold-300">{pending.code} · CBT Test</p>
                <h3 className="mt-1 font-serif text-2xl text-white">{pending.title}</h3>
                <p className="mt-1 text-sm text-ink-300">
                  {audienceLabel(pending.category, pending.department === "ALL" ? dep.id : pending.department, pending.level)}
                  {pending.semester ? ` · ${pending.semester}` : ""}
                </p>
              </div>
              <dl className="grid grid-cols-2 divide-x divide-stone-200 border-b border-stone-200 text-center">
                <div className="p-5">
                  <dd className="font-serif text-2xl text-ink-950">{pending.questionCount}</dd>
                  <dt className="text-xs uppercase tracking-wider text-ink-400">Questions</dt>
                </div>
                <div className="p-5">
                  <dd className="font-serif text-2xl text-ink-950">{pending.durationMin}:00</dd>
                  <dt className="text-xs uppercase tracking-wider text-ink-400">Minutes</dt>
                </div>
              </dl>
              <div className="p-7">
                <p className="text-sm text-ink-600">
                  Candidate: <b className="text-ink-900">{student.name}</b> ({student.regNo})
                </p>
                <p className="mt-2 text-sm text-ink-500">The timer will start immediately. Good luck!</p>
                <div className="mt-6 flex gap-3">
                  <button onClick={() => setPending(null)} className="flex-1 rounded-sm border border-stone-300 py-3 text-sm font-semibold text-ink-700 hover:bg-stone-50">
                    Cancel
                  </button>
                  <button
                    onClick={() => start(pending)}
                    disabled={loadingId !== null}
                    className="flex flex-1 items-center justify-center gap-2 rounded-sm bg-gold-400 py-3 text-sm font-semibold text-ink-950 hover:bg-gold-300 disabled:opacity-60"
                  >
                    {loadingId !== null && <Loader2 className="h-4 w-4 animate-spin" />} Start now
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  /* ================= TEST IN PROGRESS ================= */
  const q = session.questions[session.current];
  const answeredCount = Object.keys(session.answers).length;
  const total = session.questions.length;
  const mm = String(Math.floor(remaining / 60)).padStart(2, "0");
  const ss = String(remaining % 60).padStart(2, "0");
  const pct = (remaining / session.durationSec) * 100;
  const danger = remaining <= 60;
  const warn = remaining <= Math.min(180, session.durationSec * 0.25);

  return (
    <div className="min-h-[80vh] bg-ivory">
      <div className="sticky top-[80px] z-30 border-b border-ink-800 bg-ink-950 text-white md:top-[116px]">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-4 px-6 py-4">
          <div className="min-w-0">
            <p className="text-[10px] font-semibold uppercase tracking-[0.25em] text-gold-300">
              {session.test.code} · {session.test.title}
            </p>
            <p className="mt-0.5 truncate text-sm text-ink-200">
              {student?.name} <span className="text-ink-400">· {student?.regNo} · {session.test.level}</span>
            </p>
          </div>
          <div className="flex items-center gap-6">
            <div className="hidden text-right text-sm sm:block">
              <p className="text-ink-400">Answered</p>
              <p className="font-serif text-lg">
                {answeredCount} <span className="text-ink-400">/ {total}</span>
              </p>
            </div>
            <div
              className={`flex items-center gap-3 rounded-sm border px-5 py-2.5 font-mono text-2xl font-semibold tabular-nums transition ${
                danger ? "animate-pulse border-rose-500 bg-rose-700 text-white" : warn ? "border-gold-400 bg-gold-400/10 text-gold-200" : "border-white/15 bg-white/5 text-white"
              }`}
            >
              <Clock className="h-5 w-5" strokeWidth={1.8} />
              {mm}:{ss}
            </div>
          </div>
        </div>
        <div className="h-[3px] bg-ink-800">
          <div className={`h-full transition-all duration-300 ${danger ? "bg-rose-500" : warn ? "bg-gold-400" : "bg-gold-300"}`} style={{ width: `${pct}%` }} />
        </div>
      </div>

      <div className="mx-auto grid max-w-7xl gap-8 px-6 py-10 lg:grid-cols-[1fr_320px]">
        <div className="rounded-md border border-stone-200 bg-white p-8 sm:p-10">
          <p className="text-[11px] font-semibold uppercase tracking-[0.25em] text-gold-600">
            Question {session.current + 1} of {total}
          </p>
          <h2 className="mt-4 font-serif text-2xl leading-relaxed text-ink-950 sm:text-[28px]">{q.question}</h2>
          <div className="mt-8 space-y-3">
            {q.options.map((opt, i) => {
              const sel = session.answers[q.id] === i;
              return (
                <button
                  key={i}
                  onClick={() => choose(q.id, i)}
                  className={`flex w-full items-center gap-5 rounded-sm border p-5 text-left transition ${
                    sel ? "border-ink-900 bg-ink-50 ring-1 ring-ink-900" : "border-stone-200 hover:border-ink-300 hover:bg-paper"
                  }`}
                >
                  <span
                    className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-full border font-serif text-base ${
                      sel ? "border-ink-900 bg-ink-900 text-gold-300" : "border-stone-300 text-ink-500"
                    }`}
                  >
                    {LETTERS[i]}
                  </span>
                  <span className={`text-[15px] ${sel ? "font-medium text-ink-950" : "text-ink-700"}`}>{opt}</span>
                </button>
              );
            })}
          </div>
          <div className="mt-10 flex items-center justify-between gap-3 border-t border-stone-100 pt-6">
            <button
              onClick={() => go(session.current - 1)}
              disabled={session.current === 0}
              className="flex items-center gap-2 rounded-sm border border-stone-300 px-5 py-3 text-sm font-semibold text-ink-700 hover:bg-stone-50 disabled:opacity-40"
            >
              <ArrowLeft className="h-4 w-4" /> Previous
            </button>
            {session.current < total - 1 ? (
              <button onClick={() => go(session.current + 1)} className="flex items-center gap-2 rounded-sm bg-ink-900 px-6 py-3 text-sm font-semibold text-white hover:bg-ink-800">
                Next <ArrowRight className="h-4 w-4" />
              </button>
            ) : (
              <button onClick={() => setConfirm(true)} className="flex items-center gap-2 rounded-sm bg-gold-400 px-6 py-3 text-sm font-semibold text-ink-950 hover:bg-gold-300">
                <Check className="h-4 w-4" /> Finish & Submit
              </button>
            )}
          </div>
        </div>

        <aside className="h-fit rounded-md border border-stone-200 bg-white lg:sticky lg:top-[220px]">
          <h3 className="border-b border-stone-200 px-6 py-4 font-serif text-lg text-ink-950">Question Navigator</h3>
          <div className={`grid gap-2 p-6 ${total > 20 ? "max-h-[46vh] grid-cols-6 overflow-y-auto" : "grid-cols-5"}`}>
            {session.questions.map((qq, i) => {
              const answered = session.answers[qq.id] !== undefined;
              const cur = i === session.current;
              return (
                <button
                  key={qq.id}
                  onClick={() => go(i)}
                  className={`aspect-square rounded-sm text-sm font-semibold transition ${cur ? "ring-2 ring-gold-500 ring-offset-2" : ""} ${
                    answered ? "bg-ink-900 text-white" : "border border-stone-200 bg-paper text-ink-500 hover:border-ink-300"
                  }`}
                >
                  {i + 1}
                </button>
              );
            })}
          </div>
          <div className="space-y-2 border-t border-stone-100 px-6 py-4 text-xs text-ink-500">
            <div className="flex items-center gap-2.5"><span className="h-3 w-3 rounded-sm bg-ink-900" /> Answered</div>
            <div className="flex items-center gap-2.5"><span className="h-3 w-3 rounded-sm border border-stone-300 bg-paper" /> Not answered</div>
            <div className="flex items-center gap-2.5"><span className="h-3 w-3 rounded-sm ring-2 ring-gold-500" /> Current question</div>
          </div>
          <div className="border-t border-stone-100 p-6">
            {error && <p className="mb-3 rounded-sm bg-rose-50 p-2 text-xs text-rose-700">{error}</p>}
            <button
              onClick={() => setConfirm(true)}
              disabled={submitting}
              className="w-full rounded-sm bg-gold-400 py-3.5 text-sm font-semibold tracking-wide text-ink-950 hover:bg-gold-300 disabled:opacity-60"
            >
              {submitting ? "Submitting…" : "Submit Test"}
            </button>
          </div>
        </aside>
      </div>

      {(confirm || submitting) && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink-950/70 p-4 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-md bg-paper p-8 text-center shadow-2xl">
            {submitting ? (
              <>
                <Loader2 className="mx-auto h-10 w-10 animate-spin text-ink-900" />
                <p className="mt-5 font-serif text-xl text-ink-950">{remaining === 0 ? "Time is up" : "Submitting your answers"}</p>
                <p className="mt-1 text-sm text-ink-500">Please wait while we mark your test…</p>
              </>
            ) : (
              <>
                <span className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-gold-50 text-gold-600">
                  <AlertTriangle className="h-6 w-6" />
                </span>
                <h3 className="mt-5 font-serif text-2xl text-ink-950">Submit test?</h3>
                <p className="mt-2 text-sm text-ink-600">
                  You have answered <b>{answeredCount}</b> of <b>{total}</b> questions.
                </p>
                {answeredCount < total && <p className="mt-1 text-sm text-gold-700">{total - answeredCount} question(s) are still unanswered.</p>}
                <div className="mt-7 flex gap-3">
                  <button onClick={() => setConfirm(false)} className="flex-1 rounded-sm border border-stone-300 py-3 text-sm font-semibold text-ink-700 hover:bg-stone-50">
                    Return to test
                  </button>
                  <button onClick={submit} className="flex-1 rounded-sm bg-ink-900 py-3 text-sm font-semibold text-white hover:bg-ink-800">
                    Submit now
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

