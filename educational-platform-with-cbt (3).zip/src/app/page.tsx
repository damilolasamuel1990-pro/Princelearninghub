import Link from "next/link";
import { asc, desc, sql } from "drizzle-orm";
import {
  ArrowRight,
  ArrowUpRight,
  BookOpen,
  CalendarDays,
  Check,
  Clock,
  MessagesSquare,
  Newspaper,
  PlayCircle,
  Trophy,
} from "lucide-react";
import { db } from "@/db";
import { lectures, materials, news, questions, results } from "@/db/schema";
import { ensureDb } from "@/lib/bootstrap";
import { newsImage } from "@/lib/constants";
import { CATEGORIES, CONTACT, whatsappLink } from "@/lib/academics";
import { WhatsAppIcon } from "@/components/WhatsApp";

export const dynamic = "force-dynamic";

const primary = [
  {
    href: "/lectures",
    image: "/images/lecturer.jpg",
    tag: "Live & Recorded",
    title: "Online Lectures",
    text: "Attend live classes or catch up on recordings, with a question-and-answer chat in every lecture room.",
  },
  {
    href: "/materials",
    image: "/images/library.jpg",
    tag: "Library",
    title: "Course Materials",
    text: "Download lecture notes, handouts and study guides in PDF, prepared by your lecturers for every course.",
  },
  {
    href: "/cbt",
    image: "/images/exam.jpg",
    tag: "CBT Tests",
    title: "CBT Practice",
    text: "Write timed computer-based tests for your class and get your score and corrections straight away.",
  },
];

const secondary = [
  { href: "/results", icon: Trophy, title: "Results & Rankings", text: "Review past scores, corrections and the leaderboard." },
  { href: "/chat", icon: MessagesSquare, title: "Discussions", text: "Ask tutors questions and study with classmates." },
  { href: "/news", icon: Newspaper, title: "News & Notices", text: "Announcements, timetables and important dates." },
];

const fmtDate = (d: Date) => d.toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" });

export default async function Home() {
  await ensureDb();
  const [latestNews, allLectures, [counts]] = await Promise.all([
    db.select().from(news).orderBy(desc(news.pinned), desc(news.createdAt)).limit(6),
    db.select().from(lectures).orderBy(asc(lectures.scheduledAt)),
    db
      .select({
        materials: sql<number>`(select count(*)::int from ${materials})`,
        questions: sql<number>`(select count(*)::int from ${questions})`,
        results: sql<number>`(select count(*)::int from ${results})`,
        lectures: sql<number>`(select count(*)::int from ${lectures})`,
      })
      .from(sql`(select 1) as t`),
  ]);
  const live = allLectures.find((l) => l.status === "live");
  const upcoming = allLectures.filter((l) => l.status === "upcoming").slice(0, 3);
  const [featured, ...restNews] = latestNews;

  return (
    <div>
      {/* HERO */}
      <section className="relative overflow-hidden bg-ink-950">
        <div className="absolute inset-0 bg-cover bg-[center_30%]" style={{ backgroundImage: "url(/images/graduation.jpg)" }} />
        <div className="absolute inset-0 bg-gradient-to-r from-ink-950 via-ink-950/88 to-ink-950/35" />
        <div className="absolute inset-0 bg-gradient-to-t from-ink-950/80 via-transparent to-transparent" />

        <div className="relative mx-auto grid max-w-7xl items-center gap-12 px-6 pb-16 pt-20 sm:pt-28 lg:grid-cols-12">
          <div className="lg:col-span-7">
            <p className="flex items-center gap-3 text-[11px] font-semibold uppercase tracking-[0.32em] text-gold-300">
              <span className="h-px w-10 bg-gold-400" /> Online Learning Platform
            </p>
            <h1 className="mt-6 font-serif text-5xl font-medium leading-[1.05] text-white sm:text-6xl lg:text-[68px]">
              Learn well,
              <br />
              <span className="italic text-gold-300">wherever you are.</span>
            </h1>
            <p className="mt-6 max-w-xl text-lg leading-relaxed text-ink-200">
              Prince Learning Hub brings live lectures, PDF course materials, timed CBT tests and tutor support together for university, polytechnic, secondary and primary students.
            </p>
            <div className="mt-10 flex flex-wrap gap-4">
              <Link
                href="/lectures"
                className="inline-flex items-center gap-2 rounded-sm bg-gold-400 px-7 py-4 text-sm font-semibold tracking-wide text-ink-950 transition hover:bg-gold-300"
              >
                Attend a Lecture <ArrowRight className="h-4 w-4" />
              </Link>
              <Link
                href="/cbt"
                className="inline-flex items-center gap-2 rounded-sm border border-white/30 px-7 py-4 text-sm font-semibold tracking-wide text-white transition hover:border-white hover:bg-white/5"
              >
                Take a CBT Test
              </Link>
            </div>
          </div>

          {live && (
            <div className="lg:col-span-5">
              <Link
                href={`/lectures/${live.id}`}
                className="group block overflow-hidden rounded-md border border-white/15 bg-white/[0.06] backdrop-blur-md transition hover:border-gold-400/60"
              >
                <div className="relative aspect-video overflow-hidden">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={`https://img.youtube.com/vi/${live.videoId}/hqdefault.jpg`}
                    alt=""
                    className="h-full w-full object-cover transition duration-700 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-ink-950/30" />
                  <span className="absolute left-4 top-4 flex items-center gap-2 rounded-sm bg-rose-700 px-2.5 py-1 text-[10px] font-bold uppercase tracking-[0.15em] text-white">
                    <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-white" /> Live now
                  </span>
                  <PlayCircle className="absolute left-1/2 top-1/2 h-16 w-16 -translate-x-1/2 -translate-y-1/2 text-white/90 transition group-hover:scale-110" strokeWidth={1.2} />
                </div>
                <div className="p-6">
                  <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-gold-300">
                    {live.courseCode} · {live.lecturer}
                  </p>
                  <h3 className="mt-2 font-serif text-xl leading-snug text-white">{live.title}</h3>
                  <p className="mt-4 flex items-center gap-2 text-sm text-ink-200 group-hover:text-white">
                    Enter lecture room <ArrowRight className="h-4 w-4" />
                  </p>
                </div>
              </Link>
            </div>
          )}
        </div>

        <div className="relative border-t border-white/10">
          <div className="mx-auto grid max-w-7xl grid-cols-2 divide-white/10 px-6 sm:grid-cols-4 sm:divide-x">
            {[
              [counts.lectures, "Lectures"],
              [counts.materials, "Study materials"],
              [counts.questions, "CBT questions"],
              [counts.results, "Tests completed"],
            ].map(([n, l]) => (
              <div key={l as string} className="py-7 sm:px-8 sm:first:pl-0">
                <div className="font-serif text-4xl text-white">{n}</div>
                <div className="mt-1 text-xs uppercase tracking-[0.2em] text-ink-300">{l}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* NEWS TICKER */}
      <div className="flex items-stretch overflow-hidden border-b border-stone-200 bg-white">
        <span className="z-10 flex shrink-0 items-center gap-2 bg-ink-900 px-5 py-3 text-[11px] font-semibold uppercase tracking-[0.2em] text-gold-300">
          <Newspaper className="h-3.5 w-3.5" /> Latest
        </span>
        <div className="relative flex-1 overflow-hidden">
          <div className="animate-marquee flex w-max items-center gap-10 whitespace-nowrap py-3 text-sm text-ink-700">
            {[...latestNews, ...latestNews].map((n, i) => (
              <Link key={i} href="/news" className="flex items-center gap-10 hover:text-gold-700">
                {n.title}
                <span className="h-1 w-1 rounded-full bg-gold-500" />
              </Link>
            ))}
          </div>
        </div>
      </div>

      {/* SERVICES */}
      <section className="mx-auto max-w-7xl px-6 py-24">
        <div className="grid gap-6 lg:grid-cols-2 lg:items-end">
          <div>
            <p className="text-[11px] font-semibold uppercase tracking-[0.3em] text-gold-600">What we offer</p>
            <h2 className="mt-3 font-serif text-4xl font-medium leading-tight text-ink-950 sm:text-5xl">Everything you need to study online</h2>
          </div>
          <p className="text-base leading-relaxed text-ink-500 lg:pb-2">
            Lectures, materials, tests and results in one place. Join a class, download your notes, test yourself and track your progress through the session.
          </p>
        </div>

        <div className="mt-14 grid gap-6 md:grid-cols-3">
          {primary.map((f) => (
            <Link key={f.href} href={f.href} className="group relative block overflow-hidden rounded-md bg-ink-950">
              <div className="aspect-[4/5] overflow-hidden">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={f.image} alt={f.title} className="h-full w-full object-cover opacity-90 transition duration-700 group-hover:scale-105" />
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-ink-950 via-ink-950/50 to-transparent" />
              <div className="absolute inset-x-0 bottom-0 p-7">
                <p className="text-[10px] font-semibold uppercase tracking-[0.25em] text-gold-300">{f.tag}</p>
                <h3 className="mt-2 font-serif text-2xl text-white">{f.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-ink-200">{f.text}</p>
                <span className="mt-5 inline-flex items-center gap-2 text-sm font-semibold text-white">
                  Explore <ArrowUpRight className="h-4 w-4 transition group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
                </span>
              </div>
            </Link>
          ))}
        </div>

        <div className="mt-6 grid gap-6 md:grid-cols-3">
          {secondary.map((f) => (
            <Link key={f.href} href={f.href} className="group flex gap-5 rounded-md border border-stone-200 bg-white p-6 transition hover:border-gold-400 hover:shadow-md">
              <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-sm border border-gold-200 bg-gold-50 text-gold-700">
                <f.icon className="h-5 w-5" strokeWidth={1.6} />
              </span>
              <div>
                <h3 className="font-serif text-lg text-ink-950">{f.title}</h3>
                <p className="mt-1 text-sm text-ink-500">{f.text}</p>
              </div>
            </Link>
          ))}
        </div>
      </section>


      {/* CBT FOR EVERY STUDENT */}
      <section className="bg-ink-950">
        <div className="mx-auto max-w-7xl px-6 py-24">
          <div className="grid gap-6 lg:grid-cols-2 lg:items-end">
            <div>
              <p className="text-[11px] font-semibold uppercase tracking-[0.3em] text-gold-400">CBT Centre</p>
              <h2 className="mt-3 font-serif text-4xl font-medium leading-tight text-white sm:text-5xl">A test for every student, at every level</h2>
            </div>
            <p className="text-base leading-relaxed text-ink-300 lg:pb-2">
              A 100 level Computer Science student, a 400 level Software Engineering student, an HND Cybersecurity student and an SSS 3 student can all log in and write their own tests, each with its own timer and result.
            </p>
          </div>
          <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {CATEGORIES.map((c) => (
              <Link key={c.id} href="/cbt" className="group relative block overflow-hidden rounded-md">
                <div className="aspect-[3/4] overflow-hidden">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={c.image} alt={c.name} className="h-full w-full object-cover transition duration-700 group-hover:scale-105" />
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-ink-950 via-ink-950/60 to-ink-950/10" />
                <div className="absolute inset-x-0 bottom-0 p-6">
                  <h3 className="font-serif text-2xl text-white">{c.name}</h3>
                  <ul className="mt-3 space-y-1 text-[13px] text-ink-200">
                    {c.departments.slice(0, 5).map((d) => (
                      <li key={d.id} className="flex items-start gap-2">
                        <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-gold-400" />
                        <span>
                          {c.id === "primary" ? "Primary 1 – Primary 6" : d.name}
                          {c.id !== "primary" && <span className="text-ink-400"> · {d.levels[0]}–{d.levels[d.levels.length - 1]}</span>}
                        </span>
                      </li>
                    ))}
                  </ul>
                  <span className="mt-5 inline-flex items-center gap-2 text-sm font-semibold text-gold-300">
                    Start a test <ArrowUpRight className="h-4 w-4" />
                  </span>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ABOUT SPLIT */}
      <section className="bg-white">
        <div className="mx-auto grid max-w-7xl items-center gap-16 px-6 py-24 lg:grid-cols-2">
          <div className="relative">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src="/images/online-class.jpg" alt="Student attending an online class" className="aspect-[4/3] w-full rounded-md object-cover" />
            <div className="absolute -bottom-8 -right-4 hidden w-64 rounded-md border border-stone-200 bg-paper p-5 shadow-xl sm:block">
              <div className="flex items-center gap-3">
                <span className="flex h-10 w-10 items-center justify-center rounded-sm bg-ink-900 text-gold-300">
                  <Clock className="h-5 w-5" />
                </span>
                <div>
                  <div className="font-serif text-xl text-ink-950">10 minutes</div>
                  <div className="text-xs text-ink-500">Timed CBT · instant marking</div>
                </div>
              </div>
            </div>
            <div className="absolute -left-4 -top-4 -z-0 hidden h-32 w-32 border-l-2 border-t-2 border-gold-400 lg:block" />
          </div>
          <div>
            <p className="text-[11px] font-semibold uppercase tracking-[0.3em] text-gold-600">Why Prince Learning Hub</p>
            <h2 className="mt-3 font-serif text-4xl font-medium leading-tight text-ink-950">A complete campus, wherever you study</h2>
            <p className="mt-5 leading-relaxed text-ink-500">
              Study at your own pace from home, from the library or on the move, with the same support you would get on campus.
            </p>
            <ul className="mt-8 space-y-4">
              {[
                "Live and recorded lectures, each with its own discussion room",
                "Downloadable notes and handouts for every course",
                "Separate CBT tests for university, polytechnic, secondary and primary students",
                "Instant results with full corrections and explanations",
                "Ask tutors questions in course discussion rooms",
              ].map((t) => (
                <li key={t} className="flex gap-4">
                  <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-ink-900 text-gold-300">
                    <Check className="h-3.5 w-3.5" strokeWidth={2.5} />
                  </span>
                  <span className="text-ink-700">{t}</span>
                </li>
              ))}
            </ul>
            <Link href="/materials" className="mt-10 inline-flex items-center gap-2 rounded-sm bg-ink-900 px-7 py-4 text-sm font-semibold tracking-wide text-white hover:bg-ink-800">
              Browse course materials <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* NEWS + UPCOMING */}
      <section className="mx-auto max-w-7xl px-6 py-24">
        <div className="mb-12 flex items-end justify-between gap-6">
          <div>
            <p className="text-[11px] font-semibold uppercase tracking-[0.3em] text-gold-600">News & Events</p>
            <h2 className="mt-3 font-serif text-4xl font-medium text-ink-950">From the Hub</h2>
          </div>
          <Link href="/news" className="hidden items-center gap-2 text-sm font-semibold text-ink-900 hover:text-gold-700 sm:inline-flex">
            All news <ArrowRight className="h-4 w-4" />
          </Link>
        </div>

        <div className="grid gap-10 lg:grid-cols-12">
          <div className="lg:col-span-8">
            {featured && (
              <Link href="/news" className="group grid overflow-hidden rounded-md border border-stone-200 bg-white md:grid-cols-2">
                <div className="aspect-[4/3] overflow-hidden md:aspect-auto">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={newsImage(featured.category)} alt="" className="h-full w-full object-cover transition duration-700 group-hover:scale-105" />
                </div>
                <div className="flex flex-col p-8">
                  <div className="flex items-center gap-3 text-[11px] font-semibold uppercase tracking-[0.2em]">
                    <span className="text-gold-600">{featured.category}</span>
                    {featured.pinned && <span className="text-ink-400">· Pinned</span>}
                  </div>
                  <h3 className="mt-4 font-serif text-2xl leading-snug text-ink-950 group-hover:text-gold-700">{featured.title}</h3>
                  <p className="mt-3 line-clamp-4 text-sm leading-relaxed text-ink-500">{featured.body}</p>
                  <p className="mt-auto pt-6 text-xs text-ink-400">{fmtDate(featured.createdAt)}</p>
                </div>
              </Link>
            )}
            <div className="mt-6 grid gap-6 sm:grid-cols-3">
              {restNews.slice(0, 3).map((n) => (
                <Link key={n.id} href="/news" className="group">
                  <div className="aspect-[3/2] overflow-hidden rounded-md">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={newsImage(n.category)} alt="" className="h-full w-full object-cover transition duration-700 group-hover:scale-105" />
                  </div>
                  <p className="mt-4 text-[10px] font-semibold uppercase tracking-[0.2em] text-gold-600">{n.category}</p>
                  <h4 className="mt-1.5 font-serif text-lg leading-snug text-ink-950 group-hover:text-gold-700">{n.title}</h4>
                  <p className="mt-2 text-xs text-ink-400">{fmtDate(n.createdAt)}</p>
                </Link>
              ))}
            </div>
          </div>

          <aside className="lg:col-span-4">
            <div className="rounded-md border border-stone-200 bg-white">
              <div className="flex items-center justify-between border-b border-stone-200 px-6 py-5">
                <h3 className="flex items-center gap-2 font-serif text-xl text-ink-950">
                  <CalendarDays className="h-5 w-5 text-gold-600" strokeWidth={1.6} /> Upcoming Lectures
                </h3>
              </div>
              <div className="divide-y divide-stone-100">
                {upcoming.length === 0 && <p className="p-6 text-sm text-ink-400">No upcoming lectures.</p>}
                {upcoming.map((l) => (
                  <Link key={l.id} href={`/lectures/${l.id}`} className="flex gap-5 px-6 py-5 transition hover:bg-paper">
                    <div className="flex w-14 shrink-0 flex-col items-center border-r border-stone-200 pr-5">
                      <span className="font-serif text-3xl leading-none text-ink-950">{l.scheduledAt.getDate()}</span>
                      <span className="mt-1 text-[10px] font-semibold uppercase tracking-[0.2em] text-gold-600">
                        {l.scheduledAt.toLocaleDateString("en-GB", { month: "short" })}
                      </span>
                    </div>
                    <div className="min-w-0">
                      <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-ink-400">{l.courseCode}</p>
                      <p className="mt-0.5 font-medium leading-snug text-ink-900">{l.title}</p>
                      <p className="mt-1 text-xs text-ink-500">
                        {l.lecturer} · {l.scheduledAt.toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" })}
                      </p>
                    </div>
                  </Link>
                ))}
              </div>
              <Link href="/lectures" className="flex items-center justify-center gap-2 border-t border-stone-200 py-4 text-sm font-semibold text-ink-900 hover:text-gold-700">
                Full timetable <ArrowRight className="h-4 w-4" />
              </Link>
            </div>

            <div className="relative mt-6 overflow-hidden rounded-md bg-ink-950 p-8">
              <div className="absolute inset-0 bg-cover bg-center opacity-25" style={{ backgroundImage: "url(/images/computers-library.jpg)" }} />
              <div className="relative">
                <BookOpen className="h-7 w-7 text-gold-300" strokeWidth={1.4} />
                <h3 className="mt-4 font-serif text-2xl text-white">Ready for your test?</h3>
                <p className="mt-2 text-sm text-ink-200">10 questions · 10 minutes · results as soon as you submit.</p>
                <Link href="/cbt" className="mt-6 inline-flex items-center gap-2 rounded-sm bg-gold-400 px-5 py-3 text-sm font-semibold text-ink-950 hover:bg-gold-300">
                  Start CBT <ArrowRight className="h-4 w-4" />
                </Link>
              </div>
            </div>
          </aside>
        </div>
      </section>

      {/* CTA BAND */}
      <section className="relative overflow-hidden bg-ink-950">
        <div className="absolute inset-0 bg-cover bg-center" style={{ backgroundImage: "url(/images/group-study.jpg)" }} />
        <div className="absolute inset-0 bg-ink-950/85" />
        <div className="relative mx-auto flex max-w-7xl flex-col items-start justify-between gap-8 px-6 py-20 lg:flex-row lg:items-center">
          <div className="max-w-2xl">
            <p className="text-[11px] font-semibold uppercase tracking-[0.3em] text-gold-300">Student Community</p>
            <h2 className="mt-3 font-serif text-4xl font-medium leading-tight text-white">Have a question? Your tutors and classmates are here.</h2>
            <p className="mt-4 text-ink-200">Join a course discussion room to ask questions, share ideas and get answers from tutors.</p>
          </div>
          <div className="flex shrink-0 flex-col gap-3 sm:flex-row">
            <Link href="/chat" className="inline-flex items-center justify-center gap-2 rounded-sm bg-gold-400 px-7 py-4 text-sm font-semibold tracking-wide text-ink-950 hover:bg-gold-300">
              Join the discussion <ArrowRight className="h-4 w-4" />
            </Link>
            <a
              href={whatsappLink()}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 rounded-sm bg-[#25D366] px-7 py-4 text-sm font-semibold tracking-wide text-white hover:bg-[#1ebe5b]"
            >
              <WhatsAppIcon className="h-4 w-4" /> WhatsApp {CONTACT.whatsapp}
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
