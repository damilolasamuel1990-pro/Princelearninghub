"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import { LogOut, Mail, Menu, X } from "lucide-react";
import { CONTACT, getCategory, whatsappLink } from "@/lib/academics";
import { WhatsAppIcon } from "./WhatsApp";
import { useStudent } from "./StudentProvider";
import Brand from "./Logo";

const links = [
  { href: "/", label: "Home" },
  { href: "/lectures", label: "Lectures" },
  { href: "/materials", label: "Materials" },
  { href: "/cbt", label: "CBT" },
  { href: "/results", label: "Results" },
  { href: "/news", label: "News" },
  { href: "/chat", label: "Discussions" },
];

export default function Navbar() {
  const pathname = usePathname();
  const { student, ready, openSignIn, signOut } = useStudent();
  const [open, setOpen] = useState(false);
  const isActive = (href: string) => (href === "/" ? pathname === "/" : pathname.startsWith(href));

  return (
    <header className="sticky top-0 z-40">
      <div className="hidden bg-ink-950 text-[12px] text-ink-300 md:block">
        <div className="mx-auto flex h-9 max-w-7xl items-center justify-between px-6">
          <div className="flex items-center gap-6">
            <a href={whatsappLink()} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 hover:text-gold-300">
              <WhatsAppIcon className="h-3.5 w-3.5 text-[#25D366]" /> {CONTACT.whatsapp}
            </a>
            <a href={`mailto:${CONTACT.email}`} className="flex items-center gap-2 hover:text-gold-300">
              <Mail className="h-3.5 w-3.5 text-gold-400" /> {CONTACT.email}
            </a>
          </div>
          <div className="flex items-center gap-6">
            <span>2026 Academic Session</span>
            <Link href="/admin" className="hover:text-gold-300">Staff Portal</Link>
          </div>
        </div>
      </div>

      <div className="border-b border-stone-200 bg-paper/95 backdrop-blur">
        <div className="mx-auto flex h-20 max-w-7xl items-center justify-between px-6">
          <Brand />

          <nav className="hidden items-center gap-7 lg:flex">
            {links.map((l) => (
              <Link
                key={l.href}
                href={l.href}
                className={`relative py-2 text-[14px] font-medium transition-colors ${
                  isActive(l.href) ? "text-ink-950" : "text-ink-500 hover:text-ink-950"
                }`}
              >
                {l.label}
                {isActive(l.href) && <span className="absolute -bottom-[1px] left-0 right-0 h-[2px] bg-gold-500" />}
              </Link>
            ))}
          </nav>

          <div className="flex items-center gap-3">
            {ready &&
              (student ? (
                <div className="hidden items-center gap-3 sm:flex">
                  <span className="flex h-10 w-10 items-center justify-center rounded-full bg-ink-900 font-serif text-base text-gold-300">
                    {student.name.charAt(0).toUpperCase()}
                  </span>
                  <span className="text-[12px] leading-tight">
                    <span className="block font-semibold text-ink-900">{student.name}</span>
                    <span className="block text-ink-400">
                      {student.level} · {getCategory(student.category)?.name}
                    </span>
                  </span>
                  <button onClick={signOut} title="Sign out" className="ml-1 rounded-sm p-2 text-ink-400 hover:bg-stone-100 hover:text-ink-900">
                    <LogOut className="h-4 w-4" />
                  </button>
                </div>
              ) : (
                <button
                  onClick={openSignIn}
                  className="hidden rounded-sm bg-ink-900 px-5 py-2.5 text-[13px] font-semibold tracking-wide text-white transition hover:bg-ink-800 sm:block"
                >
                  Student Login
                </button>
              ))}
            <button onClick={() => setOpen((o) => !o)} className="rounded-sm p-2 text-ink-900 hover:bg-stone-100 lg:hidden" aria-label="Menu">
              {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>

        {open && (
          <nav className="border-t border-stone-200 bg-paper px-6 pb-5 pt-2 lg:hidden">
            {links.map((l) => (
              <Link
                key={l.href}
                href={l.href}
                onClick={() => setOpen(false)}
                className={`block border-b border-stone-100 py-3 text-[15px] font-medium ${isActive(l.href) ? "text-gold-600" : "text-ink-700"}`}
              >
                {l.label}
              </Link>
            ))}
            {ready &&
              (student ? (
                <button onClick={signOut} className="mt-4 w-full rounded-sm border border-ink-200 py-2.5 text-sm font-medium text-ink-700">
                  Sign out ({student.name})
                </button>
              ) : (
                <button
                  onClick={() => {
                    setOpen(false);
                    openSignIn();
                  }}
                  className="mt-4 w-full rounded-sm bg-ink-900 py-2.5 text-sm font-semibold text-white"
                >
                  Student Login
                </button>
              ))}
          </nav>
        )}
      </div>
    </header>
  );
}
