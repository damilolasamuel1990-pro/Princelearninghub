"use client";

import { useState, type ReactNode } from "react";

type WritableFileStream = { write: (data: BlobPart) => Promise<void>; close: () => Promise<void> };

type State =
  | { kind: "idle" }
  | { kind: "choosing" }
  | { kind: "saving" }
  | { kind: "saved"; name: string; size: string; where: "picker" | "auto" }
  | { kind: "cancelled" }
  | { kind: "failed"; name: string; href: string };

function fileSize(bytes: number) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

/**
 * Saves a file to the student's computer.
 *
 * 1. Where the browser supports it, the system "Save as" dialog is opened first
 *    so the student chooses the folder and sees the file being written.
 * 2. Otherwise the file is fetched and saved automatically.
 * 3. If both fail, the raw link is opened so the browser's own download button
 *    can be used.
 */
export default function DownloadLink({
  href,
  fileName,
  className,
  children,
  onStarted,
  ariaLabel,
}: {
  href: string;
  fileName: string;
  className?: string;
  children: ReactNode;
  onStarted?: () => void;
  ariaLabel?: string;
}) {
  const [state, setState] = useState<State>({ kind: "idle" });
  const busy = state.kind === "choosing" || state.kind === "saving";

  async function handleClick(e: React.MouseEvent) {
    e.preventDefault();
    if (busy) return;
    onStarted?.();

    // The save dialog must be opened while the click is still "fresh" for the browser.
    let handle: { createWritable: () => Promise<WritableFileStream> } | null = null;
    const picker = (window as { showSaveFilePicker?: unknown }).showSaveFilePicker;
    if (typeof picker === "function") {
      setState({ kind: "choosing" });
      try {
        handle = await (
          picker as (o: {
            suggestedName: string;
            types: { description: string; accept: Record<string, string[]> }[];
          }) => Promise<{ createWritable: () => Promise<WritableFileStream> }>
        )({
          suggestedName: fileName,
          types: [{ description: "PDF document", accept: { "application/pdf": [".pdf"] } }],
        });
      } catch (err) {
        if ((err as { name?: string })?.name === "AbortError") {
          setState({ kind: "cancelled" });
          return;
        }
        // any other problem: continue with the automatic download
      }
    }

    setState({ kind: "saving" });
    try {
      const res = await fetch(href, { credentials: "same-origin", cache: "no-store" });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const blob = await res.blob();
      if (blob.size === 0) throw new Error("empty file");

      if (handle) {
        const writable = await handle.createWritable();
        await writable.write(blob);
        await writable.close();
        setState({ kind: "saved", name: fileName, size: fileSize(blob.size), where: "picker" });
      } else {
        const objectUrl = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = objectUrl;
        a.download = fileName;
        a.rel = "noopener";
        document.body.appendChild(a);
        a.click();
        a.remove();
        setTimeout(() => URL.revokeObjectURL(objectUrl), 60_000);
        setState({ kind: "saved", name: fileName, size: fileSize(blob.size), where: "auto" });
      }
    } catch {
      setState({ kind: "failed", name: fileName, href });
    }
  }

  return (
    <>
      <a href={href} download={fileName} aria-label={ariaLabel} onClick={handleClick} className={className}>
        {children}
      </a>

      {state.kind !== "idle" && (
        <div className="fixed inset-x-4 bottom-6 z-50 mx-auto max-w-lg rounded-md border border-stone-200 bg-white p-5 shadow-2xl">
          {state.kind === "choosing" && (
            <p className="text-sm text-ink-800">
              📂 <b>{fileName}</b> — choose the folder where you want to save the file.
            </p>
          )}
          {state.kind === "saving" && <p className="text-sm text-ink-800">⏳ Downloading <b>{fileName}</b> …</p>}
          {state.kind === "cancelled" && <p className="text-sm text-ink-600">Save cancelled — no file was written.</p>}
          {state.kind === "saved" && (
            <div className="text-sm text-ink-800">
              <p className="font-semibold text-emerald-700">✓ Saved to your computer</p>
              <p className="mt-1">
                <b>{state.name}</b> ({state.size})
              </p>
              <p className="mt-1 text-xs text-ink-500">
                {state.where === "picker"
                  ? "It was saved to the folder you selected in the save dialog."
                  : "Check the Downloads folder of this browser. If you cannot find it, search your computer for the file name."}
              </p>
            </div>
          )}
          {state.kind === "failed" && (
            <div className="text-sm">
              <p className="font-semibold text-rose-700">⚠ The file could not be saved automatically.</p>
              <p className="mt-1 text-ink-600">
                Use the button below, then click the download icon at the top right of the page that opens.
              </p>
              <a
                href={state.href}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-3 inline-block rounded-sm bg-ink-900 px-4 py-2 text-sm font-semibold text-white"
              >
                Open {state.name}
              </a>
            </div>
          )}

          <div className="mt-4 flex items-center justify-between gap-3">
            <a href={href} target="_blank" rel="noopener noreferrer" className="text-xs font-medium text-indigo-700 hover:underline">
              Open in a new tab instead
            </a>
            <button
              onClick={() => setState({ kind: "idle" })}
              className="rounded-sm border border-stone-300 px-3 py-1.5 text-xs font-semibold text-ink-700 hover:bg-stone-50"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </>
  );
}
