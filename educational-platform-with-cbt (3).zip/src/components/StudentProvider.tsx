"use client";

import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from "react";
import { Check, X } from "lucide-react";
import { Crest } from "./Logo";
import { CATEGORIES, getCategory, type CategoryId } from "@/lib/academics";

export type Student = { name: string; regNo: string; category: CategoryId; department: string; level: string };

type Ctx = {
  student: Student | null;
  ready: boolean;
  signIn: (s: Student) => void;
  signOut: () => void;
  openSignIn: () => void;
  closeSignIn: () => void;
  signInOpen: boolean;
};

const StudentContext = createContext<Ctx | null>(null);
const KEY = "plh-student-v2";

function isValid(s: unknown): s is Student {
  const v = s as Student;
  return !!v && typeof v.name === "string" && typeof v.regNo === "string" && !!getCategory(v.category) && !!v.department && !!v.level;
}

export function StudentProvider({ children }: { children: ReactNode }) {
  const [student, setStudent] = useState<Student | null>(null);
  const [ready, setReady] = useState(false);
  const [signInOpen, setSignInOpen] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(KEY);
      const parsed = raw ? JSON.parse(raw) : null;
      // eslint-disable-next-line react-hooks/set-state-in-effect
      if (isValid(parsed)) setStudent(parsed);
    } catch {}
    setReady(true);
  }, []);

  const signIn = useCallback((s: Student) => {
    const clean = { ...s, name: s.name.trim(), regNo: s.regNo.trim().toUpperCase() };
    localStorage.setItem(KEY, JSON.stringify(clean));
    setStudent(clean);
    setSignInOpen(false);
  }, []);

  const signOut = useCallback(() => {
    localStorage.removeItem(KEY);
    setStudent(null);
  }, []);

  return (
    <StudentContext.Provider
      value={{
        student,
        ready,
        signIn,
        signOut,
        signInOpen,
        openSignIn: () => setSignInOpen(true),
        closeSignIn: () => setSignInOpen(false),
      }}
    >
      {children}
      {signInOpen && <SignInModal initial={student} />}
    </StudentContext.Provider>
  );
}

export function useStudent() {
  const ctx = useContext(StudentContext);
  if (!ctx) throw new Error("useStudent must be used within StudentProvider");
  return ctx;
}

const field =
  "w-full rounded-sm border border-stone-300 bg-white px-4 py-3 text-[15px] text-ink-900 outline-none transition placeholder:text-ink-300 focus:border-ink-700 focus:ring-4 focus:ring-ink-100";
const label = "mb-1.5 block text-[11px] font-semibold uppercase tracking-wider text-ink-600";

function SignInModal({ initial }: { initial: Student | null }) {
  const { signIn, closeSignIn } = useStudent();
  const [name, setName] = useState(initial?.name ?? "");
  const [regNo, setRegNo] = useState(initial?.regNo ?? "");
  const [category, setCategory] = useState<CategoryId>(initial?.category ?? "university");
  const cat = getCategory(category)!;
  const [department, setDepartment] = useState(initial?.department ?? cat.departments[0].id);
  const dep = cat.departments.find((d) => d.id === department) ?? cat.departments[0];
  const [level, setLevel] = useState(initial?.level ?? dep.levels[0]);
  const [error, setError] = useState("");

  const pickCategory = (id: CategoryId) => {
    const c = getCategory(id)!;
    setCategory(id);
    setDepartment(c.departments[0].id);
    setLevel(c.departments[0].levels[0]);
  };
  const pickDepartment = (id: string) => {
    const d = cat.departments.find((x) => x.id === id)!;
    setDepartment(id);
    if (!d.levels.includes(level)) setLevel(d.levels[0]);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto bg-ink-950/70 p-4 backdrop-blur-sm" onClick={closeSignIn}>
      <div onClick={(e) => e.stopPropagation()} className="my-8 grid w-full max-w-4xl overflow-hidden rounded-md bg-paper shadow-2xl md:grid-cols-5">
        <div className="relative hidden md:col-span-2 md:block">
          <div className="absolute inset-0 bg-cover bg-center transition-all duration-500" style={{ backgroundImage: `url(${cat.image})` }} />
          <div className="absolute inset-0 bg-gradient-to-t from-ink-950 via-ink-950/60 to-ink-950/20" />
          <div className="absolute bottom-0 p-8 text-white">
            <p className="text-[11px] font-semibold uppercase tracking-[0.25em] text-gold-300">{cat.name}</p>
            <p className="mt-2 font-serif text-2xl leading-snug">&ldquo;Education is the passport to the future.&rdquo;</p>
            <p className="mt-3 text-xs uppercase tracking-[0.25em] text-ink-300">— Malcolm X</p>
          </div>
        </div>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (name.trim().length < 3) return setError("Please enter your full name.");
            if (regNo.trim().length < 3) return setError(`Please enter a valid ${cat.idLabel.toLowerCase()}.`);
            signIn({ name, regNo, category, department: dep.id, level });
          }}
          className="relative p-7 sm:p-9 md:col-span-3"
        >
          <button type="button" onClick={closeSignIn} className="absolute right-4 top-4 rounded-sm p-1.5 text-ink-400 hover:bg-stone-100" aria-label="Close">
            <X className="h-5 w-5" />
          </button>
          <div className="flex items-center gap-4">
            <Crest className="h-11 w-11" />
            <div>
              <h2 className="font-serif text-2xl text-ink-950">Student Login</h2>
              <p className="text-sm text-ink-500">Tell us who you are so we can show your class's tests.</p>
            </div>
          </div>

          <p className={`${label} mt-7`}>I am a student of</p>
          <div className="grid grid-cols-2 gap-2">
            {CATEGORIES.map((c) => (
              <button
                key={c.id}
                type="button"
                onClick={() => pickCategory(c.id)}
                className={`flex items-center gap-2 rounded-sm border px-3 py-2.5 text-left text-sm font-medium transition ${
                  category === c.id ? "border-ink-900 bg-ink-900 text-white" : "border-stone-300 bg-white text-ink-700 hover:border-ink-400"
                }`}
              >
                <span className={`flex h-4 w-4 shrink-0 items-center justify-center rounded-full border ${category === c.id ? "border-gold-300 bg-gold-400" : "border-stone-300"}`}>
                  {category === c.id && <Check className="h-2.5 w-2.5 text-ink-950" strokeWidth={4} />}
                </span>
                {c.name}
              </button>
            ))}
          </div>

          <div className="mt-5 grid gap-4 sm:grid-cols-2">
            {cat.departments.length > 1 && (
              <div className="sm:col-span-2">
                <label className={label}>{category === "secondary" ? "Section" : "Department / Programme"}</label>
                <select value={dep.id} onChange={(e) => pickDepartment(e.target.value)} className={field}>
                  {cat.departments.map((d) => (
                    <option key={d.id} value={d.id}>
                      {d.name}
                    </option>
                  ))}
                </select>
              </div>
            )}
            <div>
              <label className={label}>{category === "university" ? "Level" : "Class / Level"}</label>
              <select value={level} onChange={(e) => setLevel(e.target.value)} className={field}>
                {dep.levels.map((l) => (
                  <option key={l}>{l}</option>
                ))}
              </select>
            </div>
            <div>
              <label className={label}>{cat.idLabel}</label>
              <input value={regNo} onChange={(e) => setRegNo(e.target.value)} placeholder={cat.idPlaceholder} className={`${field} uppercase placeholder:normal-case`} />
            </div>
            <div className="sm:col-span-2">
              <label className={label}>Full name</label>
              <input autoFocus value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Amaka Johnson" className={field} />
            </div>
          </div>

          {error && <p className="mt-3 text-sm text-rose-700">{error}</p>}
          <button className="mt-7 w-full rounded-sm bg-ink-900 py-3.5 text-sm font-semibold tracking-wide text-white transition hover:bg-ink-800">
            Continue
          </button>
        </form>
      </div>
    </div>
  );
}
