import Link from "next/link";

type Tone = "dark" | "light";

/** "Knowledge · Growth · Excellence" set on an arc below the wordmark. */
const TAGLINE = "KNOWLEDGE · GROWTH · EXCELLENCE";
const TAGLINE_CX = 120;
const TAGLINE_CY = 122;
const TAGLINE_R = 102;
const TAGLINE_SPAN = 112;

const colors = (tone: Tone) =>
  tone === "light"
    ? {
        navy: "#F2F6FA",
        teal: "#8FD2E6",
        gold: "#E9A13B",
        ring: "rgba(255,255,255,0.32)",
        page: "#12233A",
      }
    : {
        navy: "#163E63",
        teal: "#2286A8",
        gold: "#E9A13B",
        ring: "#D6DFE6",
        page: "#FFFFFF",
      };

/** The emblem: star, growth arrow, crown and open book. */
function Mark({ tone }: { tone: Tone }) {
  const c = colors(tone);
  return (
    <g>
      {/* growth arrow rising to the star */}
      <path
        d="M62 88 C50 66 58 45 80 35"
        fill="none"
        stroke={c.teal}
        strokeWidth="7"
        strokeLinecap="round"
      />
      <path d="M94 33 L79 27 L79 45 Z" fill={c.teal} transform="rotate(-16 79 36)" />

      {/* gold star with sparkle */}
      <path
        d="M120 14 L123.4 22.2 L132.2 22.9 L125.5 28.8 L127.3 37.5 L120 33.1 L112.7 37.5 L114.5 28.8 L107.8 22.9 L116.6 22.2 Z"
        fill={c.gold}
      />
      <path d="M120 2 V8 M107 8 L111 12.5 M133 8 L129 12.5" stroke={c.gold} strokeWidth="2.6" strokeLinecap="round" />

      {/* dotted arc sweeping away from the star */}
      {[
        [137, 18, 3.3],
        [148, 22, 3.1],
        [158, 29, 2.9],
        [167, 39, 2.7],
        [173, 51, 2.5],
        [177, 64, 2.3],
      ].map(([x, y, r]) => (
        <circle key={`${x}-${y}`} cx={x} cy={y} r={r} fill={c.gold} />
      ))}

      {/* open book */}
      <path
        d="M58 88 C82 90 102 96 120 108 C138 96 158 90 182 88 L182 97 C158 99 138 105 120 117 C102 105 82 99 58 97 Z"
        fill={c.teal}
      />
      <path
        d="M120 108 C102 96 82 90 58 88 L58 74 C82 76 104 82 120 94 Z"
        fill={c.page}
        stroke={c.navy}
        strokeWidth="2.6"
        strokeLinejoin="round"
      />
      <path
        d="M120 108 C138 96 158 90 182 88 L182 74 C158 76 136 82 120 94 Z"
        fill={c.page}
        stroke={c.navy}
        strokeWidth="2.6"
        strokeLinejoin="round"
      />
      <path
        d="M66 82 C84 85 98 90 112 97 M174 82 C156 85 142 90 128 97"
        fill="none"
        stroke={c.navy}
        strokeWidth="1.7"
        strokeLinecap="round"
        opacity="0.45"
      />
      <path d="M120 117 L111 126 L120 121 L129 126 Z" fill={c.teal} />

      {/* crown resting on the book */}
      <circle cx="92" cy="57" r="3.2" fill={c.teal} />
      <circle cx="120" cy="47" r="3.8" fill={c.teal} />
      <circle cx="148" cy="57" r="3.2" fill={c.teal} />
      <path d="M92 97 L92 62 L106 75 L120 53 L134 75 L148 62 L148 97 Z" fill={c.navy} />
      <path d="M92 88 H148 V97 H92 Z" fill={c.teal} />
    </g>
  );
}

/** Emblem only — used in small spaces such as the navbar and result slips. */
export function Crest({ className = "h-11 w-11", tone = "dark" }: { className?: string; tone?: Tone }) {
  return (
    <svg viewBox="38 0 164 134" className={className} aria-hidden="true">
      <Mark tone={tone} />
    </svg>
  );
}

/** Full lockup: emblem, ring, wordmark and the "Knowledge · Growth · Excellence" arc. */
export function Logo({ light = false, className = "h-56 w-56" }: { light?: boolean; className?: string }) {
  const tone: Tone = light ? "light" : "dark";
  const c = colors(tone);
  return (
    <svg viewBox="0 0 240 240" className={className} role="img" aria-label="Prince Learning Hub">
      {/* broken ring around the lockup */}
      <path d="M40.8 201.2 A 112 112 0 0 0 40.8 42.8" fill="none" stroke={c.ring} strokeWidth="3" strokeLinecap="round" />
      <path d="M199.2 42.8 A 112 112 0 0 1 199.2 201.2" fill="none" stroke={c.ring} strokeWidth="3" strokeLinecap="round" />

      <Mark tone={tone} />

      <text
        x="120"
        y="156"
        textAnchor="middle"
        fill={c.navy}
        fontFamily="Fraunces, Georgia, 'Times New Roman', serif"
        fontWeight="700"
        fontSize="36"
        letterSpacing="2"
      >
        PRINCE
      </text>
      <text
        x="120"
        y="177"
        textAnchor="middle"
        fill={c.teal}
        fontFamily="Inter, Helvetica, Arial, sans-serif"
        fontWeight="700"
        fontSize="12"
        letterSpacing="5.5"
      >
        • LEARNING •
      </text>
      <path d="M62 194 H102 M138 194 H178" stroke={c.teal} strokeWidth="2" strokeLinecap="round" />
      <text
        x="120"
        y="201"
        textAnchor="middle"
        fill={c.teal}
        fontFamily="Inter, Helvetica, Arial, sans-serif"
        fontWeight="700"
        fontSize="15"
        letterSpacing="5"
      >
        HUB
      </text>

      {/* tagline set letter by letter along the bottom arc */}
      {TAGLINE.split("").map((ch, i) => {
        const phi = (i - (TAGLINE.length - 1) / 2) * (TAGLINE_SPAN / (TAGLINE.length - 1));
        const rad = (phi * Math.PI) / 180;
        const x = TAGLINE_CX + TAGLINE_R * Math.sin(rad);
        const y = TAGLINE_CY + TAGLINE_R * Math.cos(rad);
        return (
          <text
            key={i}
            transform={`translate(${x.toFixed(2)} ${y.toFixed(2)}) rotate(${phi.toFixed(2)})`}
            textAnchor="middle"
            dominantBaseline="central"
            fill={c.navy}
            fontFamily="Inter, Helvetica, Arial, sans-serif"
            fontWeight="600"
            fontSize="7.5"
          >
            {ch}
          </text>
        );
      })}
    </svg>
  );
}

export default function Brand({ light = false }: { light?: boolean }) {
  return (
    <Link href="/" className="flex items-center gap-3" aria-label="Prince Learning Hub — home">
      <Crest tone={light ? "light" : "dark"} className="h-12 w-12" />
      <span className="leading-none">
        <span
          className="block font-serif text-[22px] font-medium tracking-tight"
          style={{ color: light ? "#F2F6FA" : "#163E63" }}
        >
          PRINCE
        </span>
        <span
          className="mt-1 block text-[9.5px] font-semibold uppercase tracking-[0.34em]"
          style={{ color: light ? "#8FD2E6" : "#2286A8" }}
        >
          Learning Hub
        </span>
      </span>
    </Link>
  );
}
