import Link from "next/link";
import { ChevronRight } from "lucide-react";

export default function PageHeader({
  eyebrow,
  title,
  subtitle,
  image,
}: {
  eyebrow: string;
  title: string;
  subtitle: string;
  image: string;
}) {
  return (
    <section className="no-print relative overflow-hidden bg-ink-950">
      <div className="absolute inset-0 bg-cover bg-center" style={{ backgroundImage: `url(${image})` }} />
      <div className="absolute inset-0 bg-gradient-to-r from-ink-950 via-ink-950/85 to-ink-950/40" />
      <div className="relative mx-auto max-w-7xl px-6 py-16 sm:py-20">
        <nav className="flex items-center gap-1.5 text-xs text-ink-300">
          <Link href="/" className="hover:text-gold-300">Home</Link>
          <ChevronRight className="h-3 w-3" />
          <span className="text-gold-300">{title}</span>
        </nav>
        <p className="mt-6 text-[11px] font-semibold uppercase tracking-[0.3em] text-gold-400">{eyebrow}</p>
        <h1 className="mt-3 max-w-3xl font-serif text-4xl font-medium leading-tight text-white sm:text-5xl">{title}</h1>
        <p className="mt-4 max-w-2xl text-base leading-relaxed text-ink-200">{subtitle}</p>
      </div>
    </section>
  );
}
