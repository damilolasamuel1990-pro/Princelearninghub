import Link from "next/link";
import { Mail } from "lucide-react";
import { Logo as LogoLockup } from "./Logo";
import { WhatsAppIcon } from "./WhatsApp";
import { CONTACT, whatsappLink } from "@/lib/academics";

export default function Footer() {
  return (
    <footer className="no-print mt-24 bg-ink-950 text-ink-300">
      <div className="mx-auto grid max-w-7xl gap-12 px-6 py-16 sm:grid-cols-2 lg:grid-cols-12">
        <div className="lg:col-span-4">
          <LogoLockup light className="h-56 w-56" />
          <p className="mt-6 max-w-sm text-sm leading-relaxed text-ink-300">
            An online campus for university, polytechnic, secondary and primary students, with lectures, PDF course materials, CBT tests and tutor support.
          </p>
        </div>
        <div className="lg:col-span-2">
          <h4 className="font-serif text-lg text-white">Academics</h4>
          <ul className="mt-5 space-y-3 text-sm">
            <li><Link href="/lectures" className="hover:text-gold-300">Online Lectures</Link></li>
            <li><Link href="/materials" className="hover:text-gold-300">Course Materials</Link></li>
            <li><Link href="/cbt" className="hover:text-gold-300">CBT Tests</Link></li>
            <li><Link href="/results" className="hover:text-gold-300">Results</Link></li>
          </ul>
        </div>
        <div className="lg:col-span-2">
          <h4 className="font-serif text-lg text-white">Community</h4>
          <ul className="mt-5 space-y-3 text-sm">
            <li><Link href="/chat" className="hover:text-gold-300">Discussions</Link></li>
            <li><Link href="/news" className="hover:text-gold-300">News & Notices</Link></li>
            <li><Link href="/admin" className="hover:text-gold-300">Staff Portal</Link></li>
          </ul>
        </div>
        <div className="lg:col-span-4">
          <h4 className="font-serif text-lg text-white">Contact Us</h4>
          <ul className="mt-5 space-y-4 text-sm">
            <li>
              <a href={whatsappLink()} target="_blank" rel="noopener noreferrer" className="group flex items-center gap-3 hover:text-white">
                <span className="flex h-9 w-9 items-center justify-center rounded-full bg-[#25D366]/15 text-[#25D366]">
                  <WhatsAppIcon className="h-4 w-4" />
                </span>
                <span>
                  <span className="block text-[11px] uppercase tracking-wider text-ink-400">WhatsApp</span>
                  <span className="text-base text-white group-hover:text-gold-300">{CONTACT.whatsapp}</span>
                </span>
              </a>
            </li>
            <li>
              <a href={`mailto:${CONTACT.email}`} className="group flex items-center gap-3 hover:text-white">
                <span className="flex h-9 w-9 items-center justify-center rounded-full bg-gold-400/15 text-gold-300">
                  <Mail className="h-4 w-4" />
                </span>
                <span className="min-w-0">
                  <span className="block text-[11px] uppercase tracking-wider text-ink-400">Email</span>
                  <span className="break-all text-white group-hover:text-gold-300">{CONTACT.email}</span>
                </span>
              </a>
            </li>
          </ul>
        </div>
      </div>
      <div className="border-t border-white/10">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-2 px-6 py-6 text-xs text-ink-400 sm:flex-row">
          <span>© {new Date().getFullYear()} Prince Learning Hub. All rights reserved.</span>
          <span>Photography courtesy of Pexels contributors</span>
        </div>
      </div>
    </footer>
  );
}
