"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { CornerDownRight, HelpCircle, MessageSquare, SendHorizontal, X } from "lucide-react";
import { useStudent } from "./StudentProvider";

type Msg = {
  id: number;
  room: string;
  senderName: string;
  regNo: string;
  body: string;
  isQuestion: boolean;
  replyTo: number | null;
  createdAt: string;
};

function timeAgo(iso: string) {
  const d = new Date(iso);
  const diff = (Date.now() - d.getTime()) / 1000;
  if (diff < 60) return "just now";
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
  return d.toLocaleDateString("en-GB", { day: "numeric", month: "short" });
}

const tones = ["bg-ink-600", "bg-gold-600", "bg-stone-500", "bg-teal-700", "bg-rose-800", "bg-ink-400", "bg-emerald-800"];
function toneFor(s: string) {
  let h = 0;
  for (const c of s) h = (h * 31 + c.charCodeAt(0)) >>> 0;
  return tones[h % tones.length];
}

export default function ChatBox({ room, title, subtitle, heightClass = "h-[60vh]" }: { room: string; title?: string; subtitle?: string; heightClass?: string }) {
  const { student, openSignIn } = useStudent();
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [text, setText] = useState("");
  const [isQuestion, setIsQuestion] = useState(false);
  const [replyTo, setReplyTo] = useState<Msg | null>(null);
  const [questionsOnly, setQuestionsOnly] = useState(false);
  const [sending, setSending] = useState(false);
  const lastId = useRef(0);
  const listRef = useRef<HTMLDivElement>(null);
  const stick = useRef(true);

  const scrollDown = () => {
    requestAnimationFrame(() => {
      if (listRef.current && stick.current) listRef.current.scrollTop = listRef.current.scrollHeight;
    });
  };

  const poll = useCallback(async () => {
    try {
      const res = await fetch(`/api/chat?room=${encodeURIComponent(room)}&after=${lastId.current}`, { cache: "no-store" });
      if (!res.ok) return;
      const data: Msg[] = await res.json();
      if (data.length) {
        lastId.current = data[data.length - 1].id;
        setMsgs((prev) => {
          const seen = new Set(prev.map((m) => m.id));
          return [...prev, ...data.filter((m) => !seen.has(m.id))];
        });
        scrollDown();
      }
    } catch {}
  }, [room]);

  useEffect(() => {
    lastId.current = 0;
    stick.current = true;
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setMsgs([]);
    poll();
    const t = setInterval(poll, 3000);
    return () => clearInterval(t);
  }, [room, poll]);

  async function send(e: React.FormEvent) {
    e.preventDefault();
    if (!student) return openSignIn();
    if (!text.trim() || sending) return;
    setSending(true);
    try {
      await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ room, name: student.name, regNo: student.regNo, body: text, isQuestion, replyTo: replyTo?.id }),
      });
      setText("");
      setIsQuestion(false);
      setReplyTo(null);
      stick.current = true;
      await poll();
    } finally {
      setSending(false);
    }
  }

  const byId = new Map(msgs.map((m) => [m.id, m]));
  const shown = questionsOnly ? msgs.filter((m) => m.isQuestion || (m.replyTo && byId.get(m.replyTo)?.isQuestion)) : msgs;

  return (
    <div className="flex flex-col overflow-hidden rounded-md border border-stone-200 bg-white shadow-sm">
      <div className="flex items-center justify-between border-b border-stone-200 px-5 py-4">
        <div>
          <div className="flex items-center gap-2.5">
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-500 opacity-60" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-600" />
            </span>
            <h3 className="font-serif text-lg text-ink-950">{title ?? "Discussion"}</h3>
          </div>
          {subtitle && <p className="ml-[18px] text-xs text-ink-400">{subtitle}</p>}
        </div>
        <button
          onClick={() => setQuestionsOnly((v) => !v)}
          className={`flex items-center gap-1.5 rounded-sm border px-3 py-1.5 text-xs font-medium transition ${
            questionsOnly ? "border-gold-400 bg-gold-50 text-gold-700" : "border-stone-200 text-ink-500 hover:bg-stone-50"
          }`}
        >
          <HelpCircle className="h-3.5 w-3.5" /> Questions only
        </button>
      </div>

      <div
        ref={listRef}
        onScroll={(e) => {
          const el = e.currentTarget;
          stick.current = el.scrollHeight - el.scrollTop - el.clientHeight < 80;
        }}
        className={`${heightClass} space-y-5 overflow-y-auto bg-paper px-5 py-5`}
      >
        {shown.length === 0 && (
          <div className="flex h-full flex-col items-center justify-center text-center text-ink-400">
            <MessageSquare className="h-8 w-8 text-ink-200" />
            <p className="mt-3 text-sm">No messages yet. Start the conversation.</p>
          </div>
        )}
        {shown.map((m) => {
          const mine = !!student && m.regNo === student.regNo;
          const staff = m.regNo.startsWith("STAFF");
          const parent = m.replyTo ? byId.get(m.replyTo) : undefined;
          return (
            <div key={m.id} className={`group flex gap-3 ${mine ? "flex-row-reverse" : ""}`}>
              <span
                className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-full font-serif text-sm text-white ${
                  staff ? "bg-ink-950 text-gold-300 ring-2 ring-gold-400" : toneFor(m.regNo)
                }`}
              >
                {m.senderName.charAt(0).toUpperCase()}
              </span>
              <div className={`flex max-w-[80%] flex-col ${mine ? "items-end" : "items-start"}`}>
                <div className="mb-1 flex items-center gap-2 text-[11px] text-ink-400">
                  <span className="font-semibold text-ink-700">{mine ? "You" : m.senderName}</span>
                  {staff && <span className="rounded-sm bg-ink-900 px-1.5 py-0.5 text-[9px] font-bold tracking-wider text-gold-300">TUTOR</span>}
                  <span>{timeAgo(m.createdAt)}</span>
                </div>
                <div
                  className={`rounded-md px-4 py-2.5 text-[14px] leading-relaxed ${
                    m.isQuestion
                      ? "border border-gold-200 border-l-[3px] border-l-gold-500 bg-gold-50 text-ink-900"
                      : mine
                        ? "bg-ink-900 text-white"
                        : "border border-stone-200 bg-white text-ink-800"
                  }`}
                >
                  {m.isQuestion && (
                    <div className="mb-1 flex items-center gap-1 text-[10px] font-bold uppercase tracking-[0.15em] text-gold-700">
                      <HelpCircle className="h-3 w-3" /> Question
                    </div>
                  )}
                  {parent && (
                    <div className={`mb-2 flex gap-1.5 border-l-2 pl-2 text-xs ${mine && !m.isQuestion ? "border-ink-500 text-ink-200" : "border-stone-300 text-ink-400"}`}>
                      <CornerDownRight className="mt-0.5 h-3 w-3 shrink-0" />
                      <span>
                        <b>{parent.senderName}:</b> {parent.body.slice(0, 80)}
                        {parent.body.length > 80 ? "…" : ""}
                      </span>
                    </div>
                  )}
                  <p className="whitespace-pre-wrap break-words">{m.body}</p>
                </div>
                <button onClick={() => setReplyTo(m)} className="mt-1 text-[11px] font-semibold text-gold-700 opacity-0 transition group-hover:opacity-100">
                  {m.isQuestion ? "Answer" : "Reply"}
                </button>
              </div>
            </div>
          );
        })}
      </div>

      <form onSubmit={send} className="border-t border-stone-200 bg-white p-4">
        {replyTo && (
          <div className="mb-3 flex items-center justify-between rounded-sm bg-ink-50 px-3 py-2 text-xs text-ink-700">
            <span className="truncate">
              Replying to <b>{replyTo.senderName}</b>: {replyTo.body.slice(0, 60)}
            </span>
            <button type="button" onClick={() => setReplyTo(null)} className="ml-2 text-ink-400 hover:text-ink-900">
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
        )}
        {student ? (
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setIsQuestion((q) => !q)}
              title="Mark as a question for tutors"
              className={`flex shrink-0 items-center gap-1.5 rounded-sm border px-3 py-2.5 text-xs font-semibold transition ${
                isQuestion ? "border-gold-500 bg-gold-50 text-gold-700" : "border-stone-300 text-ink-500 hover:bg-stone-50"
              }`}
            >
              <HelpCircle className="h-4 w-4" />
              <span className="hidden sm:inline">{isQuestion ? "Question" : "Ask"}</span>
            </button>
            <input
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder={isQuestion ? "Type your question for the tutor…" : "Write a message…"}
              className="min-w-0 flex-1 rounded-sm border border-stone-300 px-4 py-2.5 text-sm outline-none focus:border-ink-700 focus:ring-4 focus:ring-ink-100"
            />
            <button
              disabled={sending || !text.trim()}
              className="flex shrink-0 items-center gap-2 rounded-sm bg-ink-900 px-4 py-2.5 text-sm font-semibold text-white hover:bg-ink-800 disabled:opacity-40"
            >
              <SendHorizontal className="h-4 w-4" />
              <span className="hidden sm:inline">Send</span>
            </button>
          </div>
        ) : (
          <button type="button" onClick={openSignIn} className="w-full rounded-sm bg-ink-900 py-3 text-sm font-semibold text-white hover:bg-ink-800">
            Log in to join the discussion
          </button>
        )}
      </form>
    </div>
  );
}
