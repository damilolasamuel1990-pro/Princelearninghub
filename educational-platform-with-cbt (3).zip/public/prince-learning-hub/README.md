# Prince Learning Hub — static website (HTML, CSS, JavaScript)

This folder is a complete, standalone website. No build step, no database and no server code
are required: copy the folder anywhere (a laptop, a USB drive, or any web host) and open
`index.html` in a browser.

## Folder structure

```
prince-learning-hub/
├── index.html            Home page
├── pages/                Every other page
│   ├── news.html         News & announcements
│   ├── materials.html    Course materials (PDF downloads)
│   ├── lectures.html     Lecture listing
│   ├── lecture.html      Lecture room (video + discussion)
│   ├── cbt.html          CBT tests (timed, marked instantly)
│   ├── results.html      Results history + leaderboard
│   ├── result.html       Result slip with corrections
│   ├── chat.html         Discussion rooms
│   └── admin.html        Staff portal (news + lecture status)
├── css/
│   └── style.css         The whole design (colours, typography, components)
├── js/
│   ├── ui.js             Logo, header, footer, login, WhatsApp, file saving
│   ├── store.js          Saved results and chat messages (browser storage)
│   ├── home.js           Home page
│   ├── news.js           News page
│   ├── materials.js      Materials page (filter, search, download)
│   ├── lectures.js       Lectures + lecture room
│   ├── cbt.js            CBT engine: timer, navigator, marking
│   ├── results.js        Results list + result slip
│   ├── chat.js           Discussion widget
│   └── admin.js          Staff portal
├── data/
│   ├── content.js        News, lectures and the materials catalogue
│   └── questions.js      All CBT question banks (102 tests, 3,260 questions)
├── images/               Photographs and the logo artwork
└── downloads/            92 PDF handouts (45–54 pages each)
```

## Features

* **Student login** with name, registration number, school type, department and level
  (stored in the browser).
* **CBT tests** for University, Polytechnic, Secondary and Primary students, grouped by
  department and level. Countdown timer, question navigator, keyboard shortcuts (A–D to
  answer, N/P to move), auto-submit when time runs out, instant result with corrections.
* **PDF handouts** for every university and polytechnic course, with a designed cover page,
  units, worked examples, assignments, glossary and practice questions. Clicking a document
  opens the browser's save dialog so the file is saved to the computer.
* **Online lectures** with video and a per-lecture discussion room.
* **Discussion rooms** with a "mark as question" option and a questions-only filter.
* **Results** with score, grade, corrections and a top-10 leaderboard.
* **News** with categories and pinned items.
* **Staff portal** (code: `prince-admin`) to publish news and set lecture status.

## Changing content

* News, lectures and the material catalogue: `data/content.js`
* CBT questions: `data/questions.js`
* Colours and fonts: `css/style.css` (see the `:root` block at the top)
* Contact details (WhatsApp `07036042766`, `damilolasamuel1990@gmail.com`):
  search for them in `js/ui.js`

## Notes

* Data such as results, chat messages and staff news is stored in the browser
  (`localStorage`). On a real deployment you would connect these to a server so that
  students see each other's messages and results.
* The photographs are from Pexels (free to use). The logo is drawn as vector artwork, so it
  can be scaled or printed in one colour.
